﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Diagnostics;
using System.Drawing;
using System.ComponentModel;
using System.Windows.Media.Imaging;
using System.Drawing.Imaging;
using System.Collections.ObjectModel;
using System.Threading;
using System.Windows.Threading;

namespace ArnapouCropper
{
    public enum ImageMode
    {
        Draw,
        Erase
    };

    public enum ImageThickness
    {
        Small,
        Normal,
        Large
    };

    public class Image : INotifyPropertyChanged
    {
        private int SMALL_SIZE = 500;


        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null) PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }

        /* penMode */
        private ImageMode _penMode = ImageMode.Draw;
        public ImageMode penMode
        {
            get { return _penMode; }
            set { _penMode = value; OnPropertyChanged("penMode"); }
        }

        /* penThickness */
        private ImageThickness _penThickness = ImageThickness.Normal;
        public ImageThickness penThickness
        {
            get { return _penThickness; }
            set { _penThickness = value; OnPropertyChanged("penThickness"); }
        }
        private ObservableCollection<ImageThickness> _penThicknessList = new ObservableCollection<ImageThickness>();
        public ObservableCollection<ImageThickness> penThicknessList { get { return _penThicknessList; } }

        /* CropFactor */
        private double _cropFactor = 1.1;
        public double cropFactor
        {
            get { return _cropFactor; }
            set { _cropFactor = value; OnPropertyChanged("cropFactor"); }
        }
        private ObservableCollection<double> _cropFactorList = new ObservableCollection<double>();
        public ObservableCollection<double> cropFactorList { get { return _cropFactorList; } }

        /* Factor NB */
        private double _factorNB = 2;
        public double factorNB
        {
            get { return _factorNB; }
            set { _factorNB = value; OnPropertyChanged("factorNB"); generateBlackAndWhite(); }
        }
        private ObservableCollection<double> _factorNBList = new ObservableCollection<double>();
        public ObservableCollection<double> factorNBList { get { return _factorNBList; } }

        /* Seuil */
        private int _seuil = 128;
        public int seuil
        {
            get { return _seuil; }
            set { _seuil = value; OnPropertyChanged("seuil"); generateBlackAndWhite(); }
        }
        private ObservableCollection<int> _seuilList = new ObservableCollection<int>();
        public ObservableCollection<int> seuilList { get { return _seuilList; } }

        /* Path */
        private string filename = "";
        private string backupPath = "";
        private string backupFile = "";
        public string path { get { string s; if (filename == "") { s = ""; } else if (File.Exists(backupFile)) { s = backupFile; } else { s = filename; }; return s; } }
        public string name { get { return Path.GetFileName(this.filename); } }

        /* Small */
        private Bitmap _bitmap = null;
        private BitmapSource _bitmapImage = null;
        public BitmapSource bitmapImage { get { return _bitmapImage; } }

        /* Small */
        private Bitmap _small = null;
        private Bitmap _smallNB = null;
        private BitmapSource _smallNBImage = null;
        public BitmapSource smallNBImage { get { return _smallNBImage; } }

        /* Cropped */
        private Bitmap _cropped = null;
        private BitmapSource _croppedImage = null;
        public BitmapSource croppedImage { get { return _croppedImage; } }

        public Image(string filename)
        {
            this.filename = filename;
            backupPath = Directory.GetParent(path) + "\\backup_crop";
            if (!Directory.Exists(backupPath)) { Directory.CreateDirectory(backupPath); }
            backupFile = backupPath + "\\" + System.IO.Path.GetFileName(path);
            OnPropertyChanged("path"); 
            OnPropertyChanged("name");

            for (double d = 1; d <= 5; d += 1) { this._factorNBList.Add(Math.Round(d, 0)); }
            OnPropertyChanged("factorNBList");
            OnPropertyChanged("factorNB");

            for (int i = 32; i <= 224; i += 32) { this._seuilList.Add(i); }
            OnPropertyChanged("seuilList");
            OnPropertyChanged("seuil");

            for (double d = 5; d <= 15; d += 1) { this._cropFactorList.Add(Math.Round(d/10, 1)); }
            OnPropertyChanged("cropFactorList");
            OnPropertyChanged("cropFactor");

            this._penThicknessList.Add(ImageThickness.Small);
            this._penThicknessList.Add(ImageThickness.Normal);
            this._penThicknessList.Add(ImageThickness.Large);
            OnPropertyChanged("penThicknessList");
            OnPropertyChanged("penThickness");
        }


        public void save()
        {
            if (!File.Exists(backupFile))
            {
                File.Copy(filename, backupFile);
                OnPropertyChanged("path");
            }
            if (_cropped != null)
            {
                MediaBitmap.SaveJpeg(filename, (System.Drawing.Image)_cropped, 98);
            }
        }


        public void unselectImage()
        {
            if (_bitmap != null) { _bitmap.Dispose(); }
            _bitmap = null;
            _bitmapImage = null;

            if (_small != null) { _small.Dispose(); }
            _small = null;

            if (_cropped != null) { _cropped.Dispose(); }
            _cropped = null;
            _croppedImage = null;

            if (_smallNB != null) { _smallNB.Dispose(); }
            _smallNB = null;
            _smallNBImage = null;
        }

        public void selectImage()
        {
            _bitmap = MediaBitmap.fromFile(path);
            _small = MediaBitmap.ResizeFit(_bitmap, SMALL_SIZE);
            _bitmapImage = MediaImage.fromBitmap(_bitmap);

            OnPropertyChanged("bitmapImage");

            if (_smallNB == null) generateBlackAndWhite();
            autoCrop();
        }

        public void generateBlackAndWhite()
        {
            if (_smallNB != null) _smallNB.Dispose();
            _smallNBImage = null;
            Bitmap bmp1 = MediaBitmap.EffectGrayscale(_small);
            Bitmap bmp2 = MediaBitmap.EffectNormalize(bmp1, _factorNB);
            _smallNB = MediaBitmap.EffectThreshold(bmp2, _seuil);
            _smallNBImage = MediaBitmap.toBitmapSource(_smallNB);
            bmp1.Dispose();
            bmp2.Dispose();
            OnPropertyChanged("smallNBImage");
            autoCrop();
        }

        public bool autoCrop()
        {
            if (_cropped != null) _cropped.Dispose();
            _cropped = null;
            _croppedImage = null;

            Rectangle rect = MediaBitmap.AutoCropRect(_smallNB);
            if (rect == Rectangle.Empty)
            {
                OnPropertyChanged("croppedImage");
                return false;
            }

            double scale = (double)_bitmap.Width / (double)_smallNB.Width;

            rect.X = (int)(scale * (double)rect.X);
            rect.Y = (int)(scale * (double)rect.Y);
            rect.Height = (int)(scale * (double)rect.Height);
            rect.Width = (int)(scale * (double)rect.Width);

            int size;
            if (rect.Width > rect.Height) { size = (int)(_cropFactor * (double)rect.Width); }
            else { size = (int)(_cropFactor * (double)rect.Height); }

            _cropped = new Bitmap(size, size);
            Graphics g = Graphics.FromImage((System.Drawing.Image)_cropped);
            Point pos = new Point(0, 0);
            pos.X = -(rect.X + (rect.Width - size) / 2);
            pos.Y = -(rect.Y + (rect.Height - size) / 2);

            g.FillRectangle(Brushes.White, new Rectangle(new Point(0, 0), new Size(size, size)));
            g.DrawImage((System.Drawing.Image)_bitmap, pos);
            g.Dispose();

            _croppedImage = MediaImage.fromBitmap(_cropped);
            OnPropertyChanged("croppedImage");
            return true;
        }

        public void clearNB()
        {
            if (_smallNB == null) return;
            Graphics g = Graphics.FromImage((System.Drawing.Image)_smallNB);
            g.FillRectangle(Brushes.White, new Rectangle(new Point(0, 0), new Size(_smallNB.Width, _smallNB.Height)));
            g.Dispose();

            _smallNBImage = MediaImage.fromBitmap(_smallNB);
            OnPropertyChanged("smallNBImage");
            autoCrop();
        }

        public void drawAt(System.Windows.Point pos)
        {
            if (_smallNB == null) return;
            Graphics g = Graphics.FromImage((System.Drawing.Image)_smallNB);

            try
            {
                int p = 0;
                if (penMode == ImageMode.Draw)
                {
                    if (_penThickness == ImageThickness.Small) p = 2;
                    else if (_penThickness == ImageThickness.Normal) p = 6;
                    else if (_penThickness == ImageThickness.Large) p = 18;

                    g.FillEllipse(Brushes.LightBlue, (int)(pos.X * _smallNB.Width) - p, (int)(pos.Y * _smallNB.Height) - p, 2 * p, 2 * p);
                    g.DrawEllipse(Pens.Black, (int)(pos.X * _smallNB.Width) - p, (int)(pos.Y * _smallNB.Height) - p, 2 * p, 2 * p);
                }
                else
                {
                    if (_penThickness == ImageThickness.Small) p = 20;
                    else if (_penThickness == ImageThickness.Normal) p = 40;
                    else if (_penThickness == ImageThickness.Large) p = 120;

                    g.FillEllipse(Brushes.White, (int)(pos.X * _smallNB.Width) - p, (int)(pos.Y * _smallNB.Height) - p, 2 * p, 2 * p);
                }
            }
            catch (Exception) { }
            g.Dispose();

            _smallNBImage = MediaImage.fromBitmap(_smallNB);
            OnPropertyChanged("smallNBImage");
            autoCrop();
        }
    }
}
