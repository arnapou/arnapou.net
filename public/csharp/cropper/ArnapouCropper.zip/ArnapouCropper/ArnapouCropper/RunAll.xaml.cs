﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.ComponentModel;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Threading;
using System.Windows.Threading;

namespace ArnapouCropper
{
    /// <summary>
    /// Logique d'interaction pour Window1.xaml
    /// </summary>
    public partial class RunAll : Window, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null) PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }

        private string _progressStatus = "";
        public string progressStatus
        {
            get { return _progressStatus; }
            set { _progressStatus = value; OnPropertyChanged("progressStatus"); }
        }

        public ObservableCollection<Image> images = new ObservableCollection<Image>();

        private Thread work;

        public RunAll()
        {
            InitializeComponent();
            this.DataContext = this;

            this.Loaded += new RoutedEventHandler(RunAll_Loaded);
            this.Closed += new EventHandler(RunAll_Closed);
            this.buttonCancel.Click += new RoutedEventHandler(buttonCancel_Click);

            work = new Thread(new ThreadStart(doThread));
            work.Priority = ThreadPriority.AboveNormal;
        }

        void RunAll_Closed(object sender, EventArgs e)
        {
            this.closeWindow();
        }

        void buttonCancel_Click(object sender, RoutedEventArgs e)
        {
            this.closeWindow();
            this.Close();
        }

        void closeWindow() {
            if (work.IsAlive) work.Abort();
        }

        void doThread()
        {
            if (images.Count > 0)
            {
                for (int i = 0; i < images.Count; i++)
                {
                    images[i].selectImage();
                    images[i].save();
                    progressBar.Dispatcher.BeginInvoke(
                        DispatcherPriority.Normal,
                        new Action(delegate()
                        {
                            progressBar.Value = i + 1;
                            this.progressStatus = (i + 1).ToString() + "/" + images.Count.ToString();
                        }
                    ));
                    images[i].unselectImage();
                    GC.Collect();
                }
                images[images.Count - 1].unselectImage();
            }
            this.Dispatcher.BeginInvoke(
                DispatcherPriority.Normal,
                new Action(delegate()
                {
                    this.Close();
                }
            ));
        }

        void RunAll_Loaded(object sender, RoutedEventArgs e)
        {
            progressBar.Maximum = (double)images.Count;
            work.Start();
        }
    }
}
