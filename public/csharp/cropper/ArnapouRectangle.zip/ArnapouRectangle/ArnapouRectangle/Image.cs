﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Diagnostics;
using System.Drawing;
using System.ComponentModel;
using System.Windows.Media.Imaging;
using System.Drawing.Imaging;
using System.Collections.ObjectModel;
using System.Threading;
using System.Windows.Threading;
using System.Drawing.Text;
using System.Drawing.Drawing2D;

namespace ArnapouRectangle
{

    public class Image : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null) PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }

        private int rotation = 0;

        private bool isNew = true;

        /* points */
        private List<System.Windows.Point> points = new List<System.Windows.Point>();

        /* Path */
        private string filename = "";
        private string backupPath = "";
        private string backupFile = "";
        public string path { get { string s; if (filename == "") { s = ""; } else if (File.Exists(backupFile)) { s = backupFile; } else { s = filename; }; return s; } }
        public string name { get { return Path.GetFileName(this.filename); } }

        /* bitmap */
        private Bitmap _bitmap = null;
        private BitmapSource _bitmapImage = null;
        public BitmapSource bitmapImage { get { return _bitmapImage; } }

        /* items */
        private ObservableCollection<ImageItem> _items = new ObservableCollection<ImageItem>();
        public ObservableCollection<ImageItem> items { get { return _items; } }
        private ImageItem _selectedItem = null;
        public ImageItem selectedItem
        {
            get { return _selectedItem; }
            set
            {
                _selectedItem = value;
                OnPropertyChanged("selectedItem");
            }
        }

        public void rotate90()
        {
            if (_bitmap == null) return;
            rotation += 90;
            for (int i = 0; i < points.Count; i++)
            {
                points[i] = new System.Windows.Point((double)_bitmap.Height - points[i].Y, points[i].X);
            }
            for (int i = 0; i < items.Count; i++)
            {
                items[i].rotatePoints90(_bitmap.Width,_bitmap.Height);
            }
            this.selectImage();
        }

        public Image(string filename)
        {
            this.filename = filename;
            backupPath = Directory.GetParent(path) + "\\backup_crop";
            if (!Directory.Exists(backupPath)) { Directory.CreateDirectory(backupPath); }
            backupFile = backupPath + "\\" + System.IO.Path.GetFileName(path);
            OnPropertyChanged("path"); 
            OnPropertyChanged("name");
        }

        public void save()
        {
            if (!File.Exists(backupFile))
            {
                File.Copy(filename, backupFile);
                OnPropertyChanged("path");
            }
            for(int i = 0; i< items.Count; i++) {
                items[i].saveTo(Directory.GetParent(filename).ToString(), Path.GetFileNameWithoutExtension(filename) + "." + (i + 1).ToString());
            }
            GC.Collect();
        }


        public void unselectImage()
        {
            if (_bitmap != null) { _bitmap.Dispose(); }
            _bitmap = null;
            _bitmapImage = null;

            for (int i = 0; i < items.Count; i++)
            {
                items[i].Dispose();
            }
            GC.Collect();
        }

        public void deleteCurrentItem()
        {
            if (selectedItem == null) return;
            ImageItem temp = selectedItem;
            ImageItem next = null;
            int index = items.IndexOf(temp);
            if (index < items.Count - 1)
            {
                next = items[index + 1];
            }
            else if(index > 0) {
                next = items[0];
            }
            selectedItem = next;
            temp.Dispose();
            items.Remove(temp);
            OnPropertyChanged("items");
            generateBitmapImage();
        }

        public void selectImage()
        {
            loadBitmap();
            if (isNew)
            {
                isNew = false;
                if (_bitmap != null && _bitmap.Width < _bitmap.Height)
                {
                    rotate90();
                    return;
                }
            }
            generateBitmapImage();
        }

        private void loadBitmap()
        {
            if (_bitmap != null) { _bitmap.Dispose(); }
            _bitmap = null;
            _bitmapImage = null;

            Bitmap bmp = MediaBitmap.fromFile(path);
            if (rotation % 360 != 0)
            {
                Bitmap rotated = MediaBitmap.rotate(bmp, (float)rotation, true);
                bmp.Dispose();
                _bitmap = rotated;
            }
            else
            {
                _bitmap = bmp;
            }
        }

        private void generateBitmapImage()
        {
            if (_bitmap == null) return;
            Bitmap tempBitmap = (Bitmap)_bitmap.Clone();

            for (int i = 0; i < items.Count; i++)
            {
                drawPoints(tempBitmap, items[i].getPoints(), (i+1).ToString());
                if (!items[i].hasBitmap()) {
                    items[i].setBitmap(this.getRectangle(items[i].getPoints()));
                }
            }

            drawPoints(tempBitmap, points);

            _bitmapImage = MediaImage.fromBitmap(tempBitmap);
            tempBitmap.Dispose();
            OnPropertyChanged("bitmapImage");
        }

        private void drawPoints(Bitmap bitmap, List<System.Windows.Point> points)
        {
            this.drawPoints(bitmap, points, "");
        }

        private void drawPoints(Bitmap bitmap, List<System.Windows.Point> points, string label) {
            int pointSize = (int)(0.01*(double)Math.Max(bitmap.Width, bitmap.Height));
            int penThickness = (int)Math.Ceiling((double)Math.Max(bitmap.Width, bitmap.Height)/(double)1000);
            Graphics g = Graphics.FromImage((System.Drawing.Image)bitmap);
            Point[] square = new Point[4];
            Point center = new Point(0, 0);

            for (int i = 0; i < Math.Min(points.Count, 4); i++)
            {
                Rectangle rect = new Rectangle((int)points[i].X - pointSize, (int)points[i].Y - pointSize, pointSize * 2, pointSize * 2);

                SolidBrush bgPointColor = new SolidBrush(Color.FromArgb(128, Color.Red));
                if (i == 0) bgPointColor = new SolidBrush(Color.FromArgb(128, Color.Blue));

                g.FillEllipse(bgPointColor, rect);

                Pen pen = new Pen(Color.FromArgb(128, Color.Black), penThickness);
                g.DrawEllipse(pen, rect);
                g.DrawLine(pen, (int)points[i].X, (int)points[i].Y - pointSize, (int)points[i].X, (int)points[i].Y + pointSize);
                g.DrawLine(pen, (int)points[i].X - pointSize, (int)points[i].Y, (int)points[i].X + pointSize, (int)points[i].Y);

                square[i] = new Point((int)points[i].X, (int)points[i].Y);
                center.X += (int)points[i].X;
                center.Y += (int)points[i].Y;
            }
            if (points.Count == 4)
            {
                center.X /= 4;
                center.Y /= 4;
                Font font = new Font(new FontFamily("Arial"), (float)(pointSize));

                g.FillPolygon(new SolidBrush(Color.FromArgb(128, Color.Black)), square);
                g.FillEllipse(new SolidBrush(Color.FromArgb(200, Color.White)), new Rectangle(center.X - pointSize, center.Y - pointSize, 2 * pointSize, 2 * pointSize));
                g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
                g.DrawString(label, font, Brushes.Black, new Point(center.X - (int)(font.Size / 2), center.Y - (int)(font.GetHeight(g) / 2)));
                
            }

            g.Dispose();
        }

        public void addPoint(System.Windows.Point pos)
        {
            if (_bitmap == null) return;
            pos.X *= _bitmap.Width;
            pos.Y *= _bitmap.Height;
            this.points.Add(pos);
            if (points.Count == 4)
            {
                ImageItem item = new ImageItem(points);
                item.setBitmap(this.getRectangle(points));
                points.Clear();
                items.Add(item);
                OnPropertyChanged("items");
            }
            generateBitmapImage();
        }

        private Bitmap getRectangle(List<System.Windows.Point>  points)
        {
            if(points.Count != 4) return null;
            if(_bitmap == null) return null;

            return MediaBitmap.extractRectangle(_bitmap, points[0], points[1], points[2], points[3]);
        }

    }
}
