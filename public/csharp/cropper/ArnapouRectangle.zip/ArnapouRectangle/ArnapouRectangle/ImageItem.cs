﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Diagnostics;
using System.Drawing;
using System.ComponentModel;
using System.Windows.Media.Imaging;
using System.Drawing.Imaging;
using System.Collections.ObjectModel;
using System.Threading;
using System.Windows.Threading;

namespace ArnapouRectangle
{

    public class ImageItem : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null) PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }

        private string _filename = "";
        public string filename
        {
            get { return _filename; }
            set { _filename = value; }
        }

        private List<System.Windows.Point> points = new List<System.Windows.Point>();

        private BitmapSource _bitmapSource = null;
        public BitmapSource bitmapSource {
            get { return _bitmapSource; }
            set { _bitmapSource = value; }        
        }

        public ImageItem(List<System.Windows.Point> points)
        {
            foreach (System.Windows.Point point in points)
            {
                this.points.Add(new System.Windows.Point(point.X, point.Y));
            }
        }

        public List<System.Windows.Point> getPoints() {
            return points;
        }

        public bool hasBitmap()
        {
            return _bitmapSource != null;
        }

        public void Dispose()
        {
            if (_bitmapSource != null)
            {
                _bitmapSource = null;
            }
        }

        public void saveTo(string folder, string basename) {
            string path = folder+"\\";
            if (filename.Trim() == "") path += basename;
            else path += filename.Trim();
            path += ".jpg";

            Bitmap bmp = MediaBitmap.fromBitmapSource(_bitmapSource);
            MediaBitmap.SaveJpeg(path, bmp, 98);
            bmp.Dispose();
        }

        public void setBitmap(Bitmap bitmap)
        {
            this.setBitmap(MediaImage.fromBitmap(bitmap));
        }

        public void setBitmap(BitmapSource bitmapSource)
        {
            this._bitmapSource = bitmapSource;
            OnPropertyChanged("bitmapSource");
        }

        public void rotatePoints90(int w, int h)
        {
            for (int i = 0; i < points.Count; i++)
            {
                points[i] = new System.Windows.Point((double)h - points[i].Y, points[i].X);
            }
        }


    }
}
