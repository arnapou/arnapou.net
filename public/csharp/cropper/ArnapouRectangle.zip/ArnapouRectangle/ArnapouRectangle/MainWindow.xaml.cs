﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Reflection;
using System.Text.RegularExpressions;

namespace ArnapouRectangle
{
    /// <summary>
    /// Logique d'interaction pour MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null) PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }


        private string configFile = "";

        private Image _selectedImage = null;
        public Image selectedImage
        {
            get { return _selectedImage; }
            set
            {
                if (_selectedImage != null)
                {
                    _selectedImage.unselectImage();
                }
                if (value == null || _selectedImage == null || value.path != _selectedImage.path)
                {
                    _selectedImage = value;
                    if (value != null)
                    {
                        value.selectImage();
                    }
                    OnPropertyChanged("selectedImage");
                }
                GC.Collect();
            }
        }

        private string _currentPath = "";
        public string currentPath
        {
            get { return _currentPath; }
            set
            {
                _currentPath = value;
                OnPropertyChanged("currentPath");
                this.refreshList();
            }
        }

        private ObservableCollection<Image> _images = new ObservableCollection<Image>();
        public ObservableCollection<Image> images { get { return _images; } }

        protected bool isValidPath()
        {
            if (Directory.Exists(this.currentPath))
            {
                textBoxPath.Foreground = Brushes.Black;
                return true;
            }
            else
            {
                textBoxPath.Foreground = Brushes.Red;
                return false;
            }
        }

        protected void refreshList()
        {
            _images.Clear();
            if (this.isValidPath())
            {
                Regex r = new Regex("\\.[0-9]+\\.jpg$", RegexOptions.IgnoreCase);
                string[] files = Directory.GetFiles(this.currentPath, "*.jpg", SearchOption.TopDirectoryOnly);
                Array.Sort<string>(files);
                foreach (string filename in files)
                {
                    if (!r.IsMatch(filename))
                    {
                        Image image = new Image(filename);
                        _images.Add(image);
                    }
                }
                if (selectedImage == null)
                {
                    if (_images.Count > 0) { selectedImage = _images[0]; }
                    else { selectedImage = null; }
                }
            }
            OnPropertyChanged("images");
        }
        public MainWindow()
        {
            InitializeComponent();
            this.DataContext = this;
            this.Loaded += new RoutedEventHandler(Window_Loaded);
            this.Closing+=new CancelEventHandler(Window_Closing);
        }


        private void buttonQuit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void buttonPrev_Click(object sender, RoutedEventArgs e)
        {
            if (images.Count > 1)
            {
                int i = images.IndexOf(selectedImage);
                if (i > 0)
                {
                    selectedImage = images[i - 1];
                    imagesList.ScrollIntoView(selectedImage);
                }
            }
        }

        private void buttonNext_Click(object sender, RoutedEventArgs e)
        {
            if (images.Count > 1)
            {
                int i = images.IndexOf(selectedImage);
                if (i < images.Count - 1)
                {
                    selectedImage = images[i + 1];
                    imagesList.ScrollIntoView(selectedImage);
                }
            }
        }

        private void buttonRefresh_Click(object sender, RoutedEventArgs e)
        {
            refreshList();
        }

        private void Window_Closing(object sender, CancelEventArgs e)
        {
            configSave();
        }

        private void configLoad()
        {
            if (File.Exists(configFile))
            {
                StreamReader stream = File.OpenText(configFile);
                string content = stream.ReadLine().Trim();
                stream.Close();
                currentPath = content;
            }
        }

        private void configSave()
        {
            if (configFile != "" && currentPath != "")
            {
                StreamWriter stream = new StreamWriter(configFile);
                stream.WriteLine(currentPath);
                stream.Close();
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            configFile = Directory.GetParent(Assembly.GetExecutingAssembly().Location) + "\\";
            configFile += System.IO.Path.GetFileNameWithoutExtension(Assembly.GetExecutingAssembly().Location);
            configFile += ".conf";
            configLoad();
        }

        private void Image_MouseUp(object sender, MouseButtonEventArgs e)
        {
            if (selectedImage == null) return;
            Point Pos = e.GetPosition((IInputElement)sender);
            System.Windows.Controls.Image image = (System.Windows.Controls.Image)sender;
            Pos.X = Pos.X / image.ActualWidth;
            Pos.Y = Pos.Y / image.ActualHeight;
            selectedImage.addPoint(Pos);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (selectedImage == null) return;
            Button button = sender as Button;
            if (button != null)
            {
                ImageItem item = button.DataContext as ImageItem;
                if (item != null)
                {
                    selectedImage.selectedItem = item;
                }
            }
            selectedImage.deleteCurrentItem();
        }


        private void buttonSave_Click(object sender, RoutedEventArgs e)
        {
            if (selectedImage == null) return;
            selectedImage.save();
        }

        private void buttonSaveAndNext_Click(object sender, RoutedEventArgs e)
        {
            buttonSave_Click(sender, e);
            buttonNext_Click(sender, e);
        }

        private void buttonRotate90_Click(object sender, RoutedEventArgs e)
        {
            if (selectedImage == null) return;
            selectedImage.rotate90();
        }
    }
}
