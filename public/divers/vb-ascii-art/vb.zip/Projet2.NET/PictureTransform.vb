Option Strict Off
Option Explicit On
Imports VB = Microsoft.VisualBasic
Friend Class frmProg
	Inherits System.Windows.Forms.Form
#Region "Windows Form Designer generated code "
	Public Sub New()
		MyBase.New()
		If m_vb6FormDefInstance Is Nothing Then
			If m_InitializingDefInstance Then
				m_vb6FormDefInstance = Me
			Else
				Try 
					'For the start-up form, the first instance created is the default instance.
					If System.Reflection.Assembly.GetExecutingAssembly.EntryPoint.DeclaringType Is Me.GetType Then
						m_vb6FormDefInstance = Me
					End If
				Catch
				End Try
			End If
		End If
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents txtResult As System.Windows.Forms.TextBox
	Public WithEvents frmResult As System.Windows.Forms.GroupBox
	Public WithEvents picImage As System.Windows.Forms.PictureBox
	Public WithEvents frmPic As System.Windows.Forms.GroupBox
	Public WithEvents cmdRefresh As System.Windows.Forms.Button
	Public WithEvents _picMenu_9 As System.Windows.Forms.Panel
	Public WithEvents _picMenu_8 As System.Windows.Forms.Panel
	Public WithEvents _picMenu_7 As System.Windows.Forms.Panel
	Public WithEvents _picMenu_6 As System.Windows.Forms.Panel
	Public WithEvents mvRight As System.Windows.Forms.Button
	Public WithEvents mvTop As System.Windows.Forms.Button
	Public WithEvents mvLeft As System.Windows.Forms.Button
	Public WithEvents mvBottom As System.Windows.Forms.Button
	Public WithEvents Union As System.Windows.Forms.CheckBox
	Public WithEvents Label4 As System.Windows.Forms.Label
	Public WithEvents _picMenu_5 As System.Windows.Forms.Panel
	Public WithEvents chkDouble As System.Windows.Forms.CheckBox
	Public WithEvents chkInverse As System.Windows.Forms.CheckBox
	Public WithEvents _txtDim_1 As System.Windows.Forms.TextBox
	Public WithEvents _Barre_1 As System.Windows.Forms.HScrollBar
	Public WithEvents _txtDim_0 As System.Windows.Forms.TextBox
	Public WithEvents _Barre_0 As System.Windows.Forms.HScrollBar
	Public WithEvents txtChar As System.Windows.Forms.TextBox
	Public WithEvents cmdClear As System.Windows.Forms.Button
	Public WithEvents _picMenu_2 As System.Windows.Forms.Panel
	Public WithEvents _picMenu_1 As System.Windows.Forms.Panel
	Public WithEvents _picMenu_4 As System.Windows.Forms.Panel
	Public WithEvents _picMenu_0 As System.Windows.Forms.Panel
	Public WithEvents _picMenu_3 As System.Windows.Forms.Panel
	Public WithEvents ColorDrawing As System.Windows.Forms.Label
	Public WithEvents Label6 As System.Windows.Forms.Label
	Public WithEvents Label5 As System.Windows.Forms.Label
	Public WithEvents Label3 As System.Windows.Forms.Label
	Public WithEvents Label2 As System.Windows.Forms.Label
	Public WithEvents Label1 As System.Windows.Forms.Label
	Public WithEvents ColorFill As System.Windows.Forms.Label
	Public WithEvents frmTools As System.Windows.Forms.GroupBox
	Public WithEvents cmdQuit As System.Windows.Forms.Button
	Public WithEvents Barre As Microsoft.VisualBasic.Compatibility.VB6.HScrollBarArray
	Public WithEvents picMenu As Microsoft.VisualBasic.Compatibility.VB6.PanelArray
	Public WithEvents txtDim As Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray
	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmProg))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.txtResult = New System.Windows.Forms.TextBox
        Me.picImage = New System.Windows.Forms.PictureBox
        Me._picMenu_9 = New System.Windows.Forms.Panel
        Me._picMenu_8 = New System.Windows.Forms.Panel
        Me._picMenu_7 = New System.Windows.Forms.Panel
        Me._picMenu_6 = New System.Windows.Forms.Panel
        Me.mvRight = New System.Windows.Forms.Button
        Me.mvTop = New System.Windows.Forms.Button
        Me.mvLeft = New System.Windows.Forms.Button
        Me.mvBottom = New System.Windows.Forms.Button
        Me.Union = New System.Windows.Forms.CheckBox
        Me._picMenu_5 = New System.Windows.Forms.Panel
        Me.Label4 = New System.Windows.Forms.Label
        Me.chkDouble = New System.Windows.Forms.CheckBox
        Me.chkInverse = New System.Windows.Forms.CheckBox
        Me._txtDim_1 = New System.Windows.Forms.TextBox
        Me._txtDim_0 = New System.Windows.Forms.TextBox
        Me.txtChar = New System.Windows.Forms.TextBox
        Me._picMenu_2 = New System.Windows.Forms.Panel
        Me._picMenu_1 = New System.Windows.Forms.Panel
        Me._picMenu_4 = New System.Windows.Forms.Panel
        Me._picMenu_0 = New System.Windows.Forms.Panel
        Me._picMenu_3 = New System.Windows.Forms.Panel
        Me.ColorDrawing = New System.Windows.Forms.Label
        Me.ColorFill = New System.Windows.Forms.Label
        Me.cmdQuit = New System.Windows.Forms.Button
        Me.frmResult = New System.Windows.Forms.GroupBox
        Me.frmPic = New System.Windows.Forms.GroupBox
        Me.frmTools = New System.Windows.Forms.GroupBox
        Me.cmdRefresh = New System.Windows.Forms.Button
        Me._Barre_1 = New System.Windows.Forms.HScrollBar
        Me._Barre_0 = New System.Windows.Forms.HScrollBar
        Me.cmdClear = New System.Windows.Forms.Button
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.Barre = New Microsoft.VisualBasic.Compatibility.VB6.HScrollBarArray(Me.components)
        Me.picMenu = New Microsoft.VisualBasic.Compatibility.VB6.PanelArray(Me.components)
        Me.txtDim = New Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray(Me.components)
        Me._picMenu_5.SuspendLayout()
        Me.frmResult.SuspendLayout()
        Me.frmPic.SuspendLayout()
        Me.frmTools.SuspendLayout()
        CType(Me.Barre, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picMenu, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtDim, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtResult
        '
        Me.txtResult.AcceptsReturn = True
        Me.txtResult.AutoSize = False
        Me.txtResult.BackColor = System.Drawing.Color.FromArgb(CType(240, Byte), CType(240, Byte), CType(240, Byte))
        Me.txtResult.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtResult.Font = New System.Drawing.Font("Courier New", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtResult.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtResult.Location = New System.Drawing.Point(80, 96)
        Me.txtResult.MaxLength = 0
        Me.txtResult.Multiline = True
        Me.txtResult.Name = "txtResult"
        Me.txtResult.ReadOnly = True
        Me.txtResult.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtResult.Size = New System.Drawing.Size(273, 257)
        Me.txtResult.TabIndex = 10
        Me.txtResult.Text = "Text1" & Microsoft.VisualBasic.ChrW(13) & Microsoft.VisualBasic.ChrW(10)
        Me.ToolTip1.SetToolTip(Me.txtResult, "R�sultat texte")
        '
        'picImage
        '
        Me.picImage.BackColor = System.Drawing.Color.FromArgb(CType(240, Byte), CType(240, Byte), CType(240, Byte))
        Me.picImage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.picImage.Cursor = System.Windows.Forms.Cursors.Default
        Me.picImage.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.picImage.ForeColor = System.Drawing.SystemColors.WindowText
        Me.picImage.Location = New System.Drawing.Point(16, 72)
        Me.picImage.Name = "picImage"
        Me.picImage.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.picImage.Size = New System.Drawing.Size(369, 273)
        Me.picImage.TabIndex = 8
        Me.ToolTip1.SetToolTip(Me.picImage, "Dessiner ici")
        '
        '_picMenu_9
        '
        Me._picMenu_9.BackColor = System.Drawing.SystemColors.Control
        Me._picMenu_9.BackgroundImage = CType(resources.GetObject("_picMenu_9.BackgroundImage"), System.Drawing.Image)
        Me._picMenu_9.Cursor = System.Windows.Forms.Cursors.Default
        Me._picMenu_9.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._picMenu_9.ForeColor = System.Drawing.SystemColors.ControlText
        Me.picMenu.SetIndex(Me._picMenu_9, CType(9, Short))
        Me._picMenu_9.Location = New System.Drawing.Point(144, 56)
        Me._picMenu_9.Name = "_picMenu_9"
        Me._picMenu_9.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._picMenu_9.Size = New System.Drawing.Size(25, 25)
        Me._picMenu_9.TabIndex = 33
        Me._picMenu_9.TabStop = True
        Me.ToolTip1.SetToolTip(Me._picMenu_9, "Rectangle rempli")
        '
        '_picMenu_8
        '
        Me._picMenu_8.BackColor = System.Drawing.SystemColors.Control
        Me._picMenu_8.BackgroundImage = CType(resources.GetObject("_picMenu_8.BackgroundImage"), System.Drawing.Image)
        Me._picMenu_8.Cursor = System.Windows.Forms.Cursors.Default
        Me._picMenu_8.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._picMenu_8.ForeColor = System.Drawing.SystemColors.ControlText
        Me.picMenu.SetIndex(Me._picMenu_8, CType(8, Short))
        Me._picMenu_8.Location = New System.Drawing.Point(112, 56)
        Me._picMenu_8.Name = "_picMenu_8"
        Me._picMenu_8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._picMenu_8.Size = New System.Drawing.Size(25, 25)
        Me._picMenu_8.TabIndex = 32
        Me._picMenu_8.TabStop = True
        Me.ToolTip1.SetToolTip(Me._picMenu_8, "Ellipse remplie")
        '
        '_picMenu_7
        '
        Me._picMenu_7.BackColor = System.Drawing.SystemColors.Control
        Me._picMenu_7.BackgroundImage = CType(resources.GetObject("_picMenu_7.BackgroundImage"), System.Drawing.Image)
        Me._picMenu_7.Cursor = System.Windows.Forms.Cursors.Default
        Me._picMenu_7.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._picMenu_7.ForeColor = System.Drawing.SystemColors.ControlText
        Me.picMenu.SetIndex(Me._picMenu_7, CType(7, Short))
        Me._picMenu_7.Location = New System.Drawing.Point(80, 56)
        Me._picMenu_7.Name = "_picMenu_7"
        Me._picMenu_7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._picMenu_7.Size = New System.Drawing.Size(25, 25)
        Me._picMenu_7.TabIndex = 31
        Me._picMenu_7.TabStop = True
        Me.ToolTip1.SetToolTip(Me._picMenu_7, "Cercle rempli")
        '
        '_picMenu_6
        '
        Me._picMenu_6.BackColor = System.Drawing.SystemColors.Control
        Me._picMenu_6.BackgroundImage = CType(resources.GetObject("_picMenu_6.BackgroundImage"), System.Drawing.Image)
        Me._picMenu_6.Cursor = System.Windows.Forms.Cursors.Default
        Me._picMenu_6.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._picMenu_6.ForeColor = System.Drawing.SystemColors.ControlText
        Me.picMenu.SetIndex(Me._picMenu_6, CType(6, Short))
        Me._picMenu_6.Location = New System.Drawing.Point(80, 24)
        Me._picMenu_6.Name = "_picMenu_6"
        Me._picMenu_6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._picMenu_6.Size = New System.Drawing.Size(25, 25)
        Me._picMenu_6.TabIndex = 30
        Me._picMenu_6.TabStop = True
        Me.ToolTip1.SetToolTip(Me._picMenu_6, "Cercle")
        '
        'mvRight
        '
        Me.mvRight.BackColor = System.Drawing.SystemColors.Control
        Me.mvRight.Cursor = System.Windows.Forms.Cursors.Default
        Me.mvRight.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mvRight.ForeColor = System.Drawing.SystemColors.ControlText
        Me.mvRight.Image = CType(resources.GetObject("mvRight.Image"), System.Drawing.Image)
        Me.mvRight.Location = New System.Drawing.Point(320, 40)
        Me.mvRight.Name = "mvRight"
        Me.mvRight.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.mvRight.Size = New System.Drawing.Size(25, 25)
        Me.mvRight.TabIndex = 29
        Me.mvRight.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.ToolTip1.SetToolTip(Me.mvRight, "D�place le dessin vers la droite")
        '
        'mvTop
        '
        Me.mvTop.BackColor = System.Drawing.SystemColors.Control
        Me.mvTop.Cursor = System.Windows.Forms.Cursors.Default
        Me.mvTop.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mvTop.ForeColor = System.Drawing.SystemColors.ControlText
        Me.mvTop.Image = CType(resources.GetObject("mvTop.Image"), System.Drawing.Image)
        Me.mvTop.Location = New System.Drawing.Point(296, 16)
        Me.mvTop.Name = "mvTop"
        Me.mvTop.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.mvTop.Size = New System.Drawing.Size(25, 25)
        Me.mvTop.TabIndex = 28
        Me.mvTop.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.ToolTip1.SetToolTip(Me.mvTop, "D�place le dessin vers le haut")
        '
        'mvLeft
        '
        Me.mvLeft.BackColor = System.Drawing.SystemColors.Control
        Me.mvLeft.Cursor = System.Windows.Forms.Cursors.Default
        Me.mvLeft.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mvLeft.ForeColor = System.Drawing.SystemColors.ControlText
        Me.mvLeft.Image = CType(resources.GetObject("mvLeft.Image"), System.Drawing.Image)
        Me.mvLeft.Location = New System.Drawing.Point(272, 40)
        Me.mvLeft.Name = "mvLeft"
        Me.mvLeft.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.mvLeft.Size = New System.Drawing.Size(25, 25)
        Me.mvLeft.TabIndex = 27
        Me.mvLeft.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.ToolTip1.SetToolTip(Me.mvLeft, "D�place le dessin vers la gauche")
        '
        'mvBottom
        '
        Me.mvBottom.BackColor = System.Drawing.SystemColors.Control
        Me.mvBottom.Cursor = System.Windows.Forms.Cursors.Default
        Me.mvBottom.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mvBottom.ForeColor = System.Drawing.SystemColors.ControlText
        Me.mvBottom.Image = CType(resources.GetObject("mvBottom.Image"), System.Drawing.Image)
        Me.mvBottom.Location = New System.Drawing.Point(296, 64)
        Me.mvBottom.Name = "mvBottom"
        Me.mvBottom.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.mvBottom.Size = New System.Drawing.Size(25, 25)
        Me.mvBottom.TabIndex = 26
        Me.mvBottom.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.ToolTip1.SetToolTip(Me.mvBottom, "D�place le dessin vers le bas")
        '
        'Union
        '
        Me.Union.BackColor = System.Drawing.SystemColors.Control
        Me.Union.Cursor = System.Windows.Forms.Cursors.Default
        Me.Union.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Union.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Union.Location = New System.Drawing.Point(456, 56)
        Me.Union.Name = "Union"
        Me.Union.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Union.Size = New System.Drawing.Size(65, 17)
        Me.Union.TabIndex = 25
        Me.Union.Text = "XOR"
        Me.ToolTip1.SetToolTip(Me.Union, "M�thode Xor sur les couleurs")
        '
        '_picMenu_5
        '
        Me._picMenu_5.BackColor = System.Drawing.SystemColors.Control
        Me._picMenu_5.BackgroundImage = CType(resources.GetObject("_picMenu_5.BackgroundImage"), System.Drawing.Image)
        Me._picMenu_5.Controls.Add(Me.Label4)
        Me._picMenu_5.Cursor = System.Windows.Forms.Cursors.Default
        Me._picMenu_5.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._picMenu_5.ForeColor = System.Drawing.SystemColors.ControlText
        Me.picMenu.SetIndex(Me._picMenu_5, CType(5, Short))
        Me._picMenu_5.Location = New System.Drawing.Point(176, 24)
        Me._picMenu_5.Name = "_picMenu_5"
        Me._picMenu_5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._picMenu_5.Size = New System.Drawing.Size(25, 25)
        Me._picMenu_5.TabIndex = 24
        Me._picMenu_5.TabStop = True
        Me.ToolTip1.SetToolTip(Me._picMenu_5, "Colorie")
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.SystemColors.Control
        Me.Label4.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label4.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label4.Location = New System.Drawing.Point(0, 24)
        Me.Label4.Name = "Label4"
        Me.Label4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label4.Size = New System.Drawing.Size(25, 1)
        Me.Label4.TabIndex = 34
        Me.Label4.Text = "Label4"
        '
        'chkDouble
        '
        Me.chkDouble.BackColor = System.Drawing.SystemColors.Control
        Me.chkDouble.Checked = True
        Me.chkDouble.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkDouble.Cursor = System.Windows.Forms.Cursors.Default
        Me.chkDouble.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkDouble.ForeColor = System.Drawing.SystemColors.ControlText
        Me.chkDouble.Location = New System.Drawing.Point(360, 56)
        Me.chkDouble.Name = "chkDouble"
        Me.chkDouble.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.chkDouble.Size = New System.Drawing.Size(65, 17)
        Me.chkDouble.TabIndex = 22
        Me.chkDouble.Text = "Double"
        Me.ToolTip1.SetToolTip(Me.chkDouble, "Double le caract�re")
        '
        'chkInverse
        '
        Me.chkInverse.BackColor = System.Drawing.SystemColors.Control
        Me.chkInverse.Cursor = System.Windows.Forms.Cursors.Default
        Me.chkInverse.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkInverse.ForeColor = System.Drawing.SystemColors.ControlText
        Me.chkInverse.Location = New System.Drawing.Point(456, 32)
        Me.chkInverse.Name = "chkInverse"
        Me.chkInverse.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.chkInverse.Size = New System.Drawing.Size(65, 17)
        Me.chkInverse.TabIndex = 20
        Me.chkInverse.Text = "Inverse"
        Me.ToolTip1.SetToolTip(Me.chkInverse, "Inverse les couleurs de dessin")
        '
        '_txtDim_1
        '
        Me._txtDim_1.AcceptsReturn = True
        Me._txtDim_1.AutoSize = False
        Me._txtDim_1.BackColor = System.Drawing.SystemColors.Window
        Me._txtDim_1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtDim_1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtDim_1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtDim.SetIndex(Me._txtDim_1, CType(1, Short))
        Me._txtDim_1.Location = New System.Drawing.Point(704, 56)
        Me._txtDim_1.MaxLength = 0
        Me._txtDim_1.Name = "_txtDim_1"
        Me._txtDim_1.ReadOnly = True
        Me._txtDim_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtDim_1.Size = New System.Drawing.Size(33, 19)
        Me._txtDim_1.TabIndex = 17
        Me._txtDim_1.Text = "dimY"
        Me._txtDim_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.ToolTip1.SetToolTip(Me._txtDim_1, "Nombre de cases verticales")
        '
        '_txtDim_0
        '
        Me._txtDim_0.AcceptsReturn = True
        Me._txtDim_0.AutoSize = False
        Me._txtDim_0.BackColor = System.Drawing.SystemColors.Window
        Me._txtDim_0.Cursor = System.Windows.Forms.Cursors.IBeam
        Me._txtDim_0.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._txtDim_0.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtDim.SetIndex(Me._txtDim_0, CType(0, Short))
        Me._txtDim_0.Location = New System.Drawing.Point(704, 32)
        Me._txtDim_0.MaxLength = 0
        Me._txtDim_0.Name = "_txtDim_0"
        Me._txtDim_0.ReadOnly = True
        Me._txtDim_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._txtDim_0.Size = New System.Drawing.Size(33, 19)
        Me._txtDim_0.TabIndex = 14
        Me._txtDim_0.Text = "dimX"
        Me._txtDim_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.ToolTip1.SetToolTip(Me._txtDim_0, "Nombre de cases horizontales")
        '
        'txtChar
        '
        Me.txtChar.AcceptsReturn = True
        Me.txtChar.AutoSize = False
        Me.txtChar.BackColor = System.Drawing.SystemColors.Window
        Me.txtChar.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtChar.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtChar.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtChar.Location = New System.Drawing.Point(360, 32)
        Me.txtChar.MaxLength = 2
        Me.txtChar.Name = "txtChar"
        Me.txtChar.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtChar.Size = New System.Drawing.Size(49, 19)
        Me.txtChar.TabIndex = 12
        Me.txtChar.Text = "Text1"
        Me.txtChar.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.ToolTip1.SetToolTip(Me.txtChar, "1 ou 2 caract�res")
        '
        '_picMenu_2
        '
        Me._picMenu_2.BackColor = System.Drawing.SystemColors.Control
        Me._picMenu_2.BackgroundImage = CType(resources.GetObject("_picMenu_2.BackgroundImage"), System.Drawing.Image)
        Me._picMenu_2.Cursor = System.Windows.Forms.Cursors.Default
        Me._picMenu_2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._picMenu_2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.picMenu.SetIndex(Me._picMenu_2, CType(2, Short))
        Me._picMenu_2.Location = New System.Drawing.Point(112, 24)
        Me._picMenu_2.Name = "_picMenu_2"
        Me._picMenu_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._picMenu_2.Size = New System.Drawing.Size(25, 25)
        Me._picMenu_2.TabIndex = 6
        Me._picMenu_2.TabStop = True
        Me.ToolTip1.SetToolTip(Me._picMenu_2, "Ellipse")
        '
        '_picMenu_1
        '
        Me._picMenu_1.BackColor = System.Drawing.SystemColors.Control
        Me._picMenu_1.BackgroundImage = CType(resources.GetObject("_picMenu_1.BackgroundImage"), System.Drawing.Image)
        Me._picMenu_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._picMenu_1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._picMenu_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.picMenu.SetIndex(Me._picMenu_1, CType(1, Short))
        Me._picMenu_1.Location = New System.Drawing.Point(48, 24)
        Me._picMenu_1.Name = "_picMenu_1"
        Me._picMenu_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._picMenu_1.Size = New System.Drawing.Size(25, 25)
        Me._picMenu_1.TabIndex = 5
        Me._picMenu_1.TabStop = True
        Me.ToolTip1.SetToolTip(Me._picMenu_1, "Ligne")
        '
        '_picMenu_4
        '
        Me._picMenu_4.BackColor = System.Drawing.SystemColors.Control
        Me._picMenu_4.BackgroundImage = CType(resources.GetObject("_picMenu_4.BackgroundImage"), System.Drawing.Image)
        Me._picMenu_4.Cursor = System.Windows.Forms.Cursors.Default
        Me._picMenu_4.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._picMenu_4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.picMenu.SetIndex(Me._picMenu_4, CType(4, Short))
        Me._picMenu_4.Location = New System.Drawing.Point(16, 56)
        Me._picMenu_4.Name = "_picMenu_4"
        Me._picMenu_4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._picMenu_4.Size = New System.Drawing.Size(25, 25)
        Me._picMenu_4.TabIndex = 4
        Me._picMenu_4.TabStop = True
        Me.ToolTip1.SetToolTip(Me._picMenu_4, "Gomme / Clic droit aussi")
        '
        '_picMenu_0
        '
        Me._picMenu_0.BackColor = System.Drawing.SystemColors.Control
        Me._picMenu_0.BackgroundImage = CType(resources.GetObject("_picMenu_0.BackgroundImage"), System.Drawing.Image)
        Me._picMenu_0.Cursor = System.Windows.Forms.Cursors.Default
        Me._picMenu_0.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._picMenu_0.ForeColor = System.Drawing.SystemColors.ControlText
        Me.picMenu.SetIndex(Me._picMenu_0, CType(0, Short))
        Me._picMenu_0.Location = New System.Drawing.Point(16, 24)
        Me._picMenu_0.Name = "_picMenu_0"
        Me._picMenu_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._picMenu_0.Size = New System.Drawing.Size(25, 25)
        Me._picMenu_0.TabIndex = 3
        Me._picMenu_0.TabStop = True
        Me.ToolTip1.SetToolTip(Me._picMenu_0, "Dessin libre")
        '
        '_picMenu_3
        '
        Me._picMenu_3.BackColor = System.Drawing.SystemColors.Control
        Me._picMenu_3.BackgroundImage = CType(resources.GetObject("_picMenu_3.BackgroundImage"), System.Drawing.Image)
        Me._picMenu_3.Cursor = System.Windows.Forms.Cursors.Default
        Me._picMenu_3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._picMenu_3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.picMenu.SetIndex(Me._picMenu_3, CType(3, Short))
        Me._picMenu_3.Location = New System.Drawing.Point(144, 24)
        Me._picMenu_3.Name = "_picMenu_3"
        Me._picMenu_3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._picMenu_3.Size = New System.Drawing.Size(25, 25)
        Me._picMenu_3.TabIndex = 2
        Me._picMenu_3.TabStop = True
        Me.ToolTip1.SetToolTip(Me._picMenu_3, "Rectangle")
        '
        'ColorDrawing
        '
        Me.ColorDrawing.BackColor = System.Drawing.SystemColors.Window
        Me.ColorDrawing.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ColorDrawing.Cursor = System.Windows.Forms.Cursors.Default
        Me.ColorDrawing.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ColorDrawing.ForeColor = System.Drawing.SystemColors.WindowText
        Me.ColorDrawing.Location = New System.Drawing.Point(176, 56)
        Me.ColorDrawing.Name = "ColorDrawing"
        Me.ColorDrawing.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ColorDrawing.Size = New System.Drawing.Size(17, 17)
        Me.ColorDrawing.TabIndex = 35
        Me.ToolTip1.SetToolTip(Me.ColorDrawing, "Couleur de dessin")
        '
        'ColorFill
        '
        Me.ColorFill.BackColor = System.Drawing.Color.FromArgb(CType(128, Byte), CType(128, Byte), CType(128, Byte))
        Me.ColorFill.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ColorFill.Cursor = System.Windows.Forms.Cursors.Default
        Me.ColorFill.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ColorFill.ForeColor = System.Drawing.SystemColors.WindowText
        Me.ColorFill.Location = New System.Drawing.Point(184, 64)
        Me.ColorFill.Name = "ColorFill"
        Me.ColorFill.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ColorFill.Size = New System.Drawing.Size(17, 17)
        Me.ColorFill.TabIndex = 36
        Me.ToolTip1.SetToolTip(Me.ColorFill, "Couleur de Coloriage")
        '
        'cmdQuit
        '
        Me.cmdQuit.BackColor = System.Drawing.SystemColors.Control
        Me.cmdQuit.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdQuit.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdQuit.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdQuit.Location = New System.Drawing.Point(784, 24)
        Me.cmdQuit.Name = "cmdQuit"
        Me.cmdQuit.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdQuit.Size = New System.Drawing.Size(49, 49)
        Me.cmdQuit.TabIndex = 0
        Me.cmdQuit.Text = "&Quitter"
        Me.ToolTip1.SetToolTip(Me.cmdQuit, "Quitter le programme")
        '
        'frmResult
        '
        Me.frmResult.BackColor = System.Drawing.SystemColors.Control
        Me.frmResult.Controls.Add(Me.txtResult)
        Me.frmResult.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.frmResult.ForeColor = System.Drawing.SystemColors.ControlText
        Me.frmResult.Location = New System.Drawing.Point(432, 176)
        Me.frmResult.Name = "frmResult"
        Me.frmResult.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.frmResult.Size = New System.Drawing.Size(400, 409)
        Me.frmResult.TabIndex = 9
        Me.frmResult.TabStop = False
        Me.frmResult.Text = "R�sultat sous forme de texte"
        '
        'frmPic
        '
        Me.frmPic.BackColor = System.Drawing.SystemColors.Control
        Me.frmPic.Controls.Add(Me.picImage)
        Me.frmPic.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.frmPic.ForeColor = System.Drawing.SystemColors.ControlText
        Me.frmPic.Location = New System.Drawing.Point(16, 169)
        Me.frmPic.Name = "frmPic"
        Me.frmPic.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.frmPic.Size = New System.Drawing.Size(400, 417)
        Me.frmPic.TabIndex = 7
        Me.frmPic.TabStop = False
        Me.frmPic.Text = "Aire de dessin"
        '
        'frmTools
        '
        Me.frmTools.BackColor = System.Drawing.SystemColors.Control
        Me.frmTools.Controls.Add(Me.cmdRefresh)
        Me.frmTools.Controls.Add(Me._picMenu_9)
        Me.frmTools.Controls.Add(Me._picMenu_8)
        Me.frmTools.Controls.Add(Me._picMenu_7)
        Me.frmTools.Controls.Add(Me._picMenu_6)
        Me.frmTools.Controls.Add(Me.mvRight)
        Me.frmTools.Controls.Add(Me.mvTop)
        Me.frmTools.Controls.Add(Me.mvLeft)
        Me.frmTools.Controls.Add(Me.mvBottom)
        Me.frmTools.Controls.Add(Me.Union)
        Me.frmTools.Controls.Add(Me._picMenu_5)
        Me.frmTools.Controls.Add(Me.chkDouble)
        Me.frmTools.Controls.Add(Me.chkInverse)
        Me.frmTools.Controls.Add(Me._txtDim_1)
        Me.frmTools.Controls.Add(Me._Barre_1)
        Me.frmTools.Controls.Add(Me._txtDim_0)
        Me.frmTools.Controls.Add(Me._Barre_0)
        Me.frmTools.Controls.Add(Me.txtChar)
        Me.frmTools.Controls.Add(Me.cmdClear)
        Me.frmTools.Controls.Add(Me._picMenu_2)
        Me.frmTools.Controls.Add(Me._picMenu_1)
        Me.frmTools.Controls.Add(Me._picMenu_4)
        Me.frmTools.Controls.Add(Me._picMenu_0)
        Me.frmTools.Controls.Add(Me._picMenu_3)
        Me.frmTools.Controls.Add(Me.ColorDrawing)
        Me.frmTools.Controls.Add(Me.Label6)
        Me.frmTools.Controls.Add(Me.Label5)
        Me.frmTools.Controls.Add(Me.Label3)
        Me.frmTools.Controls.Add(Me.Label2)
        Me.frmTools.Controls.Add(Me.Label1)
        Me.frmTools.Controls.Add(Me.ColorFill)
        Me.frmTools.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.frmTools.ForeColor = System.Drawing.SystemColors.ControlText
        Me.frmTools.Location = New System.Drawing.Point(16, 16)
        Me.frmTools.Name = "frmTools"
        Me.frmTools.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.frmTools.Size = New System.Drawing.Size(753, 97)
        Me.frmTools.TabIndex = 1
        Me.frmTools.TabStop = False
        Me.frmTools.Text = "Outils de dessin"
        '
        'cmdRefresh
        '
        Me.cmdRefresh.BackColor = System.Drawing.SystemColors.Control
        Me.cmdRefresh.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdRefresh.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdRefresh.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdRefresh.Location = New System.Drawing.Point(208, 24)
        Me.cmdRefresh.Name = "cmdRefresh"
        Me.cmdRefresh.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdRefresh.Size = New System.Drawing.Size(49, 25)
        Me.cmdRefresh.TabIndex = 37
        Me.cmdRefresh.Text = "Refresh"
        '
        '_Barre_1
        '
        Me._Barre_1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Barre.SetIndex(Me._Barre_1, CType(1, Short))
        Me._Barre_1.LargeChange = 1
        Me._Barre_1.Location = New System.Drawing.Point(592, 56)
        Me._Barre_1.Maximum = 50
        Me._Barre_1.Minimum = 10
        Me._Barre_1.Name = "_Barre_1"
        Me._Barre_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Barre_1.Size = New System.Drawing.Size(105, 17)
        Me._Barre_1.TabIndex = 16
        Me._Barre_1.TabStop = True
        Me._Barre_1.Value = 50
        '
        '_Barre_0
        '
        Me._Barre_0.Cursor = System.Windows.Forms.Cursors.Default
        Me.Barre.SetIndex(Me._Barre_0, CType(0, Short))
        Me._Barre_0.LargeChange = 1
        Me._Barre_0.Location = New System.Drawing.Point(592, 32)
        Me._Barre_0.Maximum = 50
        Me._Barre_0.Minimum = 10
        Me._Barre_0.Name = "_Barre_0"
        Me._Barre_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Barre_0.Size = New System.Drawing.Size(105, 17)
        Me._Barre_0.TabIndex = 13
        Me._Barre_0.TabStop = True
        Me._Barre_0.Value = 50
        '
        'cmdClear
        '
        Me.cmdClear.BackColor = System.Drawing.SystemColors.Control
        Me.cmdClear.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdClear.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdClear.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdClear.Location = New System.Drawing.Point(216, 56)
        Me.cmdClear.Name = "cmdClear"
        Me.cmdClear.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdClear.Size = New System.Drawing.Size(33, 25)
        Me.cmdClear.TabIndex = 11
        Me.cmdClear.Text = "cls"
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.SystemColors.Control
        Me.Label6.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label6.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label6.Location = New System.Drawing.Point(448, 13)
        Me.Label6.Name = "Label6"
        Me.Label6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label6.Size = New System.Drawing.Size(89, 17)
        Me.Label6.TabIndex = 23
        Me.Label6.Text = "Options de dessin"
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.SystemColors.Control
        Me.Label5.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label5.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label5.Location = New System.Drawing.Point(552, 13)
        Me.Label5.Name = "Label5"
        Me.Label5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label5.Size = New System.Drawing.Size(185, 17)
        Me.Label5.TabIndex = 21
        Me.Label5.Text = "Dimensions"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.SystemColors.Control
        Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label3.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label3.Location = New System.Drawing.Point(360, 13)
        Me.Label3.Name = "Label3"
        Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label3.Size = New System.Drawing.Size(57, 17)
        Me.Label3.TabIndex = 19
        Me.Label3.Text = "Charact�re"
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.SystemColors.Control
        Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label2.Location = New System.Drawing.Point(552, 56)
        Me.Label2.Name = "Label2"
        Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label2.Size = New System.Drawing.Size(33, 17)
        Me.Label2.TabIndex = 18
        Me.Label2.Text = "Vert."
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label1.Location = New System.Drawing.Point(552, 32)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(33, 17)
        Me.Label1.TabIndex = 15
        Me.Label1.Text = "Horiz."
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Barre
        '
        '
        'picMenu
        '
        '
        'frmProg
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(846, 602)
        Me.Controls.Add(Me.frmResult)
        Me.Controls.Add(Me.frmPic)
        Me.Controls.Add(Me.frmTools)
        Me.Controls.Add(Me.cmdQuit)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Location = New System.Drawing.Point(4, 23)
        Me.MinimizeBox = False
        Me.Name = "frmProg"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Petit Transformateur d'image en texte"
        Me._picMenu_5.ResumeLayout(False)
        Me.frmResult.ResumeLayout(False)
        Me.frmPic.ResumeLayout(False)
        Me.frmTools.ResumeLayout(False)
        CType(Me.Barre, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picMenu, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtDim, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
#End Region 
#Region "Upgrade Support "
	Private Shared m_vb6FormDefInstance As frmProg
	Private Shared m_InitializingDefInstance As Boolean
	Public Shared Property DefInstance() As frmProg
		Get
			If m_vb6FormDefInstance Is Nothing OrElse m_vb6FormDefInstance.IsDisposed Then
				m_InitializingDefInstance = True
				m_vb6FormDefInstance = New frmProg()
				m_InitializingDefInstance = False
			End If
			DefInstance = m_vb6FormDefInstance
		End Get
		Set
			m_vb6FormDefInstance = Value
		End Set
	End Property
#End Region 
	
	Const myLineColor As Integer = &H808080
	Const myColor As Integer = &H555555
	Const myBackColor As Integer = &HF0F0F0
	Dim ToolSelected As Integer
	
	Dim DrawColor As Boolean
	Dim FilledColor As Boolean
	Dim ToBeFilled As Boolean
	
	Dim WinHeight As Integer
	Dim WinWidth As Integer
	Dim WinTop As Integer
	Dim Border As Integer
	Dim MyChar As String
	Dim PicMaxDimX As Integer
	Dim PicMaxDimY As Integer
	
	Dim Y1, X1, X2, Y2 As Integer
	
	Dim MouseButton As Integer
	Dim GridX As Integer
	Dim GridY As Integer
	Dim GridPicture() As Boolean
	Dim GridEraser() As Boolean
	Dim GridTempo() As Boolean
	Dim GridFilled() As Boolean
	
	Dim ModeUnionIsXOR As Boolean
	Dim DoubleLesLettres As Boolean
	
	Dim ModeInverse As Boolean
	
	Private Function GetCoord(ByRef X As Integer, ByRef Y As Integer) As Integer
		Dim Length, Tmp As Object
		'UPGRADE_WARNING: Couldn't resolve default property of object Length. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		Length = VB6.PixelsToTwipsX(picImage.Width)
		'UPGRADE_WARNING: Couldn't resolve default property of object Length. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		'UPGRADE_WARNING: Couldn't resolve default property of object Tmp. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		Tmp = Length / GridX
		'UPGRADE_WARNING: Couldn't resolve default property of object Tmp. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		X = Fix(X / Tmp) + 1
		
		'UPGRADE_WARNING: Couldn't resolve default property of object Length. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		Length = VB6.PixelsToTwipsY(picImage.Height)
		'UPGRADE_WARNING: Couldn't resolve default property of object Length. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		'UPGRADE_WARNING: Couldn't resolve default property of object Tmp. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		Tmp = Length / GridY
		'UPGRADE_WARNING: Couldn't resolve default property of object Tmp. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		Y = Fix(Y / Tmp) + 1
		
	End Function
	
	Private Sub Colorie(ByVal X As Short, ByVal Y As Short, ByVal Color As Boolean)
		GridPicture(X, Y) = FilledColor Xor ModeInverse
		If X > 1 Then
			If GridPicture(X - 1, Y) = Color Then Colorie(X - 1, Y, Color)
		End If
		If X < GridX Then
			If GridPicture(X + 1, Y) = Color Then Colorie(X + 1, Y, Color)
		End If
		If Y > 1 Then
			If GridPicture(X, Y - 1) = Color Then Colorie(X, Y - 1, Color)
		End If
		If Y < GridY Then
			If GridPicture(X, Y + 1) = Color Then Colorie(X, Y + 1, Color)
		End If
	End Sub
	
	Private Sub DrawLigne(Optional ByVal ClearGrid As Boolean = True)
		Dim deltaY, Yfin, Y, X, Xfin, deltaX, delta As Object
		If ClearGrid Then ClearGridTempo()
		'UPGRADE_WARNING: Couldn't resolve default property of object X. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		X = X1
		'UPGRADE_WARNING: Couldn't resolve default property of object Y. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		Y = Y1
		'UPGRADE_WARNING: Couldn't resolve default property of object Xfin. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		Xfin = X2
		'UPGRADE_WARNING: Couldn't resolve default property of object Yfin. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		Yfin = Y2
		'UPGRADE_WARNING: Couldn't resolve default property of object X. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		'UPGRADE_WARNING: Couldn't resolve default property of object Xfin. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		'UPGRADE_WARNING: Couldn't resolve default property of object deltaX. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		deltaX = System.Math.Abs(Xfin - X)
		'UPGRADE_WARNING: Couldn't resolve default property of object Y. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		'UPGRADE_WARNING: Couldn't resolve default property of object Yfin. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		'UPGRADE_WARNING: Couldn't resolve default property of object deltaY. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		deltaY = System.Math.Abs(Yfin - Y)
		'UPGRADE_WARNING: Couldn't resolve default property of object Y. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		'UPGRADE_WARNING: Couldn't resolve default property of object X. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		StorePixelGridTempo(X, Y)
		If X1 <= X2 And Y1 <= Y2 Then ' 1er quadrant
			If X2 - X1 >= Y2 - Y1 Then ' en dessous 1ere bissectrice
				'UPGRADE_WARNING: Couldn't resolve default property of object deltaX. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				'UPGRADE_WARNING: Couldn't resolve default property of object deltaY. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				'UPGRADE_WARNING: Couldn't resolve default property of object delta. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				delta = 2 * deltaY - deltaX
				'UPGRADE_WARNING: Couldn't resolve default property of object Xfin. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				'UPGRADE_WARNING: Couldn't resolve default property of object X. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				While X <> Xfin
					'UPGRADE_WARNING: Couldn't resolve default property of object X. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					X = X + 1
					'UPGRADE_WARNING: Couldn't resolve default property of object delta. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					If delta > 0 Then
						'UPGRADE_WARNING: Couldn't resolve default property of object Y. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
						Y = Y + 1
						'UPGRADE_WARNING: Couldn't resolve default property of object deltaX. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
						'UPGRADE_WARNING: Couldn't resolve default property of object delta. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
						delta = delta - 2 * deltaX
					End If
					'UPGRADE_WARNING: Couldn't resolve default property of object deltaY. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					'UPGRADE_WARNING: Couldn't resolve default property of object delta. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					delta = delta + 2 * deltaY
					'UPGRADE_WARNING: Couldn't resolve default property of object Y. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					'UPGRADE_WARNING: Couldn't resolve default property of object X. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					StorePixelGridTempo(X, Y)
				End While
			Else ' en dessus 1ere bissectrice
				'UPGRADE_WARNING: Couldn't resolve default property of object deltaY. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				'UPGRADE_WARNING: Couldn't resolve default property of object deltaX. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				'UPGRADE_WARNING: Couldn't resolve default property of object delta. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				delta = 2 * deltaX - deltaY
				'UPGRADE_WARNING: Couldn't resolve default property of object Yfin. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				'UPGRADE_WARNING: Couldn't resolve default property of object Y. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				While Y <> Yfin
					'UPGRADE_WARNING: Couldn't resolve default property of object Y. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					Y = Y + 1
					'UPGRADE_WARNING: Couldn't resolve default property of object delta. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					If delta > 0 Then
						'UPGRADE_WARNING: Couldn't resolve default property of object X. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
						X = X + 1
						'UPGRADE_WARNING: Couldn't resolve default property of object deltaY. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
						'UPGRADE_WARNING: Couldn't resolve default property of object delta. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
						delta = delta - 2 * deltaY
					End If
					'UPGRADE_WARNING: Couldn't resolve default property of object deltaX. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					'UPGRADE_WARNING: Couldn't resolve default property of object delta. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					delta = delta + 2 * deltaX
					'UPGRADE_WARNING: Couldn't resolve default property of object Y. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					'UPGRADE_WARNING: Couldn't resolve default property of object X. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					StorePixelGridTempo(X, Y)
				End While
			End If
		End If
		If X1 > X2 And Y1 < Y2 Then ' 2e quadrant
			If X1 - X2 >= Y2 - Y1 Then ' en dessous 2e bissectrice
				'UPGRADE_WARNING: Couldn't resolve default property of object deltaX. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				'UPGRADE_WARNING: Couldn't resolve default property of object deltaY. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				'UPGRADE_WARNING: Couldn't resolve default property of object delta. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				delta = 2 * deltaY - deltaX
				'UPGRADE_WARNING: Couldn't resolve default property of object Xfin. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				'UPGRADE_WARNING: Couldn't resolve default property of object X. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				While X <> Xfin
					'UPGRADE_WARNING: Couldn't resolve default property of object X. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					X = X - 1
					'UPGRADE_WARNING: Couldn't resolve default property of object delta. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					If delta > 0 Then
						'UPGRADE_WARNING: Couldn't resolve default property of object Y. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
						Y = Y + 1
						'UPGRADE_WARNING: Couldn't resolve default property of object deltaX. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
						'UPGRADE_WARNING: Couldn't resolve default property of object delta. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
						delta = delta - 2 * deltaX
					End If
					'UPGRADE_WARNING: Couldn't resolve default property of object deltaY. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					'UPGRADE_WARNING: Couldn't resolve default property of object delta. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					delta = delta + 2 * deltaY
					'UPGRADE_WARNING: Couldn't resolve default property of object Y. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					'UPGRADE_WARNING: Couldn't resolve default property of object X. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					StorePixelGridTempo(X, Y)
				End While
			Else ' en dessus 2e bissectrice
				'UPGRADE_WARNING: Couldn't resolve default property of object deltaY. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				'UPGRADE_WARNING: Couldn't resolve default property of object deltaX. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				'UPGRADE_WARNING: Couldn't resolve default property of object delta. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				delta = 2 * deltaX - deltaY
				'UPGRADE_WARNING: Couldn't resolve default property of object Yfin. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				'UPGRADE_WARNING: Couldn't resolve default property of object Y. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				While Y <> Yfin
					'UPGRADE_WARNING: Couldn't resolve default property of object Y. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					Y = Y + 1
					'UPGRADE_WARNING: Couldn't resolve default property of object delta. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					If delta > 0 Then
						'UPGRADE_WARNING: Couldn't resolve default property of object X. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
						X = X - 1
						'UPGRADE_WARNING: Couldn't resolve default property of object deltaY. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
						'UPGRADE_WARNING: Couldn't resolve default property of object delta. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
						delta = delta - 2 * deltaY
					End If
					'UPGRADE_WARNING: Couldn't resolve default property of object deltaX. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					'UPGRADE_WARNING: Couldn't resolve default property of object delta. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					delta = delta + 2 * deltaX
					'UPGRADE_WARNING: Couldn't resolve default property of object Y. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					'UPGRADE_WARNING: Couldn't resolve default property of object X. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					StorePixelGridTempo(X, Y)
				End While
			End If
		End If
		If X1 >= X2 And Y1 >= Y2 Then ' 3e quadrant
			If X1 - X2 >= Y1 - Y2 Then ' en dessous 3e bissectrice
				'UPGRADE_WARNING: Couldn't resolve default property of object deltaX. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				'UPGRADE_WARNING: Couldn't resolve default property of object deltaY. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				'UPGRADE_WARNING: Couldn't resolve default property of object delta. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				delta = 2 * deltaY - deltaX
				'UPGRADE_WARNING: Couldn't resolve default property of object Xfin. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				'UPGRADE_WARNING: Couldn't resolve default property of object X. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				While X <> Xfin
					'UPGRADE_WARNING: Couldn't resolve default property of object X. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					X = X - 1
					'UPGRADE_WARNING: Couldn't resolve default property of object delta. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					If delta > 0 Then
						'UPGRADE_WARNING: Couldn't resolve default property of object Y. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
						Y = Y - 1
						'UPGRADE_WARNING: Couldn't resolve default property of object deltaX. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
						'UPGRADE_WARNING: Couldn't resolve default property of object delta. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
						delta = delta - 2 * deltaX
					End If
					'UPGRADE_WARNING: Couldn't resolve default property of object deltaY. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					'UPGRADE_WARNING: Couldn't resolve default property of object delta. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					delta = delta + 2 * deltaY
					'UPGRADE_WARNING: Couldn't resolve default property of object Y. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					'UPGRADE_WARNING: Couldn't resolve default property of object X. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					StorePixelGridTempo(X, Y)
				End While
			Else ' en dessus 3e bissectrice
				'UPGRADE_WARNING: Couldn't resolve default property of object deltaY. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				'UPGRADE_WARNING: Couldn't resolve default property of object deltaX. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				'UPGRADE_WARNING: Couldn't resolve default property of object delta. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				delta = 2 * deltaX - deltaY
				'UPGRADE_WARNING: Couldn't resolve default property of object Yfin. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				'UPGRADE_WARNING: Couldn't resolve default property of object Y. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				While Y <> Yfin
					'UPGRADE_WARNING: Couldn't resolve default property of object Y. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					Y = Y - 1
					'UPGRADE_WARNING: Couldn't resolve default property of object delta. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					If delta > 0 Then
						'UPGRADE_WARNING: Couldn't resolve default property of object X. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
						X = X - 1
						'UPGRADE_WARNING: Couldn't resolve default property of object deltaY. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
						'UPGRADE_WARNING: Couldn't resolve default property of object delta. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
						delta = delta - 2 * deltaY
					End If
					'UPGRADE_WARNING: Couldn't resolve default property of object deltaX. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					'UPGRADE_WARNING: Couldn't resolve default property of object delta. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					delta = delta + 2 * deltaX
					'UPGRADE_WARNING: Couldn't resolve default property of object Y. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					'UPGRADE_WARNING: Couldn't resolve default property of object X. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					StorePixelGridTempo(X, Y)
				End While
			End If
		End If
		If X1 < X2 And Y1 > Y2 Then ' 4er quadrant
			If X2 - X1 >= Y1 - Y2 Then ' en dessous 4ere bissectrice
				'UPGRADE_WARNING: Couldn't resolve default property of object deltaX. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				'UPGRADE_WARNING: Couldn't resolve default property of object deltaY. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				'UPGRADE_WARNING: Couldn't resolve default property of object delta. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				delta = 2 * deltaY - deltaX
				'UPGRADE_WARNING: Couldn't resolve default property of object Xfin. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				'UPGRADE_WARNING: Couldn't resolve default property of object X. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				While X <> Xfin
					'UPGRADE_WARNING: Couldn't resolve default property of object X. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					X = X + 1
					'UPGRADE_WARNING: Couldn't resolve default property of object delta. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					If delta > 0 Then
						'UPGRADE_WARNING: Couldn't resolve default property of object Y. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
						Y = Y - 1
						'UPGRADE_WARNING: Couldn't resolve default property of object deltaX. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
						'UPGRADE_WARNING: Couldn't resolve default property of object delta. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
						delta = delta - 2 * deltaX
					End If
					'UPGRADE_WARNING: Couldn't resolve default property of object deltaY. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					'UPGRADE_WARNING: Couldn't resolve default property of object delta. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					delta = delta + 2 * deltaY
					'UPGRADE_WARNING: Couldn't resolve default property of object Y. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					'UPGRADE_WARNING: Couldn't resolve default property of object X. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					StorePixelGridTempo(X, Y)
				End While
			Else ' en dessus 4ere bissectrice
				'UPGRADE_WARNING: Couldn't resolve default property of object deltaY. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				'UPGRADE_WARNING: Couldn't resolve default property of object deltaX. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				'UPGRADE_WARNING: Couldn't resolve default property of object delta. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				delta = 2 * deltaX - deltaY
				'UPGRADE_WARNING: Couldn't resolve default property of object Yfin. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				'UPGRADE_WARNING: Couldn't resolve default property of object Y. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				While Y <> Yfin
					'UPGRADE_WARNING: Couldn't resolve default property of object Y. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					Y = Y - 1
					'UPGRADE_WARNING: Couldn't resolve default property of object delta. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					If delta > 0 Then
						'UPGRADE_WARNING: Couldn't resolve default property of object X. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
						X = X + 1
						'UPGRADE_WARNING: Couldn't resolve default property of object deltaY. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
						'UPGRADE_WARNING: Couldn't resolve default property of object delta. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
						delta = delta - 2 * deltaY
					End If
					'UPGRADE_WARNING: Couldn't resolve default property of object deltaX. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					'UPGRADE_WARNING: Couldn't resolve default property of object delta. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					delta = delta + 2 * deltaX
					'UPGRADE_WARNING: Couldn't resolve default property of object Y. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					'UPGRADE_WARNING: Couldn't resolve default property of object X. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					StorePixelGridTempo(X, Y)
				End While
			End If
		End If
	End Sub
	
	Private Sub StorePixelGridEraser(ByVal X As Integer, ByVal Y As Integer)
		If X > 0 And X < GridX + 1 And Y > 0 And Y < GridY + 1 Then
			GridEraser(X, Y) = True
		End If
	End Sub
	
	Private Sub StorePixelGridTempo(ByVal X As Integer, ByVal Y As Integer)
		If X > 0 And X < GridX + 1 And Y > 0 And Y < GridY + 1 Then
			GridTempo(X, Y) = True
		End If
	End Sub
	
	Private Sub StorePixelGridFilled(ByVal X As Integer, ByVal Y As Integer)
		If X > 0 And X < GridX + 1 And Y > 0 And Y < GridY + 1 Then
			GridFilled(X, Y) = True
		End If
	End Sub
	
	Private Sub DrawRectangle()
        Dim i, tmpY2, tmpX2, tmpX1, tmpY1, Tmp, j As Integer
		'UPGRADE_WARNING: Couldn't resolve default property of object tmpX1. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		tmpX1 = X1
		'UPGRADE_WARNING: Couldn't resolve default property of object tmpX2. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		tmpX2 = X2
		'UPGRADE_WARNING: Couldn't resolve default property of object tmpY1. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		tmpY1 = Y1
		'UPGRADE_WARNING: Couldn't resolve default property of object tmpY2. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		tmpY2 = Y2
		If X1 > X2 Then
			'UPGRADE_WARNING: Couldn't resolve default property of object Tmp. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
			Tmp = X1
			X1 = X2
			'UPGRADE_WARNING: Couldn't resolve default property of object Tmp. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
			X2 = Tmp
		End If
		If Y1 > Y2 Then
			'UPGRADE_WARNING: Couldn't resolve default property of object Tmp. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
			Tmp = Y1
			Y1 = Y2
			'UPGRADE_WARNING: Couldn't resolve default property of object Tmp. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
			Y2 = Tmp
		End If
		ClearGridTempo()
		
		If ToBeFilled Then
			For i = X1 + 1 To X2 - 1
				For j = Y1 + 1 To Y2 - 1
					'UPGRADE_WARNING: Couldn't resolve default property of object j. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					'UPGRADE_WARNING: Couldn't resolve default property of object i. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					StorePixelGridFilled(i, j)
				Next 
			Next 
		End If
		
		'UPGRADE_WARNING: Couldn't resolve default property of object Tmp. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		Tmp = X2
		X2 = X1
		DrawLigne(False) ' fait un reset de la grille tempo
		'UPGRADE_WARNING: Couldn't resolve default property of object Tmp. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		X2 = Tmp
		
		'UPGRADE_WARNING: Couldn't resolve default property of object Tmp. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		Tmp = Y1
		Y1 = Y2
		DrawLigne(False)
		'UPGRADE_WARNING: Couldn't resolve default property of object Tmp. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		Y1 = Tmp
		
		'UPGRADE_WARNING: Couldn't resolve default property of object Tmp. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		Tmp = X1
		X1 = X2
		DrawLigne(False)
		'UPGRADE_WARNING: Couldn't resolve default property of object Tmp. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		X1 = Tmp
		
		'UPGRADE_WARNING: Couldn't resolve default property of object Tmp. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		Tmp = Y2
		Y2 = Y1
		DrawLigne(False)
		
		'UPGRADE_WARNING: Couldn't resolve default property of object tmpX1. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		X1 = tmpX1
		'UPGRADE_WARNING: Couldn't resolve default property of object tmpX2. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		X2 = tmpX2
		'UPGRADE_WARNING: Couldn't resolve default property of object tmpY1. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		Y1 = tmpY1
		'UPGRADE_WARNING: Couldn't resolve default property of object tmpY2. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		Y2 = tmpY2
	End Sub
	
	Private Sub DrawEllipse()
		Dim R As Integer
		Dim DeltaR1, DeltaR, DeltaR2 As Integer
		Dim X, Y As Integer
		ClearGridTempo()
		If System.Math.Abs(X2 - X1) > System.Math.Abs(Y2 - Y1) Then
			R = Fix((System.Math.Abs(X2 - X1) + 1) / 2)
		Else
			R = Fix((System.Math.Abs(Y2 - Y1) + 1) / 2) + 1
		End If
		DeltaR = 0
		X = R
		Y = 0
		TracePixelEllipse(R, 0, R)
		If ToBeFilled Then TraceBclPixelEllipse(R, 0, R)
		TracePixelEllipse(0, R, R)
		If ToBeFilled Then TraceBclPixelEllipse(0, R, R)
		If R > 0 Then
			While Y <= X
				DeltaR1 = DeltaR + 2 * Y - 2 * X + 2
				DeltaR2 = DeltaR + 2 * Y + 1
				If System.Math.Abs(DeltaR1) < System.Math.Abs(DeltaR2) Then
					DeltaR = DeltaR1
					Y = Y + 1
					X = X - 1
				Else
					DeltaR = DeltaR2
					Y = Y + 1
				End If
				TracePixelEllipse(X, Y, R)
				If ToBeFilled Then TraceBclPixelEllipse(X, Y, R)
				TracePixelEllipse(Y, X, R)
				If ToBeFilled Then TraceBclPixelEllipse(Y, X, R)
			End While
		End If
	End Sub
	
	Private Sub TraceBclPixelEllipse(ByVal X As Integer, ByVal Y As Integer, ByVal R As Integer)
		Dim i As Integer
		If Y <> R Then
			For i = 0 To X - 1
				TracePixelEllipse(i, Y, R)
			Next 
		End If
	End Sub
	
	Private Sub TracePixelEllipse(ByVal X As Integer, ByVal Y As Integer, ByVal R As Integer)
		Dim NewX, MilX, MilY, NewY As Single
		Dim ValX, ValY As Integer
		MilX = (X2 + X1) / 2
		MilY = (Y2 + Y1) / 2
		ValX = 0
		ValY = 0
		If R <> 0 Then
			NewX = Fix((System.Math.Abs(X2 - X1) + 1) * X / (2 * R))
			NewY = Fix((System.Math.Abs(Y2 - Y1) + 1) * Y / (2 * R))
			If (System.Math.Abs(X2 - X1) + 1) Mod 2 = 0 Then ValX = 1
			If (System.Math.Abs(Y2 - Y1) + 1) Mod 2 = 0 Then ValY = 1
			StorePixelGridTempo(Fix(MilX + NewX), Fix(MilY - NewY) + ValY)
			StorePixelGridTempo(Fix(MilX - NewX) + ValX, Fix(MilY - NewY) + ValY)
			StorePixelGridTempo(Fix(MilX + NewX), Fix(MilY + NewY))
			StorePixelGridTempo(Fix(MilX - NewX) + ValX, Fix(MilY + NewY))
		Else
			StorePixelGridTempo(X, Y)
		End If
	End Sub
	
	Private Sub TraceBclPixelCircle(ByVal X As Integer, ByVal Y As Integer, ByVal R As Integer)
		Dim i As Integer
		If Y <> R Then
			For i = 0 To X - 1
				StorePixelGridFilled(X1 + i, Y1 + Y)
				StorePixelGridFilled(X1 + i, Y1 - Y)
				StorePixelGridFilled(X1 - i, Y1 + Y)
				StorePixelGridFilled(X1 - i, Y1 - Y)
			Next 
		End If
	End Sub
	
	Private Sub TracePixelCircle(ByVal X As Integer, ByVal Y As Integer)
		StorePixelGridTempo(X1 + X, Y1 + Y)
		StorePixelGridTempo(X1 + X, Y1 - Y)
		StorePixelGridTempo(X1 - X, Y1 + Y)
		StorePixelGridTempo(X1 - X, Y1 - Y)
	End Sub
	
	Private Sub DrawCercle()
		Dim R As Integer
		Dim DeltaR1, DeltaR, DeltaR2 As Integer
		Dim X, Y As Integer
		ClearGridTempo()
		R = CInt(VB6.Format(System.Math.Sqrt((X1 - X2) ^ 2 + (Y1 - Y2) ^ 2)))
		DeltaR = 0
		X = R
		Y = 0
		TracePixelCircle(R, 0)
		If ToBeFilled Then TraceBclPixelCircle(R, 0, R)
		TracePixelCircle(0, R)
		If ToBeFilled Then TraceBclPixelCircle(0, R, R)
		If R > 0 Then
			While Y <= X
				DeltaR1 = DeltaR + 2 * Y - 2 * X + 2
				DeltaR2 = DeltaR + 2 * Y + 1
				If System.Math.Abs(DeltaR1) < System.Math.Abs(DeltaR2) Then
					DeltaR = DeltaR1
					Y = Y + 1
					X = X - 1
				Else
					DeltaR = DeltaR2
					Y = Y + 1
				End If
				TracePixelCircle(X, Y)
				If ToBeFilled Then TraceBclPixelCircle(X, Y, R)
				TracePixelCircle(Y, X)
				If ToBeFilled Then TraceBclPixelCircle(Y, X, R)
			End While
		End If
	End Sub
	
	'UPGRADE_NOTE: Barre.Change was changed from an event to a procedure. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2010"'
	'UPGRADE_WARNING: HScrollBar event Barre.Change has a new behavior. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2065"'
	Private Sub Barre_Change(ByRef Index As Short, ByVal newScrollValue As Integer)
		'UPGRADE_WARNING: Can't resolve the name of control Barre( Index ). Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2009"'
		txtDim(Index).Text = VB6.Format(Barre(Index).Value)
		'UPGRADE_WARNING: Can't resolve the name of control Barre( 1 ). Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2009"'
		'UPGRADE_WARNING: Can't resolve the name of control Barre( 0 ). Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2009"'
		PictureResize(Barre(0).Value, Barre(1).Value)
		DrawPicture()
	End Sub
	
	'UPGRADE_NOTE: Barre.Scroll was changed from an event to a procedure. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2010"'
	Private Sub Barre_Scroll_Renamed(ByRef Index As Short, ByVal newScrollValue As Integer)
		'UPGRADE_WARNING: Can't resolve the name of control Barre( Index ). Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2009"'
		txtDim(Index).Text = VB6.Format(Barre(Index).Value)
		'UPGRADE_WARNING: Can't resolve the name of control Barre( 1 ). Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2009"'
		'UPGRADE_WARNING: Can't resolve the name of control Barre( 0 ). Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2009"'
		PictureResize(Barre(0).Value, Barre(1).Value)
		DrawPicture()
	End Sub
	
	Private Sub StoreTempo()
		Dim Xdim, X, Y, Ydim As Object
		'UPGRADE_WARNING: Couldn't resolve default property of object Xdim. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		Xdim = (Barre(0).Maximum - Barre(0).LargeChange + 1)
		'UPGRADE_WARNING: Couldn't resolve default property of object Ydim. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		Ydim = (Barre(1).Maximum - Barre(1).LargeChange + 1)
		'UPGRADE_WARNING: Couldn't resolve default property of object Xdim. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		For X = 1 To Xdim
			'UPGRADE_WARNING: Couldn't resolve default property of object Ydim. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
			For Y = 1 To Ydim
				If WhichColor(X, Y) Then
					'UPGRADE_WARNING: Couldn't resolve default property of object Y. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					'UPGRADE_WARNING: Couldn't resolve default property of object X. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					GridPicture(X, Y) = Not (ModeInverse)
				Else
					'UPGRADE_WARNING: Couldn't resolve default property of object Y. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					'UPGRADE_WARNING: Couldn't resolve default property of object X. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					GridPicture(X, Y) = ModeInverse
				End If
			Next 
		Next 
		ClearGridTempo()
	End Sub
	
	Private Sub StoreEraser()
		Dim Xdim, X, Y, Ydim As Object
		'UPGRADE_WARNING: Couldn't resolve default property of object Xdim. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		Xdim = (Barre(0).Maximum - Barre(0).LargeChange + 1)
		'UPGRADE_WARNING: Couldn't resolve default property of object Ydim. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		Ydim = (Barre(1).Maximum - Barre(1).LargeChange + 1)
		'UPGRADE_WARNING: Couldn't resolve default property of object Xdim. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		For X = 1 To Xdim
			'UPGRADE_WARNING: Couldn't resolve default property of object Ydim. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
			For Y = 1 To Ydim
				'UPGRADE_WARNING: Couldn't resolve default property of object Y. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				'UPGRADE_WARNING: Couldn't resolve default property of object X. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				'UPGRADE_WARNING: Couldn't resolve default property of object Y. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				'UPGRADE_WARNING: Couldn't resolve default property of object X. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				If GridEraser(X, Y) Then GridPicture(X, Y) = False
			Next 
		Next 
	End Sub
	
	Private Sub ClearGridTempo()
        Dim Xdim, X, Y, Ydim As Integer
		'UPGRADE_WARNING: Couldn't resolve default property of object Xdim. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		Xdim = (Barre(0).Maximum - Barre(0).LargeChange + 1)
		'UPGRADE_WARNING: Couldn't resolve default property of object Ydim. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		Ydim = (Barre(1).Maximum - Barre(1).LargeChange + 1)
		'UPGRADE_WARNING: Couldn't resolve default property of object Xdim. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		For X = 1 To Xdim
			'UPGRADE_WARNING: Couldn't resolve default property of object Ydim. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
			For Y = 1 To Ydim
				'UPGRADE_WARNING: Couldn't resolve default property of object Y. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				'UPGRADE_WARNING: Couldn't resolve default property of object X. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				GridTempo(X, Y) = False
				'UPGRADE_WARNING: Couldn't resolve default property of object Y. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				'UPGRADE_WARNING: Couldn't resolve default property of object X. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				GridEraser(X, Y) = False
				'UPGRADE_WARNING: Couldn't resolve default property of object Y. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				'UPGRADE_WARNING: Couldn't resolve default property of object X. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				GridFilled(X, Y) = False
			Next 
		Next 
	End Sub
	
	Private Sub ClearGrid()
        Dim Xdim As Integer, X As Integer, Y As Integer, Ydim As Integer
		'UPGRADE_WARNING: Couldn't resolve default property of object Xdim. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		Xdim = (Barre(0).Maximum - Barre(0).LargeChange + 1)
		'UPGRADE_WARNING: Couldn't resolve default property of object Ydim. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		Ydim = (Barre(1).Maximum - Barre(1).LargeChange + 1)
		'UPGRADE_WARNING: Couldn't resolve default property of object Xdim. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		For X = 1 To Xdim
			'UPGRADE_WARNING: Couldn't resolve default property of object Ydim. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
			For Y = 1 To Ydim
				'UPGRADE_WARNING: Couldn't resolve default property of object Y. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				'UPGRADE_WARNING: Couldn't resolve default property of object X. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				GridTempo(X, Y) = False
				'UPGRADE_WARNING: Couldn't resolve default property of object Y. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				'UPGRADE_WARNING: Couldn't resolve default property of object X. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				GridEraser(X, Y) = False
				'UPGRADE_WARNING: Couldn't resolve default property of object Y. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				'UPGRADE_WARNING: Couldn't resolve default property of object X. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				GridPicture(X, Y) = False
				'UPGRADE_WARNING: Couldn't resolve default property of object Y. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				'UPGRADE_WARNING: Couldn't resolve default property of object X. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				GridFilled(X, Y) = False
			Next 
		Next 
	End Sub
	
	Private Sub ClearGridPicture()
        Dim Xdim As Integer, X As Integer, Y As Integer, Ydim As Object
		'UPGRADE_WARNING: Couldn't resolve default property of object Xdim. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		Xdim = (Barre(0).Maximum - Barre(0).LargeChange + 1)
		'UPGRADE_WARNING: Couldn't resolve default property of object Ydim. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		Ydim = (Barre(1).Maximum - Barre(1).LargeChange + 1)
		'UPGRADE_WARNING: Couldn't resolve default property of object Xdim. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		For X = 1 To Xdim
			'UPGRADE_WARNING: Couldn't resolve default property of object Ydim. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
			For Y = 1 To Ydim
				'UPGRADE_WARNING: Couldn't resolve default property of object Y. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				'UPGRADE_WARNING: Couldn't resolve default property of object X. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				GridPicture(X, Y) = False
			Next 
		Next 
	End Sub
	
	'UPGRADE_WARNING: Event chkDouble.CheckStateChanged may fire when form is initialized. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2075"'
	Private Sub chkDouble_CheckStateChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles chkDouble.CheckStateChanged
		If chkDouble.CheckState = System.Windows.Forms.CheckState.Checked Then
			DoubleLesLettres = True
			If Len(txtChar.Text) > 1 Then
				txtChar.Text = VB.Left(txtChar.Text, 1)
				txtChar_TextChanged(txtChar, New System.EventArgs())
			End If
		Else
			DoubleLesLettres = False
		End If
		ClearGridTempo()
		Transforme()
	End Sub
	
	'UPGRADE_WARNING: Event chkInverse.CheckStateChanged may fire when form is initialized. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2075"'
	Private Sub chkInverse_CheckStateChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles chkInverse.CheckStateChanged
		If chkInverse.CheckState = System.Windows.Forms.CheckState.Checked Then
			ModeInverse = True
		Else
			ModeInverse = False
		End If
		ClearGridTempo()
		DrawPicture()
	End Sub
	
	Private Sub cmdClear_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdClear.Click
		ClearGrid()
		'UPGRADE_WARNING: Can't resolve the name of control Barre( 1 ). Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2009"'
		'UPGRADE_WARNING: Can't resolve the name of control Barre( 0 ). Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2009"'
		PictureResize(Barre(0).Value, Barre(1).Value)
		ClearGridTempo()
		DrawPicture()
	End Sub
	
	Private Sub cmdQuit_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdQuit.Click
		frmProg.DefInstance.Close()
	End Sub
	
	Private Sub Transforme()
        Dim Y As Integer, X As Integer, txt As String
		'UPGRADE_WARNING: Couldn't resolve default property of object txt. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		txt = ""
		For Y = 1 To GridY
			For X = 1 To GridX
				If WhichColor(X, Y) Then
					'UPGRADE_WARNING: Couldn't resolve default property of object txt. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					txt = txt + MyChar
					'UPGRADE_WARNING: Couldn't resolve default property of object txt. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					If DoubleLesLettres Then txt = txt + MyChar
				Else
					'UPGRADE_WARNING: Couldn't resolve default property of object txt. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					txt = txt + " "
					'UPGRADE_WARNING: Couldn't resolve default property of object txt. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					If DoubleLesLettres Or Len(txtChar.Text) > 1 Then txt = txt + " "
				End If
			Next 
			'UPGRADE_WARNING: Couldn't resolve default property of object txt. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
			txt = txt + vbCrLf
		Next 
		'UPGRADE_WARNING: Couldn't resolve default property of object txt. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		txtResult.Text = txt
	End Sub
	
	Private Function WhichColor(ByVal i As Object, ByVal j As Object) As Boolean
		Dim CTmp, CFond, CFill As Object
		'UPGRADE_WARNING: Couldn't resolve default property of object j. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		'UPGRADE_WARNING: Couldn't resolve default property of object i. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		If GridEraser(i, j) Then
			WhichColor = ModeInverse
		Else
			If Not (ModeUnionIsXOR) Then
				'UPGRADE_WARNING: Couldn't resolve default property of object j. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				'UPGRADE_WARNING: Couldn't resolve default property of object i. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				If GridTempo(i, j) Then
					WhichColor = DrawColor
				Else
					'UPGRADE_WARNING: Couldn't resolve default property of object j. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					'UPGRADE_WARNING: Couldn't resolve default property of object i. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
					If GridFilled(i, j) Then
						WhichColor = FilledColor
					Else
						'UPGRADE_WARNING: Couldn't resolve default property of object j. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
						'UPGRADE_WARNING: Couldn't resolve default property of object i. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
						WhichColor = ModeInverse Xor GridPicture(i, j)
					End If
				End If
			Else
				'UPGRADE_WARNING: Couldn't resolve default property of object j. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				'UPGRADE_WARNING: Couldn't resolve default property of object i. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				'UPGRADE_WARNING: Couldn't resolve default property of object CFond. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				CFond = ModeInverse Xor GridPicture(i, j)
				'UPGRADE_WARNING: Couldn't resolve default property of object j. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				'UPGRADE_WARNING: Couldn't resolve default property of object i. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				'UPGRADE_WARNING: Couldn't resolve default property of object CTmp. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				CTmp = GridTempo(i, j) And DrawColor
				'UPGRADE_WARNING: Couldn't resolve default property of object j. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				'UPGRADE_WARNING: Couldn't resolve default property of object i. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				'UPGRADE_WARNING: Couldn't resolve default property of object CFill. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				CFill = GridFilled(i, j) And FilledColor
				'            WhichColor = Not (CFond) And (CTmp Or CFill) Or CFond And Not (CTmp Xor CFill)
				WhichColor = Not (CFond) And (CTmp Or CFill) Or CFond And Not (CTmp) And Not (CFill)
			End If
		End If
	End Function
	
	Private Sub DrawPicture()
		Dim tmpX1, tmpY1 As Integer
		Dim tmpX2, tmpY2 As Integer
		Dim j, i, Somme As Integer
		Dim Couleur As Boolean
		Dim picWidth, picHeight As Integer
		'UPGRADE_ISSUE: PictureBox method picImage.Cls was not upgraded. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2064"'
		picImage.Cls()
		Somme = 0
		For i = 1 To GridX
			For j = 1 To GridY
				If WhichColor(i, j) Then Somme = Somme + 1
			Next 
		Next 
		If Somme > GridX * GridY / 2 Then
			Couleur = False
			picImage.BackColor = System.Drawing.ColorTranslator.FromOle(myColor)
		Else
			Couleur = True
			picImage.BackColor = System.Drawing.ColorTranslator.FromOle(myBackColor)
		End If
		picWidth = VB6.PixelsToTwipsX(picImage.Width)
		picHeight = VB6.PixelsToTwipsY(picImage.Height)
		'dessine les cases en faisant l'union
		tmpX2 = 0
		For i = 1 To GridX
			tmpX1 = tmpX2
			tmpX2 = Fix(i * picWidth / GridX)
			tmpY2 = 0
			For j = 1 To GridY
				tmpY1 = tmpY2
				tmpY2 = Fix(j * picHeight / GridY)
				If WhichColor(i, j) = Couleur Then
					If Couleur Then
						'UPGRADE_ISSUE: PictureBox method picImage.Line was not upgraded. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2064"'
						picImage.Line (tmpX1, tmpY1) - (tmpX2, tmpY2), myColor, BF
					Else
						'UPGRADE_ISSUE: PictureBox method picImage.Line was not upgraded. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2064"'
						picImage.Line (tmpX1, tmpY1) - (tmpX2, tmpY2), myBackColor, BF
						
					End If
				End If
			Next 
		Next 
		
		'dessine la grille
		For i = 1 To GridY - 1
			tmpY1 = Fix(i * picHeight / GridY)
			'UPGRADE_ISSUE: PictureBox method picImage.Line was not upgraded. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2064"'
			picImage.Line (0, tmpY1) - (picWidth, tmpY1), myLineColor
		Next 
		For i = 1 To GridX - 1
			tmpX1 = Fix(i * picWidth / GridX)
			'UPGRADE_ISSUE: PictureBox method picImage.Line was not upgraded. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2064"'
			picImage.Line (tmpX1, 0) - (tmpX1, picHeight), myLineColor
		Next 
		Transforme()
	End Sub
	
	Private Sub PictureResize(ByVal dimX As Integer, ByVal dimY As Integer)
		Dim rapInit, rapCurrent As Single
		Dim dimWidth, dimHeight As Integer
		Dim tmpX, tmpY As Integer
		Dim i, j As Integer
		If GridX < dimX Then
			For i = GridX + 1 To dimX
				For j = 1 To dimY
					GridPicture(i, j) = ModeInverse
					GridTempo(i, j) = False
				Next 
			Next 
		End If
		If GridY < dimY Then
			For i = 1 To dimX
				For j = GridY + 1 To dimY
					GridPicture(i, j) = ModeInverse
					GridTempo(i, j) = False
				Next 
			Next 
		End If
		GridX = dimX
		GridY = dimY
		'redimensionne la grille
		'UPGRADE_ISSUE: PictureBox method picImage.Cls was not upgraded. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2064"'
		picImage.Cls()
		rapInit = PicMaxDimX / PicMaxDimY
		rapCurrent = dimX / dimY
		If rapInit > rapCurrent Then ' c'est en y qu'il faut fixer le max
			dimHeight = PicMaxDimY
			dimWidth = dimHeight * rapCurrent
		Else
			dimWidth = PicMaxDimX
			dimHeight = dimWidth / rapCurrent
		End If
		tmpX = (VB6.PixelsToTwipsX(frmPic.Width) - dimWidth) / 2
		tmpY = (VB6.PixelsToTwipsY(frmPic.Height) - dimHeight) / 2
		picImage.SetBounds(VB6.TwipsToPixelsX(tmpX), VB6.TwipsToPixelsY(tmpY), VB6.TwipsToPixelsX(dimWidth), VB6.TwipsToPixelsY(dimHeight))
	End Sub
	
	Private Sub cmdRefresh_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdRefresh.Click
		DrawPicture()
	End Sub
	
	Private Sub ColorDrawing_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles ColorDrawing.Click
		DrawColor = Not (DrawColor)
		If DrawColor Then
			ColorDrawing.BackColor = System.Drawing.ColorTranslator.FromOle(myColor)
		Else
			ColorDrawing.BackColor = System.Drawing.Color.White
		End If
	End Sub
	
	Private Sub ColorFill_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles ColorFill.Click
		FilledColor = Not (FilledColor)
		If FilledColor Then
			ColorFill.BackColor = System.Drawing.ColorTranslator.FromOle(myColor)
		Else
			ColorFill.BackColor = System.Drawing.Color.White
		End If
	End Sub
	
	Private Sub frmProg_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
		Border = 250
		WinHeight = VB6.PixelsToTwipsY(frmProg.DefInstance.Height)
		WinWidth = VB6.PixelsToTwipsX(frmProg.DefInstance.Width)
		WinTop = VB6.PixelsToTwipsY(frmTools.Top) + Border + VB6.PixelsToTwipsY(frmTools.Height)
		picImage.SetBounds(VB6.TwipsToPixelsX(Border), VB6.TwipsToPixelsY(Border * 1.5), VB6.TwipsToPixelsX(VB6.PixelsToTwipsX(frmPic.Width) - 2 * Border), VB6.TwipsToPixelsY(VB6.PixelsToTwipsY(frmPic.Height) - 2.5 * Border))
		PicMaxDimX = VB6.PixelsToTwipsX(picImage.Width)
		PicMaxDimY = VB6.PixelsToTwipsY(picImage.Height)
		
		ModeInverse = False
		ModeUnionIsXOR = False
		DoubleLesLettres = True
		MouseButton = 0
		ColorDrawing.BackColor = System.Drawing.ColorTranslator.FromOle(myColor)
		ColorFill.BackColor = System.Drawing.Color.White
		DrawColor = False
		FilledColor = True
		ToBeFilled = False
		ColorDrawing_Click(ColorDrawing, New System.EventArgs())
		ColorFill_Click(ColorFill, New System.EventArgs())
		
		Dim Xdim, Ydim As Object
		'UPGRADE_WARNING: Couldn't resolve default property of object Xdim. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		Xdim = (Barre(0).Maximum - Barre(0).LargeChange + 1)
		'UPGRADE_WARNING: Couldn't resolve default property of object Ydim. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		Ydim = (Barre(1).Maximum - Barre(1).LargeChange + 1)
		'UPGRADE_WARNING: Lower bound of array GridPicture was changed from 1,1 to 0,0. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1033"'
		'UPGRADE_WARNING: Couldn't resolve default property of object Ydim. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		'UPGRADE_WARNING: Couldn't resolve default property of object Xdim. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		ReDim GridPicture(Xdim, Ydim)
		'UPGRADE_WARNING: Lower bound of array GridTempo was changed from 1,1 to 0,0. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1033"'
		'UPGRADE_WARNING: Couldn't resolve default property of object Ydim. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		'UPGRADE_WARNING: Couldn't resolve default property of object Xdim. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		ReDim GridTempo(Xdim, Ydim)
		'UPGRADE_WARNING: Lower bound of array GridEraser was changed from 1,1 to 0,0. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1033"'
		'UPGRADE_WARNING: Couldn't resolve default property of object Ydim. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		'UPGRADE_WARNING: Couldn't resolve default property of object Xdim. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		ReDim GridEraser(Xdim, Ydim)
		'UPGRADE_WARNING: Lower bound of array GridFilled was changed from 1,1 to 0,0. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1033"'
		'UPGRADE_WARNING: Couldn't resolve default property of object Ydim. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		'UPGRADE_WARNING: Couldn't resolve default property of object Xdim. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		ReDim GridFilled(Xdim, Ydim)
		
		picMenu_Click(picMenu.Item(0), New System.EventArgs())
		txtChar.Text = ""
		txtResult.Text = ""
		Barre(0).Value = 20
		Barre(1).Value = 20
		'UPGRADE_WARNING: Can't resolve the name of control Barre( 0 ). Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2009"'
		txtDim(0).Text = VB6.Format(Barre(0).Value)
		'UPGRADE_WARNING: Can't resolve the name of control Barre( 1 ). Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2009"'
		txtDim(1).Text = VB6.Format(Barre(1).Value)
		txtChar.Text = "#"
		MyChar = txtChar.Text
		'UPGRADE_WARNING: Can't resolve the name of control Barre( 1 ). Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2009"'
		'UPGRADE_WARNING: Can't resolve the name of control Barre( 0 ). Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2009"'
		PictureResize(Barre(0).Value, Barre(1).Value)
		Call cmdClear_Click(cmdClear, New System.EventArgs())
	End Sub
	
	'UPGRADE_WARNING: Event frmProg.Resize may fire when form is initialized. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2075"'
	Private Sub frmProg_Resize(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Resize
		Dim dessY, dessX, newBorder As Object
		If VB6.PixelsToTwipsX(frmProg.DefInstance.Width) < WinWidth Or VB6.PixelsToTwipsY(frmProg.DefInstance.Height) < WinHeight Then
			frmProg.DefInstance.Width = VB6.TwipsToPixelsX(WinWidth)
			frmProg.DefInstance.Height = VB6.TwipsToPixelsY(WinHeight)
		End If
		
		'UPGRADE_WARNING: Couldn't resolve default property of object newBorder. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		newBorder = 1 * Border
		'UPGRADE_WARNING: Couldn't resolve default property of object newBorder. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		'UPGRADE_WARNING: Couldn't resolve default property of object dessX. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		dessX = (VB6.PixelsToTwipsX(frmProg.DefInstance.Width) - 3 * newBorder) / 2
		'UPGRADE_WARNING: Couldn't resolve default property of object newBorder. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		'UPGRADE_WARNING: Couldn't resolve default property of object dessY. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		dessY = VB6.PixelsToTwipsY(frmProg.DefInstance.Height) - 2 * newBorder - WinTop
		
		'UPGRADE_WARNING: Couldn't resolve default property of object newBorder. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		'UPGRADE_WARNING: Couldn't resolve default property of object dessX. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
		frmResult.SetBounds(VB6.TwipsToPixelsX(dessX + 2 * newBorder), VB6.TwipsToPixelsY(WinTop), VB6.TwipsToPixelsX(dessX), VB6.TwipsToPixelsY(dessY))
		frmPic.SetBounds(VB6.TwipsToPixelsX(newBorder), VB6.TwipsToPixelsY(WinTop), VB6.TwipsToPixelsX(dessX), VB6.TwipsToPixelsY(dessY))
		
		
		PicMaxDimX = VB6.PixelsToTwipsX(frmPic.Width) - 2 * Border
		PicMaxDimY = VB6.PixelsToTwipsY(frmPic.Height) - 2.5 * Border
		txtResult.SetBounds(VB6.TwipsToPixelsX(Border), VB6.TwipsToPixelsY(Border * 1.5), VB6.TwipsToPixelsX(VB6.PixelsToTwipsX(frmResult.Width) - 2 * Border), VB6.TwipsToPixelsY(VB6.PixelsToTwipsY(frmResult.Height) - 2.5 * Border))
		'UPGRADE_WARNING: Can't resolve the name of control Barre( 1 ). Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2009"'
		'UPGRADE_WARNING: Can't resolve the name of control Barre( 0 ). Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2009"'
		PictureResize(Barre(0).Value, Barre(1).Value)
		DrawPicture()
	End Sub
	
	
	
	Private Sub mvBottom_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mvBottom.Click
		Dim X, Y As Object
		For Y = GridY To 2 Step -1
			For X = 1 To GridX
				'UPGRADE_WARNING: Couldn't resolve default property of object Y. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				'UPGRADE_WARNING: Couldn't resolve default property of object X. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				GridPicture(X, Y) = GridPicture(X, Y - 1)
			Next 
		Next 
		For X = 1 To GridX
			'UPGRADE_WARNING: Couldn't resolve default property of object X. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
			GridPicture(X, 1) = ModeInverse
		Next 
		DrawPicture()
	End Sub
	
	Private Sub mvLeft_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mvLeft.Click
		Dim X, Y As Object
		For X = 1 To GridX - 1
			For Y = 1 To GridY
				'UPGRADE_WARNING: Couldn't resolve default property of object Y. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				'UPGRADE_WARNING: Couldn't resolve default property of object X. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				GridPicture(X, Y) = GridPicture(X + 1, Y)
			Next 
		Next 
		For Y = 1 To GridY
			'UPGRADE_WARNING: Couldn't resolve default property of object Y. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
			GridPicture(GridX, Y) = ModeInverse
		Next 
		DrawPicture()
	End Sub
	
	Private Sub mvRight_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mvRight.Click
		Dim X, Y As Object
		For X = GridX To 2 Step -1
			For Y = 1 To GridY
				'UPGRADE_WARNING: Couldn't resolve default property of object Y. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				'UPGRADE_WARNING: Couldn't resolve default property of object X. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				GridPicture(X, Y) = GridPicture(X - 1, Y)
			Next 
		Next 
		For Y = 1 To GridY
			'UPGRADE_WARNING: Couldn't resolve default property of object Y. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
			GridPicture(1, Y) = ModeInverse
		Next 
		DrawPicture()
	End Sub
	
	Private Sub mvTop_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mvTop.Click
		Dim X, Y As Object
		For Y = 1 To GridY - 1
			For X = 1 To GridX
				'UPGRADE_WARNING: Couldn't resolve default property of object Y. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				'UPGRADE_WARNING: Couldn't resolve default property of object X. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
				GridPicture(X, Y) = GridPicture(X, Y + 1)
			Next 
		Next 
		For X = 1 To GridX
			'UPGRADE_WARNING: Couldn't resolve default property of object X. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
			GridPicture(X, GridY) = ModeInverse
		Next 
		DrawPicture()
	End Sub
	
	Private Sub picImage_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles picImage.Click
		Select Case ToolSelected
			Case 0 ' pinceau
			Case 1 ' ligne
			Case 2 ' ellipse
			Case 3 ' rect
			Case 4 ' eraser
			Case 5 ' fill
			Case 6 ' cercle
			Case 7 ' cercle plein
			Case 8 ' ellipse pleine
			Case 9 ' rectangle plein
		End Select
	End Sub
	
	Private Sub picImage_MouseDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.MouseEventArgs) Handles picImage.MouseDown
		Dim Button As Short = eventArgs.Button \ &H100000
		Dim Shift As Short = System.Windows.Forms.Control.ModifierKeys \ &H10000
		Dim X As Single = VB6.PixelsToTwipsX(eventArgs.X)
		Dim Y As Single = VB6.PixelsToTwipsY(eventArgs.Y)
		X1 = X
		Y1 = Y
		GetCoord(X1, Y1)
		If Button = 1 Then
			Select Case ToolSelected
				Case 0 ' pinceau
					StorePixelGridTempo(X1, Y1)
					DrawPicture()
				Case 1 ' ligne
					X2 = X1
					Y2 = Y1
					DrawLigne()
					DrawPicture()
				Case 2, 8 ' ellipse (et colori�e)
					X2 = X1
					Y2 = Y1
					DrawEllipse()
					DrawPicture()
				Case 3, 9 ' rect (et colori�)
					X2 = X1
					Y2 = Y1
					DrawRectangle()
					DrawPicture()
				Case 4 ' eraser
					StorePixelGridEraser(X1, Y1)
					DrawPicture()
				Case 5 ' fill
				Case 6, 7 ' cercle (et colori�)
					X2 = X1
					Y2 = Y1
					DrawCercle()
					DrawPicture()
			End Select
		End If
		If Button = 2 Then
			StorePixelGridEraser(X1, Y1)
			DrawPicture()
		End If
	End Sub
	
	Private Sub picImage_MouseMove(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.MouseEventArgs) Handles picImage.MouseMove
		Dim Button As Short = eventArgs.Button \ &H100000
		Dim Shift As Short = System.Windows.Forms.Control.ModifierKeys \ &H10000
		Dim X As Single = VB6.PixelsToTwipsX(eventArgs.X)
		Dim Y As Single = VB6.PixelsToTwipsY(eventArgs.Y)
		Dim tmpX, tmpY As Integer
		tmpX = X
		tmpY = Y
		GetCoord(tmpX, tmpY)
		If tmpX <> X2 Or tmpY <> Y2 Then
			X2 = tmpX
			Y2 = tmpY
			If Button = 1 Then
				Select Case ToolSelected
					Case 0 ' pinceau
						StorePixelGridTempo(tmpX, tmpY)
						DrawPicture()
					Case 1 ' ligne
						DrawLigne()
						DrawPicture()
					Case 2, 8 ' ellipse (et colori�e)
						DrawEllipse()
						DrawPicture()
					Case 3, 9 ' rect  (et colori�)
						DrawRectangle()
						DrawPicture()
					Case 4 ' eraser
						StorePixelGridEraser(X2, Y2)
						DrawPicture()
					Case 5 ' fill
					Case 6, 7 ' cercle (et colori�)
						DrawCercle()
						DrawPicture()
				End Select
			End If
			If Button = 2 Then
				StorePixelGridEraser(X2, Y2)
				DrawPicture()
			End If
		End If
	End Sub
	
	Private Sub picImage_MouseUp(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.MouseEventArgs) Handles picImage.MouseUp
		Dim Button As Short = eventArgs.Button \ &H100000
		Dim Shift As Short = System.Windows.Forms.Control.ModifierKeys \ &H10000
		Dim X As Single = VB6.PixelsToTwipsX(eventArgs.X)
		Dim Y As Single = VB6.PixelsToTwipsY(eventArgs.Y)
		X2 = X
		Y2 = Y
		GetCoord(X2, Y2)
		If Button = 1 Then
			Select Case ToolSelected
				Case 0 ' pinceau
					StorePixelGridTempo(X2, Y2)
					StoreTempo()
					DrawPicture()
				Case 1 ' ligne
					DrawLigne()
					StoreTempo()
					DrawPicture()
				Case 2, 8 ' ellipse (et colori�e)
					DrawEllipse()
					StoreTempo()
					DrawPicture()
				Case 3, 9 ' rect (et colori�)
					DrawRectangle()
					StoreTempo()
					DrawPicture()
				Case 4 ' eraser
					StorePixelGridEraser(X2, Y2)
					StoreEraser()
					DrawPicture()
				Case 5 ' fill
					If X1 = X2 And Y1 = Y2 Then
						If GridPicture(X1, Y1) <> (FilledColor Xor ModeInverse) Then
							Colorie(X1, Y1, GridPicture(X1, Y1))
						End If
						DrawPicture()
					End If
				Case 6, 7 ' cercle (et colori�)
					DrawCercle()
					StoreTempo()
					DrawPicture()
			End Select
		End If
		If Button = 2 Then
			StorePixelGridEraser(X2, Y2)
			StoreEraser()
			DrawPicture()
		End If
	End Sub
	
	Private Sub picMenu_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles picMenu.Click
		Dim Index As Short = picMenu.GetIndex(eventSender)
		Dim i As Object
		For i = 0 To 9
			'UPGRADE_WARNING: Couldn't resolve default property of object i. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
			If Index <> i Then
				picMenu(i).BorderStyle = System.Windows.Forms.BorderStyle.None ' None
			Else
				picMenu(i).BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D ' Fixed Single
			End If
		Next 
		ToBeFilled = False
		If Index >= 7 And Index <= 9 Then ToBeFilled = True
		ToolSelected = Index
	End Sub
	
	'UPGRADE_WARNING: Event txtChar.TextChanged may fire when form is initialized. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2075"'
	Private Sub txtChar_TextChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtChar.TextChanged
		MyChar = txtChar.Text
		If Len(MyChar) = 2 Then
			chkDouble.CheckState = System.Windows.Forms.CheckState.Unchecked
			DoubleLesLettres = False
		End If
		Transforme()
	End Sub
	
	'UPGRADE_WARNING: Event union.CheckStateChanged may fire when form is initialized. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2075"'
	Private Sub union_CheckStateChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles union.CheckStateChanged
		If Union.CheckState = System.Windows.Forms.CheckState.Checked Then
			ModeUnionIsXOR = True
		Else
			ModeUnionIsXOR = False
		End If
	End Sub
	Private Sub Barre_Scroll(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.ScrollEventArgs) Handles Barre.Scroll
		Dim Index As Short = Barre.GetIndex(eventSender)
		Select Case eventArgs.type
			Case System.Windows.Forms.ScrollEventType.ThumbTrack
				Barre_Scroll_Renamed(Index, eventArgs.newValue)
			Case System.Windows.Forms.ScrollEventType.EndScroll
				Barre_Change(Index, eventArgs.newValue)
		End Select
	End Sub


End Class