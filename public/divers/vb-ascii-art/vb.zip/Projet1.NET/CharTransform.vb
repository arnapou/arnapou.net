Option Strict Off
Option Explicit On
Friend Class MyForm
	Inherits System.Windows.Forms.Form
#Region "Windows Form Designer generated code "
	Public Sub New()
		MyBase.New()
		If m_vb6FormDefInstance Is Nothing Then
			If m_InitializingDefInstance Then
				m_vb6FormDefInstance = Me
			Else
				Try 
					'For the start-up form, the first instance created is the default instance.
					If System.Reflection.Assembly.GetExecutingAssembly.EntryPoint.DeclaringType Is Me.GetType Then
						m_vb6FormDefInstance = Me
					End If
				Catch
				End Try
			End If
		End If
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents _Car_2 As System.Windows.Forms.RadioButton
	Public WithEvents _Car_1 As System.Windows.Forms.RadioButton
	Public WithEvents _Car_0 As System.Windows.Forms.RadioButton
	Public WithEvents chkChar As System.Windows.Forms.CheckBox
	Public WithEvents txtChar As System.Windows.Forms.TextBox
	Public WithEvents Frame1 As System.Windows.Forms.GroupBox
	Public WithEvents txtTexte As System.Windows.Forms.TextBox
	Public WithEvents _Sens_1 As System.Windows.Forms.RadioButton
	Public WithEvents _Sens_2 As System.Windows.Forms.RadioButton
	Public WithEvents _Sens_0 As System.Windows.Forms.RadioButton
	Public WithEvents frame As System.Windows.Forms.GroupBox
	Public WithEvents cmdQuit As System.Windows.Forms.Button
	Public WithEvents txtResult As System.Windows.Forms.TextBox
	Public WithEvents lblTexte As System.Windows.Forms.Label
	Public WithEvents Car As Microsoft.VisualBasic.Compatibility.VB6.RadioButtonArray
	Public WithEvents Sens As Microsoft.VisualBasic.Compatibility.VB6.RadioButtonArray
	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(MyForm))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.Frame1 = New System.Windows.Forms.GroupBox
        Me._Car_2 = New System.Windows.Forms.RadioButton
        Me._Car_1 = New System.Windows.Forms.RadioButton
        Me._Car_0 = New System.Windows.Forms.RadioButton
        Me.chkChar = New System.Windows.Forms.CheckBox
        Me.txtChar = New System.Windows.Forms.TextBox
        Me.txtTexte = New System.Windows.Forms.TextBox
        Me.frame = New System.Windows.Forms.GroupBox
        Me._Sens_1 = New System.Windows.Forms.RadioButton
        Me._Sens_2 = New System.Windows.Forms.RadioButton
        Me._Sens_0 = New System.Windows.Forms.RadioButton
        Me.cmdQuit = New System.Windows.Forms.Button
        Me.txtResult = New System.Windows.Forms.TextBox
        Me.lblTexte = New System.Windows.Forms.Label
        Me.Car = New Microsoft.VisualBasic.Compatibility.VB6.RadioButtonArray(Me.components)
        Me.Sens = New Microsoft.VisualBasic.Compatibility.VB6.RadioButtonArray(Me.components)
        Me.Frame1.SuspendLayout()
        Me.frame.SuspendLayout()
        CType(Me.Car, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Sens, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Frame1
        '
        Me.Frame1.BackColor = System.Drawing.SystemColors.Control
        Me.Frame1.Controls.Add(Me._Car_2)
        Me.Frame1.Controls.Add(Me._Car_1)
        Me.Frame1.Controls.Add(Me._Car_0)
        Me.Frame1.Controls.Add(Me.chkChar)
        Me.Frame1.Controls.Add(Me.txtChar)
        Me.Frame1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame1.Location = New System.Drawing.Point(440, 16)
        Me.Frame1.Name = "Frame1"
        Me.Frame1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame1.Size = New System.Drawing.Size(153, 73)
        Me.Frame1.TabIndex = 8
        Me.Frame1.TabStop = False
        Me.Frame1.Text = "Caract�res"
        '
        '_Car_2
        '
        Me._Car_2.BackColor = System.Drawing.SystemColors.Control
        Me._Car_2.Checked = True
        Me._Car_2.Cursor = System.Windows.Forms.Cursors.Default
        Me._Car_2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Car_2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Car.SetIndex(Me._Car_2, CType(2, Short))
        Me._Car_2.Location = New System.Drawing.Point(88, 40)
        Me._Car_2.Name = "_Car_2"
        Me._Car_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Car_2.Size = New System.Drawing.Size(57, 25)
        Me._Car_2.TabIndex = 13
        Me._Car_2.TabStop = True
        Me._Car_2.Text = "Aucun"
        '
        '_Car_1
        '
        Me._Car_1.BackColor = System.Drawing.SystemColors.Control
        Me._Car_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._Car_1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Car_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Car.SetIndex(Me._Car_1, CType(1, Short))
        Me._Car_1.Location = New System.Drawing.Point(8, 53)
        Me._Car_1.Name = "_Car_1"
        Me._Car_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Car_1.Size = New System.Drawing.Size(73, 17)
        Me._Car_1.TabIndex = 12
        Me._Car_1.TabStop = True
        Me._Car_1.Text = "Minuscules"
        '
        '_Car_0
        '
        Me._Car_0.BackColor = System.Drawing.SystemColors.Control
        Me._Car_0.Cursor = System.Windows.Forms.Cursors.Default
        Me._Car_0.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Car_0.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Car.SetIndex(Me._Car_0, CType(0, Short))
        Me._Car_0.Location = New System.Drawing.Point(8, 37)
        Me._Car_0.Name = "_Car_0"
        Me._Car_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Car_0.Size = New System.Drawing.Size(81, 17)
        Me._Car_0.TabIndex = 11
        Me._Car_0.TabStop = True
        Me._Car_0.Text = "Majuscules"
        '
        'chkChar
        '
        Me.chkChar.BackColor = System.Drawing.SystemColors.Control
        Me.chkChar.Checked = True
        Me.chkChar.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkChar.Cursor = System.Windows.Forms.Cursors.Default
        Me.chkChar.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkChar.ForeColor = System.Drawing.SystemColors.ControlText
        Me.chkChar.Location = New System.Drawing.Point(24, 14)
        Me.chkChar.Name = "chkChar"
        Me.chkChar.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.chkChar.Size = New System.Drawing.Size(105, 25)
        Me.chkChar.TabIndex = 10
        Me.chkChar.Text = "Le m�me partout"
        '
        'txtChar
        '
        Me.txtChar.AcceptsReturn = True
        Me.txtChar.AutoSize = False
        Me.txtChar.BackColor = System.Drawing.SystemColors.Window
        Me.txtChar.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtChar.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtChar.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtChar.Location = New System.Drawing.Point(48, 40)
        Me.txtChar.MaxLength = 1
        Me.txtChar.Name = "txtChar"
        Me.txtChar.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtChar.Size = New System.Drawing.Size(57, 25)
        Me.txtChar.TabIndex = 9
        Me.txtChar.Text = "#"
        Me.txtChar.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtTexte
        '
        Me.txtTexte.AcceptsReturn = True
        Me.txtTexte.AutoSize = False
        Me.txtTexte.BackColor = System.Drawing.SystemColors.Window
        Me.txtTexte.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtTexte.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTexte.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtTexte.Location = New System.Drawing.Point(24, 32)
        Me.txtTexte.MaxLength = 0
        Me.txtTexte.Name = "txtTexte"
        Me.txtTexte.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtTexte.Size = New System.Drawing.Size(361, 25)
        Me.txtTexte.TabIndex = 7
        Me.txtTexte.Text = "Text1"
        '
        'frame
        '
        Me.frame.BackColor = System.Drawing.SystemColors.Control
        Me.frame.Controls.Add(Me._Sens_1)
        Me.frame.Controls.Add(Me._Sens_2)
        Me.frame.Controls.Add(Me._Sens_0)
        Me.frame.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.frame.ForeColor = System.Drawing.SystemColors.ControlText
        Me.frame.Location = New System.Drawing.Point(624, 16)
        Me.frame.Name = "frame"
        Me.frame.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.frame.Size = New System.Drawing.Size(121, 73)
        Me.frame.TabIndex = 3
        Me.frame.TabStop = False
        Me.frame.Text = "Sens"
        '
        '_Sens_1
        '
        Me._Sens_1.BackColor = System.Drawing.SystemColors.Control
        Me._Sens_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._Sens_1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Sens_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Sens.SetIndex(Me._Sens_1, CType(1, Short))
        Me._Sens_1.Location = New System.Drawing.Point(24, 32)
        Me._Sens_1.Name = "_Sens_1"
        Me._Sens_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Sens_1.Size = New System.Drawing.Size(73, 13)
        Me._Sens_1.TabIndex = 6
        Me._Sens_1.TabStop = True
        Me._Sens_1.Text = "Vertical 2"
        '
        '_Sens_2
        '
        Me._Sens_2.BackColor = System.Drawing.SystemColors.Control
        Me._Sens_2.Checked = True
        Me._Sens_2.Cursor = System.Windows.Forms.Cursors.Default
        Me._Sens_2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Sens_2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Sens.SetIndex(Me._Sens_2, CType(2, Short))
        Me._Sens_2.Location = New System.Drawing.Point(24, 48)
        Me._Sens_2.Name = "_Sens_2"
        Me._Sens_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Sens_2.Size = New System.Drawing.Size(73, 13)
        Me._Sens_2.TabIndex = 5
        Me._Sens_2.TabStop = True
        Me._Sens_2.Text = "Horizontal"
        '
        '_Sens_0
        '
        Me._Sens_0.BackColor = System.Drawing.SystemColors.Control
        Me._Sens_0.Cursor = System.Windows.Forms.Cursors.Default
        Me._Sens_0.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Sens_0.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Sens.SetIndex(Me._Sens_0, CType(0, Short))
        Me._Sens_0.Location = New System.Drawing.Point(24, 16)
        Me._Sens_0.Name = "_Sens_0"
        Me._Sens_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Sens_0.Size = New System.Drawing.Size(73, 13)
        Me._Sens_0.TabIndex = 4
        Me._Sens_0.TabStop = True
        Me._Sens_0.Text = "Vertical 1"
        '
        'cmdQuit
        '
        Me.cmdQuit.BackColor = System.Drawing.SystemColors.Control
        Me.cmdQuit.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdQuit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.cmdQuit.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdQuit.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdQuit.Location = New System.Drawing.Point(768, 32)
        Me.cmdQuit.Name = "cmdQuit"
        Me.cmdQuit.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdQuit.Size = New System.Drawing.Size(129, 33)
        Me.cmdQuit.TabIndex = 2
        Me.cmdQuit.Text = "&Quitter"
        '
        'txtResult
        '
        Me.txtResult.AcceptsReturn = True
        Me.txtResult.AutoSize = False
        Me.txtResult.BackColor = System.Drawing.SystemColors.Window
        Me.txtResult.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtResult.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtResult.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtResult.Location = New System.Drawing.Point(16, 104)
        Me.txtResult.MaxLength = 0
        Me.txtResult.Multiline = True
        Me.txtResult.Name = "txtResult"
        Me.txtResult.ReadOnly = True
        Me.txtResult.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtResult.Size = New System.Drawing.Size(881, 233)
        Me.txtResult.TabIndex = 1
        Me.txtResult.Text = "Text1"
        '
        'lblTexte
        '
        Me.lblTexte.BackColor = System.Drawing.SystemColors.Control
        Me.lblTexte.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblTexte.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTexte.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblTexte.Location = New System.Drawing.Point(8, 16)
        Me.lblTexte.Name = "lblTexte"
        Me.lblTexte.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblTexte.Size = New System.Drawing.Size(97, 25)
        Me.lblTexte.TabIndex = 0
        Me.lblTexte.Text = "Ecrire votre texte"
        Me.lblTexte.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'MyForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(912, 356)
        Me.Controls.Add(Me.Frame1)
        Me.Controls.Add(Me.txtTexte)
        Me.Controls.Add(Me.frame)
        Me.Controls.Add(Me.cmdQuit)
        Me.Controls.Add(Me.txtResult)
        Me.Controls.Add(Me.lblTexte)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Location = New System.Drawing.Point(4, 23)
        Me.MaximizeBox = False
        Me.Name = "MyForm"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Petit Utilitaire Rigolo"
        Me.Frame1.ResumeLayout(False)
        Me.frame.ResumeLayout(False)
        CType(Me.Car, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Sens, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
#End Region 
#Region "Upgrade Support "
	Private Shared m_vb6FormDefInstance As MyForm
	Private Shared m_InitializingDefInstance As Boolean
	Public Shared Property DefInstance() As MyForm
		Get
			If m_vb6FormDefInstance Is Nothing OrElse m_vb6FormDefInstance.IsDisposed Then
				m_InitializingDefInstance = True
				m_vb6FormDefInstance = New MyForm()
				m_InitializingDefInstance = False
			End If
			DefInstance = m_vb6FormDefInstance
		End Get
		Set
			m_vb6FormDefInstance = Value
		End Set
	End Property
#End Region 
	
	
	Dim Alphabet(255, 5) As String
	
	'UPGRADE_WARNING: Event chkChar.CheckStateChanged may fire when form is initialized. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2075"'
	Private Sub chkChar_CheckStateChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles chkChar.CheckStateChanged
		If chkChar.CheckState = System.Windows.Forms.CheckState.Checked Then
            _Car_0.Visible = False
            _Car_1.Visible = False
            _Car_2.Visible = False
            txtChar.Visible = True
        End If
        If chkChar.CheckState = System.Windows.Forms.CheckState.Unchecked Then
            txtChar.Visible = False
            _Car_0.Visible = True
            _Car_1.Visible = True
            _Car_2.Visible = True
        End If
    End Sub

    Private Sub Ecrire()
        Dim tempo, Result, k, i, Taille, j, test, Texte, tempChar As Object
        Dim MonTableau(5) As String
        txtResult.Text = ""
        'UPGRADE_WARNING: Couldn't resolve default property of object Texte. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
        Texte = txtTexte.Text
        'UPGRADE_WARNING: Couldn't resolve default property of object Taille. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
        Taille = Len(Texte)
        For i = 0 To 5
            'UPGRADE_WARNING: Couldn't resolve default property of object Result. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
            Result = ""
            'UPGRADE_WARNING: Couldn't resolve default property of object Taille. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
            For j = 1 To Taille
                'UPGRADE_WARNING: Couldn't resolve default property of object j. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
                'UPGRADE_WARNING: Couldn't resolve default property of object Texte. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
                'UPGRADE_WARNING: Couldn't resolve default property of object tempChar. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
                tempChar = Mid(Texte, j, 1)
                'UPGRADE_WARNING: Couldn't resolve default property of object i. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
                'UPGRADE_WARNING: Couldn't resolve default property of object tempChar. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
                'UPGRADE_WARNING: Couldn't resolve default property of object tempo. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
                tempo = Alphabet(Asc(tempChar), i)
                'UPGRADE_WARNING: Couldn't resolve default property of object tempo. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
                If tempo = "" Then
                    'UPGRADE_WARNING: Couldn't resolve default property of object test. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
                    test = 0
                    For k = 0 To 5
                        'UPGRADE_WARNING: Couldn't resolve default property of object k. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
                        'UPGRADE_WARNING: Couldn't resolve default property of object tempChar. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
                        If Alphabet(Asc(tempChar), k) <> "" Then
                            'UPGRADE_WARNING: Couldn't resolve default property of object k. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
                            'UPGRADE_WARNING: Couldn't resolve default property of object tempChar. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
                            'UPGRADE_WARNING: Couldn't resolve default property of object test. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
                            test = Len(Alphabet(Asc(tempChar), k))
                        End If
                    Next
                    'UPGRADE_WARNING: Couldn't resolve default property of object test. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
                    If test > 0 Then
                        'UPGRADE_WARNING: Couldn't resolve default property of object tempChar. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
                        'UPGRADE_WARNING: Couldn't resolve default property of object test. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
                        If tempChar = "_" Then test = test - 1
                        'UPGRADE_WARNING: Couldn't resolve default property of object test. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
                        'UPGRADE_WARNING: Couldn't resolve default property of object Result. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
                        Result = Result + New String(" ", test + 1)
                    End If
                Else
                    If chkChar.CheckState = System.Windows.Forms.CheckState.Checked Then
                        'UPGRADE_WARNING: Couldn't resolve default property of object tempo. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
                        'UPGRADE_WARNING: Couldn't resolve default property of object Result. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
                        Result = Result + Replace(tempo, "#", txtChar.Text)
                    Else
                        'UPGRADE_WARNING: Couldn't resolve default property of object tempChar. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
                        'UPGRADE_WARNING: Couldn't resolve default property of object tempo. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
                        'UPGRADE_WARNING: Couldn't resolve default property of object Result. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
                        If _Car_0.Checked = True Then Result = Result + Replace(tempo, "#", UCase(tempChar))
                        'UPGRADE_WARNING: Couldn't resolve default property of object tempChar. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
                        'UPGRADE_WARNING: Couldn't resolve default property of object tempo. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
                        'UPGRADE_WARNING: Couldn't resolve default property of object Result. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
                        If _Car_1.Checked = True Then Result = Result + Replace(tempo, "#", LCase(tempChar))
                        'UPGRADE_WARNING: Couldn't resolve default property of object tempChar. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
                        'UPGRADE_WARNING: Couldn't resolve default property of object tempo. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
                        'UPGRADE_WARNING: Couldn't resolve default property of object Result. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
                        If _Car_2.Checked = True Then Result = Result + Replace(tempo, "#", tempChar)
                    End If
                    'UPGRADE_WARNING: Couldn't resolve default property of object tempChar. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
                    'UPGRADE_WARNING: Couldn't resolve default property of object Result. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
                    If tempChar <> "_" Then Result = Result + " "
                End If
            Next
            'UPGRADE_WARNING: Couldn't resolve default property of object i. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
            'UPGRADE_WARNING: Couldn't resolve default property of object Result. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
            MonTableau(i) = Result
        Next
        'UPGRADE_WARNING: Couldn't resolve default property of object Result. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
        Result = ""
        If _Sens_2.Checked = True Then
            For i = 0 To 5
                'UPGRADE_WARNING: Couldn't resolve default property of object i. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
                'UPGRADE_WARNING: Couldn't resolve default property of object Result. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
                Result = Result + MonTableau(i) + vbCrLf
            Next
        End If
        If _Sens_1.Checked = True Then
            For i = 1 To Len(MonTableau(0))
                For j = 5 To 0 Step -1
                    'UPGRADE_WARNING: Couldn't resolve default property of object i. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
                    'UPGRADE_WARNING: Couldn't resolve default property of object j. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
                    'UPGRADE_WARNING: Couldn't resolve default property of object Result. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
                    Result = Result + Mid(MonTableau(j), i, 1)
                Next
                'UPGRADE_WARNING: Couldn't resolve default property of object Result. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
                Result = Result + vbCrLf
            Next
        End If
        If _Sens_0.Checked = True Then
            For i = Len(MonTableau(0)) To 1 Step -1
                For j = 0 To 5
                    'UPGRADE_WARNING: Couldn't resolve default property of object i. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
                    'UPGRADE_WARNING: Couldn't resolve default property of object j. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
                    'UPGRADE_WARNING: Couldn't resolve default property of object Result. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
                    Result = Result + Mid(MonTableau(j), i, 1)
                Next
                'UPGRADE_WARNING: Couldn't resolve default property of object Result. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
                Result = Result + vbCrLf
            Next
        End If
        'UPGRADE_WARNING: Couldn't resolve default property of object Result. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
        txtResult.Text = Result
    End Sub

    Private Sub cmdQuit_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdQuit.Click
        MyForm.DefInstance.Close()
    End Sub

    Private Sub MyForm_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
        Dim i, j As Object

        txtChar.Visible = True
        chkChar.CheckState = System.Windows.Forms.CheckState.Checked
        _Car_0.Visible = False
        _Car_1.Visible = False
        _Car_2.Visible = False

        txtTexte.Text = "Mettez ici votre texte !"
        txtResult.Text = ""
        txtChar.Text = "#"

        For i = 0 To 255
            For j = 0 To 5
                'UPGRADE_WARNING: Couldn't resolve default property of object j. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
                'UPGRADE_WARNING: Couldn't resolve default property of object i. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1037"'
                Alphabet(i, j) = ""
            Next
        Next

        Alphabet(Asc("A"), 0) = "  #  "
        Alphabet(Asc("A"), 1) = " # # "
        Alphabet(Asc("A"), 2) = "#   #"
        Alphabet(Asc("A"), 3) = "#####"
        Alphabet(Asc("A"), 4) = "#   #"

        Alphabet(Asc("B"), 0) = "###  "
        Alphabet(Asc("B"), 1) = "#  # "
        Alphabet(Asc("B"), 2) = "#### "
        Alphabet(Asc("B"), 3) = "#   #"
        Alphabet(Asc("B"), 4) = "#### "

        Alphabet(Asc("C"), 0) = " ###"
        Alphabet(Asc("C"), 1) = "#   "
        Alphabet(Asc("C"), 2) = "#   "
        Alphabet(Asc("C"), 3) = "#   "
        Alphabet(Asc("C"), 4) = " ###"

        Alphabet(Asc("D"), 0) = "#### "
        Alphabet(Asc("D"), 1) = "#   #"
        Alphabet(Asc("D"), 2) = "#   #"
        Alphabet(Asc("D"), 3) = "#   #"
        Alphabet(Asc("D"), 4) = "#### "

        Alphabet(Asc("E"), 0) = "####"
        Alphabet(Asc("E"), 1) = "#   "
        Alphabet(Asc("E"), 2) = "### "
        Alphabet(Asc("E"), 3) = "#   "
        Alphabet(Asc("E"), 4) = "####"

        Alphabet(Asc("F"), 0) = "####"
        Alphabet(Asc("F"), 1) = "#   "
        Alphabet(Asc("F"), 2) = "### "
        Alphabet(Asc("F"), 3) = "#   "
        Alphabet(Asc("F"), 4) = "#   "

        Alphabet(Asc("G"), 0) = " ### "
        Alphabet(Asc("G"), 1) = "#    "
        Alphabet(Asc("G"), 2) = "#  ##"
        Alphabet(Asc("G"), 3) = "#   #"
        Alphabet(Asc("G"), 4) = " ### "

        Alphabet(Asc("H"), 0) = "#   #"
        Alphabet(Asc("H"), 1) = "#   #"
        Alphabet(Asc("H"), 2) = "#####"
        Alphabet(Asc("H"), 3) = "#   #"
        Alphabet(Asc("H"), 4) = "#   #"

        Alphabet(Asc("I"), 0) = "#"
        Alphabet(Asc("I"), 1) = "#"
        Alphabet(Asc("I"), 2) = "#"
        Alphabet(Asc("I"), 3) = "#"
        Alphabet(Asc("I"), 4) = "#"

        Alphabet(Asc("J"), 0) = "  ###"
        Alphabet(Asc("J"), 1) = "   # "
        Alphabet(Asc("J"), 2) = "   # "
        Alphabet(Asc("J"), 3) = "#  # "
        Alphabet(Asc("J"), 4) = " ##  "

        Alphabet(Asc("K"), 0) = "#  #"
        Alphabet(Asc("K"), 1) = "# # "
        Alphabet(Asc("K"), 2) = "##  "
        Alphabet(Asc("K"), 3) = "# # "
        Alphabet(Asc("K"), 4) = "#  #"

        Alphabet(Asc("L"), 0) = "#   "
        Alphabet(Asc("L"), 1) = "#   "
        Alphabet(Asc("L"), 2) = "#   "
        Alphabet(Asc("L"), 3) = "#   "
        Alphabet(Asc("L"), 4) = "####"

        Alphabet(Asc("M"), 0) = "#   #"
        Alphabet(Asc("M"), 1) = "## ##"
        Alphabet(Asc("M"), 2) = "# # #"
        Alphabet(Asc("M"), 3) = "#   #"
        Alphabet(Asc("M"), 4) = "#   #"

        Alphabet(Asc("N"), 0) = "#   #"
        Alphabet(Asc("N"), 1) = "##  #"
        Alphabet(Asc("N"), 2) = "# # #"
        Alphabet(Asc("N"), 3) = "#  ##"
        Alphabet(Asc("N"), 4) = "#   #"

        Alphabet(Asc("O"), 0) = " ### "
        Alphabet(Asc("O"), 1) = "#   #"
        Alphabet(Asc("O"), 2) = "#   #"
        Alphabet(Asc("O"), 3) = "#   #"
        Alphabet(Asc("O"), 4) = " ### "

        Alphabet(Asc("P"), 0) = "#### "
        Alphabet(Asc("P"), 1) = "#   #"
        Alphabet(Asc("P"), 2) = "#### "
        Alphabet(Asc("P"), 3) = "#    "
        Alphabet(Asc("P"), 4) = "#    "

        Alphabet(Asc("Q"), 0) = " ###  "
        Alphabet(Asc("Q"), 1) = "#   # "
        Alphabet(Asc("Q"), 2) = "#   # "
        Alphabet(Asc("Q"), 3) = "#   # "
        Alphabet(Asc("Q"), 4) = " ### #"

        Alphabet(Asc("R"), 0) = "#### "
        Alphabet(Asc("R"), 1) = "#   #"
        Alphabet(Asc("R"), 2) = "#### "
        Alphabet(Asc("R"), 3) = "#  # "
        Alphabet(Asc("R"), 4) = "#   #"

        Alphabet(Asc("S"), 0) = " ####"
        Alphabet(Asc("S"), 1) = "#    "
        Alphabet(Asc("S"), 2) = " ### "
        Alphabet(Asc("S"), 3) = "    #"
        Alphabet(Asc("S"), 4) = "#### "

        Alphabet(Asc("T"), 0) = "#####"
        Alphabet(Asc("T"), 1) = "  #  "
        Alphabet(Asc("T"), 2) = "  #  "
        Alphabet(Asc("T"), 3) = "  #  "
        Alphabet(Asc("T"), 4) = "  #  "

        Alphabet(Asc("U"), 0) = "#   #"
        Alphabet(Asc("U"), 1) = "#   #"
        Alphabet(Asc("U"), 2) = "#   #"
        Alphabet(Asc("U"), 3) = "#   #"
        Alphabet(Asc("U"), 4) = " ### "

        Alphabet(Asc("V"), 0) = "#   #"
        Alphabet(Asc("V"), 1) = "#   #"
        Alphabet(Asc("V"), 2) = "#   #"
        Alphabet(Asc("V"), 3) = " # # "
        Alphabet(Asc("V"), 4) = "  #  "

        Alphabet(Asc("W"), 0) = "#     #"
        Alphabet(Asc("W"), 1) = "#     #"
        Alphabet(Asc("W"), 2) = "#     #"
        Alphabet(Asc("W"), 3) = " # # # "
        Alphabet(Asc("W"), 4) = "  # #  "

        Alphabet(Asc("X"), 0) = "#   #"
        Alphabet(Asc("X"), 1) = " # # "
        Alphabet(Asc("X"), 2) = "  #  "
        Alphabet(Asc("X"), 3) = " # # "
        Alphabet(Asc("X"), 4) = "#   #"

        Alphabet(Asc("Y"), 0) = "#   #"
        Alphabet(Asc("Y"), 1) = " # # "
        Alphabet(Asc("Y"), 2) = "  #  "
        Alphabet(Asc("Y"), 3) = "  #  "
        Alphabet(Asc("Y"), 4) = "  #  "

        Alphabet(Asc("X"), 0) = "#   #"
        Alphabet(Asc("X"), 1) = " # # "
        Alphabet(Asc("X"), 2) = "  #  "
        Alphabet(Asc("X"), 3) = " # # "
        Alphabet(Asc("X"), 4) = "#   #"

        Alphabet(Asc("Z"), 0) = "#####"
        Alphabet(Asc("Z"), 1) = "   # "
        Alphabet(Asc("Z"), 2) = "  #  "
        Alphabet(Asc("Z"), 3) = " #   "
        Alphabet(Asc("Z"), 4) = "#####"

        Alphabet(Asc(" "), 0) = "    "

        Alphabet(Asc("a"), 1) = " ### "
        Alphabet(Asc("a"), 2) = "#  # "
        Alphabet(Asc("a"), 3) = "#  # "
        Alphabet(Asc("a"), 4) = " ## #"

        Alphabet(Asc("b"), 0) = "#    "
        Alphabet(Asc("b"), 1) = "# ## "
        Alphabet(Asc("b"), 2) = "##  #"
        Alphabet(Asc("b"), 3) = "#   #"
        Alphabet(Asc("b"), 4) = " ### "

        Alphabet(Asc("c"), 1) = " ###"
        Alphabet(Asc("c"), 2) = "#   "
        Alphabet(Asc("c"), 3) = "#   "
        Alphabet(Asc("c"), 4) = " ###"

        Alphabet(Asc("d"), 0) = "    #"
        Alphabet(Asc("d"), 1) = " ## #"
        Alphabet(Asc("d"), 2) = "#  ##"
        Alphabet(Asc("d"), 3) = "#   #"
        Alphabet(Asc("d"), 4) = " ### "

        Alphabet(Asc("e"), 1) = " ### "
        Alphabet(Asc("e"), 2) = "#####"
        Alphabet(Asc("e"), 3) = "#    "
        Alphabet(Asc("e"), 4) = " ### "

        Alphabet(Asc("f"), 0) = " ##"
        Alphabet(Asc("f"), 1) = "#  "
        Alphabet(Asc("f"), 2) = "###"
        Alphabet(Asc("f"), 3) = "#  "
        Alphabet(Asc("f"), 4) = "#  "

        Alphabet(Asc("g"), 1) = "  ## "
        Alphabet(Asc("g"), 2) = " #  #"
        Alphabet(Asc("g"), 3) = "  ###"
        Alphabet(Asc("g"), 4) = "#   #"
        Alphabet(Asc("g"), 5) = " ### "

        Alphabet(Asc("h"), 0) = "#    "
        Alphabet(Asc("h"), 1) = "#    "
        Alphabet(Asc("h"), 2) = "# ## "
        Alphabet(Asc("h"), 3) = "##  #"
        Alphabet(Asc("h"), 4) = "#   #"

        Alphabet(Asc("i"), 1) = "#"
        Alphabet(Asc("i"), 2) = " "
        Alphabet(Asc("i"), 3) = "#"
        Alphabet(Asc("i"), 4) = "#"

        Alphabet(Asc("j"), 1) = "  #"
        Alphabet(Asc("j"), 2) = "   "
        Alphabet(Asc("j"), 3) = "  #"
        Alphabet(Asc("j"), 4) = "  #"
        Alphabet(Asc("j"), 5) = "## "

        Alphabet(Asc("k"), 0) = "#  "
        Alphabet(Asc("k"), 1) = "#  "
        Alphabet(Asc("k"), 2) = "# #"
        Alphabet(Asc("k"), 3) = "## "
        Alphabet(Asc("k"), 4) = "# #"

        Alphabet(Asc("l"), 0) = "#  "
        Alphabet(Asc("l"), 1) = "#  "
        Alphabet(Asc("l"), 2) = "#  "
        Alphabet(Asc("l"), 3) = "#  "
        Alphabet(Asc("l"), 4) = " ##"

        Alphabet(Asc("m"), 1) = "# ## ##"
        Alphabet(Asc("m"), 2) = "## ## #"
        Alphabet(Asc("m"), 3) = "#  #  #"
        Alphabet(Asc("m"), 4) = "#  #  #"

        Alphabet(Asc("n"), 1) = "# ##"
        Alphabet(Asc("n"), 2) = "## #"
        Alphabet(Asc("n"), 3) = "#  #"
        Alphabet(Asc("n"), 4) = "#  #"

        Alphabet(Asc("o"), 1) = " ### "
        Alphabet(Asc("o"), 2) = "#   #"
        Alphabet(Asc("o"), 3) = "#   #"
        Alphabet(Asc("o"), 4) = " ### "

        Alphabet(Asc("p"), 1) = " ### "
        Alphabet(Asc("p"), 2) = "#   #"
        Alphabet(Asc("p"), 3) = "##  #"
        Alphabet(Asc("p"), 4) = "# ## "
        Alphabet(Asc("p"), 5) = "#    "

        Alphabet(Asc("q"), 1) = " ### "
        Alphabet(Asc("q"), 2) = "#   #"
        Alphabet(Asc("q"), 3) = "#  ##"
        Alphabet(Asc("q"), 4) = " ## #"
        Alphabet(Asc("q"), 5) = "    #"

        Alphabet(Asc("r"), 1) = "# ##"
        Alphabet(Asc("r"), 2) = "##  "
        Alphabet(Asc("r"), 3) = "#   "
        Alphabet(Asc("r"), 4) = "#   "

        Alphabet(Asc("s"), 1) = " ###"
        Alphabet(Asc("s"), 2) = "### "
        Alphabet(Asc("s"), 3) = "   #"
        Alphabet(Asc("s"), 4) = "### "

        Alphabet(Asc("t"), 0) = "#   "
        Alphabet(Asc("t"), 1) = "#   "
        Alphabet(Asc("t"), 2) = "### "
        Alphabet(Asc("t"), 3) = "#   "
        Alphabet(Asc("t"), 4) = " ## "

        Alphabet(Asc("u"), 1) = "#  #"
        Alphabet(Asc("u"), 2) = "#  #"
        Alphabet(Asc("u"), 3) = "#  #"
        Alphabet(Asc("u"), 4) = " ###"

        Alphabet(Asc("v"), 1) = "#  #"
        Alphabet(Asc("v"), 2) = "#  #"
        Alphabet(Asc("v"), 3) = "# # "
        Alphabet(Asc("v"), 4) = " #  "

        Alphabet(Asc("w"), 1) = "#   #"
        Alphabet(Asc("w"), 2) = "#   #"
        Alphabet(Asc("w"), 3) = "# # #"
        Alphabet(Asc("w"), 4) = " # # "

        Alphabet(Asc("x"), 1) = " # #"
        Alphabet(Asc("x"), 2) = "  # "
        Alphabet(Asc("x"), 3) = " ## "
        Alphabet(Asc("x"), 4) = "#  #"

        Alphabet(Asc("y"), 1) = "#  #"
        Alphabet(Asc("y"), 2) = "#  #"
        Alphabet(Asc("y"), 3) = " ###"
        Alphabet(Asc("y"), 4) = "   #"
        Alphabet(Asc("y"), 5) = "### "

        Alphabet(Asc("z"), 1) = "####"
        Alphabet(Asc("z"), 2) = "  # "
        Alphabet(Asc("z"), 3) = " #  "
        Alphabet(Asc("z"), 4) = "####"

        Alphabet(Asc("1"), 0) = "  #"
        Alphabet(Asc("1"), 1) = " ##"
        Alphabet(Asc("1"), 2) = "  #"
        Alphabet(Asc("1"), 3) = "  #"
        Alphabet(Asc("1"), 4) = "  #"

        Alphabet(Asc("2"), 0) = " ## "
        Alphabet(Asc("2"), 1) = "#  #"
        Alphabet(Asc("2"), 2) = "  # "
        Alphabet(Asc("2"), 3) = " #  "
        Alphabet(Asc("2"), 4) = "####"

        Alphabet(Asc("3"), 0) = "### "
        Alphabet(Asc("3"), 1) = "   #"
        Alphabet(Asc("3"), 2) = " ## "
        Alphabet(Asc("3"), 3) = "   #"
        Alphabet(Asc("3"), 4) = "### "

        Alphabet(Asc("4"), 0) = "  ## "
        Alphabet(Asc("4"), 1) = " # # "
        Alphabet(Asc("4"), 2) = "#####"
        Alphabet(Asc("4"), 3) = "   # "
        Alphabet(Asc("4"), 4) = "   # "

        Alphabet(Asc("5"), 0) = "####"
        Alphabet(Asc("5"), 1) = "#   "
        Alphabet(Asc("5"), 2) = "### "
        Alphabet(Asc("5"), 3) = "   #"
        Alphabet(Asc("5"), 4) = "### "

        Alphabet(Asc("6"), 0) = " ## "
        Alphabet(Asc("6"), 1) = "#   "
        Alphabet(Asc("6"), 2) = "### "
        Alphabet(Asc("6"), 3) = "#  #"
        Alphabet(Asc("6"), 4) = " ## "

        Alphabet(Asc("7"), 0) = "####"
        Alphabet(Asc("7"), 1) = "  # "
        Alphabet(Asc("7"), 2) = " #  "
        Alphabet(Asc("7"), 3) = " #  "
        Alphabet(Asc("7"), 4) = " #  "

        Alphabet(Asc("8"), 0) = " ## "
        Alphabet(Asc("8"), 1) = "#  #"
        Alphabet(Asc("8"), 2) = " ## "
        Alphabet(Asc("8"), 3) = "#  #"
        Alphabet(Asc("8"), 4) = " ## "

        Alphabet(Asc("9"), 0) = " ## "
        Alphabet(Asc("9"), 1) = "#  #"
        Alphabet(Asc("9"), 2) = " ###"
        Alphabet(Asc("9"), 3) = "   #"
        Alphabet(Asc("9"), 4) = " ## "

        Alphabet(Asc("0"), 0) = " ## "
        Alphabet(Asc("0"), 1) = "#  #"
        Alphabet(Asc("0"), 2) = "#  #"
        Alphabet(Asc("0"), 3) = "#  #"
        Alphabet(Asc("0"), 4) = " ## "

        Alphabet(Asc("!"), 0) = "#"
        Alphabet(Asc("!"), 1) = "#"
        Alphabet(Asc("!"), 2) = "#"
        Alphabet(Asc("!"), 3) = " "
        Alphabet(Asc("!"), 4) = "#"

        Alphabet(Asc("?"), 0) = " ## "
        Alphabet(Asc("?"), 1) = "#  #"
        Alphabet(Asc("?"), 2) = "  # "
        Alphabet(Asc("?"), 3) = "    "
        Alphabet(Asc("?"), 4) = "  # "

        Alphabet(Asc("."), 4) = "#"

        Alphabet(Asc(":"), 2) = "#"
        Alphabet(Asc(":"), 4) = "#"

        Alphabet(Asc(";"), 2) = "#"
        Alphabet(Asc(";"), 3) = " "
        Alphabet(Asc(";"), 4) = "#"
        Alphabet(Asc(";"), 5) = "#"

        Alphabet(Asc("'"), 0) = " #"
        Alphabet(Asc("'"), 1) = "# "

        Alphabet(Asc(","), 4) = "#"
        Alphabet(Asc(","), 5) = "#"

        Alphabet(Asc("/"), 0) = "    #"
        Alphabet(Asc("/"), 1) = "   # "
        Alphabet(Asc("/"), 2) = "  #  "
        Alphabet(Asc("/"), 3) = " #   "
        Alphabet(Asc("/"), 4) = "#    "

        Alphabet(Asc("\"), 0) = "#    "
        Alphabet(Asc("\"), 1) = " #   "
        Alphabet(Asc("\"), 2) = "  #  "
        Alphabet(Asc("\"), 3) = "   # "
        Alphabet(Asc("\"), 4) = "    #"

        Alphabet(Asc("-"), 2) = "###"

        Alphabet(Asc("+"), 1) = " # "
        Alphabet(Asc("+"), 2) = "###"
        Alphabet(Asc("+"), 3) = " # "

        Alphabet(Asc("_"), 4) = "#####"

    End Sub


    'UPGRADE_WARNING: Event txtTexte.TextChanged may fire when form is initialized. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup2075"'
    Private Sub txtTexte_TextChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtTexte.TextChanged
        Ecrire()
    End Sub
End Class