/*********************************************************************************
 *                                   DEFINE                                      */
/*********************************************************************************
**  IA_MODE : type d'IA
**     0 => poids linéaires
**     1 => poids non-linéaires (tendance à déplacer les pions de départ)
**     2 => poids non-linéaires (tendance à déplacer les pions près de l'arrivée)
**  IA_PROFONDEUR : profondeur de recherche (temps de calcul ~ difficulté)
**  IA_MAX_NB_SAUTS : nb de sauts à tester au max dans la recherche
**/
#define IA_MODE         1
#define IA_PROFONDEUR   2
#define IA_MAX_NB_SAUTS 10

/*********************************************************************************
 *                                  STRUCTURES                                   *
 *********************************************************************************/

/***** Structure move *****/
struct move {
	int num_pion;
	int directions[IA_MAX_NB_SAUTS];
	struct move *Next;
};

/***** Structure max_move *****/
struct max_move {
	int valeur;
	int num_pion;
	int directions[IA_MAX_NB_SAUTS];
};

/*********************************************************************************
 *                                  PROTOTYPES                                   *
 *********************************************************************************/
int IA_CalculValeurPoint(int);
int IA_EvalJeu(struct jeu *, int);
void IA_SetMoveDirections(int [], int []);
struct max_move * IA_ForEachMove_Max(struct move *, int, struct jeu *, int, int, int);
struct max_move * IA_ForEachMove_Min(struct move *, int, struct jeu *, int, int, int);
struct move * IA_PossibleMoves(struct pion *);
struct move * IA_PossibleJumpMoves(struct move *, struct pion *, int, int [], int);
struct max_move * IA_BestMove(struct jeu *, int);

void FreeMove(struct move *);
struct move * InitMove(int, int);
struct move * InitMoveJump(int, int [], int);

struct max_move * InitMaxMove(int);
void FreeMaxMove(struct max_move *);

struct max_move * IA_MinMax(struct jeu *, int, int, int);

int JouePionMove(struct pion *, int []);
int JouePionMoveReverse(struct pion *, int []);

int Ask_NbOrdinateurs(struct jeu *, int);
void InitOrdinateurs(struct jeu *, int);

/*********************************************************************************
 *                                  FONCTIONS                                    */
/*********************************************************************************
**  Initialise les ordinateurs
**/
void InitOrdinateurs(struct jeu *Jeu, int nb_ordinateurs) {
	int nb_joueurs = 0, i;
	char tmp[256];
	// compte le nb de joueurs humains
	while(Jeu->Joueurs[nb_joueurs] != NULL) {
		nb_joueurs++;
	}
	for(i=nb_joueurs; i<nb_joueurs+nb_ordinateurs; i++) {
		sprintf(tmp, "Ordinateur %d", i+1);
		Jeu->Joueurs[i] = InitJoueur(i+1, tmp, Jeu->Plateau, JOUEUR_ARTIFICIEL);
	}
}

/*********************************************************************************
**  Demande le nb d'ordinateurs
**/
int Ask_NbOrdinateurs(struct jeu *Jeu, int nb_joueurs) {
	int nb_ordinateurs = 99;
	char tmp[256];
	
	while (nb_ordinateurs > 6 - nb_joueurs) {
		printf("\nNombre d'ordinateurs = ");
		scanf("%s", tmp);
		if (IsInteger(tmp)) {
			nb_ordinateurs = GetInteger(tmp);
			if (nb_ordinateurs > 6 - nb_joueurs) {
				AfficheChaine("/!\\ Hum ... maximum 6 joueurs au total /!\\\n", ANSI_ROUGE, PAS_SOULIGNE);
			}
		} else { // autre chose qu'un entier a été saisi
			CheckExit(tmp, Jeu);
			AfficheChaine("/!\\ Hum ... savez-vous ce qu'est un entier ? ... MDR ... /!\\\n", ANSI_ROUGE, PAS_SOULIGNE);
			nb_ordinateurs = 99; // pour que la boucle continue
		}
	}
	if (nb_ordinateurs < 2 - nb_joueurs) { // pas d'ordinateur => exit fin du pgm
		AfficheChaine("/!\\ Heu ... pas d'ordinateur => pas de jeu ... bye ... /!\\\n\n",ANSI_ROUGE, PAS_SOULIGNE);
		ExitGame(Jeu);
	}
	return nb_ordinateurs;
}

/*********************************************************************************
**  joue le pion dans la suite de directions et retourne 0 si un saut a été fait 
**  (1 si saut, 0 sinon)
**/
int JouePionMove(struct pion *p, int directions[IA_MAX_NB_SAUTS]) {
	int i = 0, saut;
	while (directions[i] != 0) {
		// AfficheDebug1Int("        Joue %d", directions[i]);
		saut = JouePion(p, directions[i]);
		i++;
	}
	return saut;
}

/*********************************************************************************
**  joue le pion dans la suite inverse de directions et retourne 0 si un saut a
**  été fait (1 si saut, 0 sinon)
**/
int JouePionMoveReverse(struct pion *p, int directions[IA_MAX_NB_SAUTS]) {
	int i = 0, saut;
	while (directions[i] != 0) { i++; }
	i--;
	while (i >= 0) {
		saut = JouePion(p, Direction_Opposee(directions[i]));
		i--;
	}
	return saut;
}

/*********************************************************************************
**  initialise un objet move
**/
struct max_move * InitMaxMove(int valeur) {
	struct max_move *Max_Move = (struct max_move *)malloc(sizeof(struct max_move));
	int i;
	Max_Move->valeur = valeur;
	Max_Move->num_pion = -1;
	for(i=0; i<IA_MAX_NB_SAUTS; i++) {
		Max_Move->directions[i] = 0;
	}
	return Max_Move;
}

/*********************************************************************************
**  free move structure
**/
void FreeMaxMove(struct max_move *Max_Move) {
	if (Max_Move != NULL) {
		free(Max_Move);
	}
}

/*********************************************************************************
**  initialise un objet move
**/
struct move * InitMove(int num_pion, int direction) {
	struct move *Move = (struct move *)malloc(sizeof(struct move));
	int i;
	Move->num_pion = num_pion;
	for(i=0; i<IA_MAX_NB_SAUTS; i++) {
		Move->directions[i] = 0;
	}
	Move->directions[0] = direction;
	Move->Next = NULL;
	return Move;
}

/*********************************************************************************
**  initialise un objet move en copiant les directions d'un autre move
**/
struct move * InitMoveJump(int num_pion, int directions[IA_MAX_NB_SAUTS], int direction) {
	struct move *Move = (struct move *)malloc(sizeof(struct move));
	int i = 0;
	Move->num_pion = num_pion;
	while (directions[i] != 0) {
		Move->directions[i] = directions[i];
		i++;
	}
	Move->directions[i] = direction;
	Move->directions[i+1] = 0;
	Move->Next = NULL;
	return Move;
}

/*********************************************************************************
**  free move structure
**/
void FreeMove(struct move *Move) {
	if (Move != NULL) {
		if (Move->Next != NULL) { FreeMove(Move->Next); }
		free(Move);
	}
}

/*********************************************************************************
**  modifie num_pion et direction pour avoir le meilleur mouvement
**/
struct max_move * IA_BestMove(struct jeu *Jeu, int num_joueur) {
	struct max_move *max = IA_MinMax(Jeu, num_joueur, num_joueur, IA_PROFONDEUR);
	//AfficheDebug2Int("Meilleur mouvement => pion n°%d   direction %d", max->num_pion, max->directions[0]);
	return max;
}

/*********************************************************************************
**  recursive => store in int array all directions used (jumps)
**/
void IA_SetMoveDirections(int directions_src[IA_MAX_NB_SAUTS], int directions_dest[IA_MAX_NB_SAUTS]) {
	int i = 0;
	while(directions_src[i] != 0) {
		directions_dest[i] = directions_src[i];
		i++;
	}
	if (i<IA_MAX_NB_SAUTS) {
		directions_dest[i] = 0;
	}
}

/*********************************************************************************
**  Max
**/
struct max_move * IA_ForEachMove_Max(struct move *Move, int num_pion, struct jeu *Jeu, int num_joueur, int joueur_who_moves, int profondeur) {
	struct max_move *max, *Max_Move;
	int next_joueur;
	max = InitMaxMove(-99999);
	while(Move != NULL) {
		next_joueur = NextJoueur(Jeu, joueur_who_moves);
		JouePionMove(Jeu->Joueurs[joueur_who_moves - 1]->Pions[num_pion], Move->directions);
		if (NbPionsArrives(Jeu->Plateau, num_joueur) == 10 && profondeur == IA_PROFONDEUR) {
			Max_Move = InitMaxMove(99999);
		} else {
			Max_Move = IA_MinMax(Jeu, num_joueur, next_joueur, profondeur - 1);
		}
		JouePionMoveReverse(Jeu->Joueurs[joueur_who_moves - 1]->Pions[num_pion], Move->directions);
		if (Max_Move->valeur > max->valeur) {
			max->valeur = Max_Move->valeur;
			if (profondeur == IA_PROFONDEUR) {
				IA_SetMoveDirections(Move->directions, max->directions);
			}
		}
		FreeMaxMove(Max_Move);
		Move = Move->Next;
	}
	return max;
}

/*********************************************************************************
**  Min
**/
struct max_move * IA_ForEachMove_Min(struct move *Move, int num_pion, struct jeu *Jeu, int num_joueur, int joueur_who_moves, int profondeur) {
	struct max_move *max, *Max_Move;
	int next_joueur;
	max = InitMaxMove(99999);
	while(Move != NULL) {
		next_joueur = NextJoueur(Jeu, joueur_who_moves);
		JouePionMove(Jeu->Joueurs[joueur_who_moves - 1]->Pions[num_pion], Move->directions);
		Max_Move = IA_MinMax(Jeu, num_joueur, next_joueur, profondeur - 1);
		JouePionMoveReverse(Jeu->Joueurs[joueur_who_moves - 1]->Pions[num_pion], Move->directions);
		if (Max_Move->valeur < max->valeur) {
			max->valeur = Max_Move->valeur;
		}
		FreeMaxMove(Max_Move);
		Move = Move->Next;
	}
	return max;
}

/*********************************************************************************
**  MinMax
**/
struct max_move * IA_MinMax(struct jeu *Jeu, int num_joueur, int joueur_who_moves, int profondeur) {
	struct move *Move = NULL;
	struct max_move *Max_Move, *max;
	int num_pion;
	if (profondeur <= 0) {
		Max_Move = InitMaxMove(IA_EvalJeu(Jeu, Jeu->Joueurs[num_joueur - 1]->numero));
		return Max_Move;
	}
	if (joueur_who_moves == num_joueur) {
		max = InitMaxMove(-99999);
		for(num_pion=0; num_pion<=9; num_pion++) { // teste les pions
			Move = IA_PossibleMoves(Jeu->Joueurs[joueur_who_moves - 1]->Pions[num_pion]);
			Max_Move = IA_ForEachMove_Max(Move, num_pion, Jeu, num_joueur, joueur_who_moves, profondeur);
			FreeMove(Move);
			if (Max_Move->valeur > max->valeur) {
				max->valeur = Max_Move->valeur;
				max->num_pion = num_pion;
				IA_SetMoveDirections(Max_Move->directions, max->directions);
			}
			FreeMaxMove(Max_Move);
		}
	} else {
		max = InitMaxMove(99999);
		for(num_pion=0; num_pion<=9; num_pion++) { // teste les pions
			Move = IA_PossibleMoves(Jeu->Joueurs[joueur_who_moves - 1]->Pions[num_pion]);
			Max_Move = IA_ForEachMove_Min(Move, num_pion, Jeu, num_joueur, joueur_who_moves, profondeur);
			FreeMove(Move);
			if (Max_Move->valeur < max->valeur) {
				max->valeur = Max_Move->valeur;
			}
			FreeMaxMove(Max_Move);
		}
	}
	return max;
}

/*********************************************************************************
**  retourne tous les mouvements possibles
**/
struct move * IA_PossibleMoves(struct pion *Pion) {
	struct move *FirstMove = NULL;
	struct move *Move;
	int direction, num_cases[IA_MAX_NB_SAUTS], i;
	// initialise le tableau
	for(i=0; i<IA_MAX_NB_SAUTS; i++) {
		num_cases[i] = 0;
	}
	num_cases[0] = Pion->CaseDuPion->numero;
	// teste les directions
	for(direction=1; direction<=6; direction++) {
		if (PionPeutJouer(Pion, direction) > 0) {
			if (FirstMove == NULL) {
				FirstMove = InitMove(Pion->numero, direction);
				Move = FirstMove;
			} else {
				Move->Next = InitMove(Pion->numero, direction);
			}
			if (Move->Next != NULL) {
				Move = Move->Next;
			}
			if (JouePion(Pion, direction) == A_SAUTE) {
				Move = IA_PossibleJumpMoves(Move, Pion, Direction_Opposee(direction), num_cases, 1);
			}
			JouePion(Pion, Direction_Opposee(direction));
		}
	}
	return FirstMove;
}

/*********************************************************************************
**  retourne tous les mouvements encore possibles (sauts)
**/
struct move * IA_PossibleJumpMoves(struct move *FirstMove, struct pion *Pion, int old_direction, int num_cases[IA_MAX_NB_SAUTS], int nb_cases) {
	struct move *Move = FirstMove;
	int direction, i;
	// évite le dépassement de tableau
	if (nb_cases >= IA_MAX_NB_SAUTS-1) { return Move; } 
	// recherche le numéro de la case dans le tableau afin d'éviter de repasser sur une case (bouclage infini)
	for(i=0; i<nb_cases; i++) {
		if (Pion->CaseDuPion->numero == num_cases[i]) {
			return Move;
		}
	}
	num_cases[nb_cases] = Pion->CaseDuPion->numero;
	// teste les direction
	for(direction=1; direction<=6; direction++) {
		if (PionPeutRejouer(Pion, direction, old_direction) > 0) {
			Move->Next = InitMoveJump(Pion->numero, FirstMove->directions, direction);
			JouePion(Pion, direction);
			Move = IA_PossibleJumpMoves(Move->Next, Pion, Direction_Opposee(direction), num_cases, nb_cases+1);
			JouePion(Pion, Direction_Opposee(direction));
		}
	}
	return Move;
}

/*********************************************************************************
**  Evalue le poids des pions d'un jeu vis à vis d'un joueur
**/
int IA_EvalJeu(struct jeu *Jeu, int num_joueur) {
	int i, j, Somme = 0, Val;
	int j1[121] = {	                         1,
			                       2,  2,
			                     4,  4,  4,
			                   6,  6,  6,  6,
			 2,  4,  6,  7,  7,  7,  7,  7,  7,  7,  6,  4,  2,
			   5,  7,  8,  8,  9,  9,  9,  9,  8,  8,  7,  5,
			     8,  9,  9, 10, 10, 11, 10, 10,  9,  9,  8,
			      10, 10, 11, 12, 12, 12, 12, 11, 10, 10,
			        11, 12, 13, 14, 14, 14, 13, 12, 11,
			      11, 13, 14, 15, 16, 16, 15, 14, 13, 11,
			    10, 13, 15, 16, 17, 17, 17, 16, 15, 13, 10,
			   8, 12, 15, 17, 18, 19, 19, 18, 17, 15, 12,  8,
			 6, 10, 14, 17, 19, 20, 21, 20, 19, 17, 14, 10,  6,
			                  21, 22, 22, 21,
			                    23, 23, 23,
			                      24, 24,
			                        25 };
	int j2[121] = {	                        25,
			                      24, 24,
			                    23, 23, 23,
			                  21, 22, 22, 21,
			 6, 10, 14, 17, 19, 20, 21, 20, 19, 17, 14, 10,  6,
			   8, 12, 15, 17, 18, 19, 19, 18, 17, 15, 12,  8,
			    10, 13, 15, 16, 17, 17, 17, 16, 15, 13, 10,
			      11, 13, 14, 15, 16, 16, 15, 14, 13, 11,
			        11, 12, 13, 14, 14, 14, 13, 12, 11,
			      10, 10, 11, 12, 12, 12, 12, 11, 10, 10,
			     8,  9,  9, 10, 10, 11, 10, 10,  9,  9,  8,
			   5,  7,  8,  8,  9,  9,  9,  9,  8,  8,  7,  5,
			 2,  4,  6,  7,  7,  7,  7,  7,  7,  7,  6,  4,  2,
			                   6,  6,  6,  6,
			                     4,  4,  4,
			                       2,  2,
			                         1 };
	int j3[121] = {	                         2,
			                       4,  5,
			                     6,  7,  8,
			                   7,  8,  9, 10,
			 1,  2,  4,  6,  7,  8,  9, 10, 11, 11, 10,  8,  6,
			   2,  4,  6,  7,  9, 10, 11, 12, 13, 13, 12, 10,
			     4,  6,  7,  9, 10, 12, 13, 14, 15, 15, 14,
			       6,  7,  9, 11, 12, 14, 15, 16, 17, 17,
			         7,  9, 10, 12, 14, 16, 17, 18, 19,
			       7,  8, 10, 12, 14, 16, 17, 19, 20, 21,
			     6,  8,  9, 11, 13, 15, 17, 19, 21, 22, 23,
			   4,  7,  9, 10, 12, 14, 16, 18, 20, 22, 23, 24,
			 2,  5,  8, 10, 11, 13, 15, 17, 19, 21, 23, 24, 25,
			                  11, 13, 15, 17,
			                    10, 12, 14,
			                       8, 10,
			                         6 };
	int j4[121] = {	                         6,
			                      10,  8,
			                    14, 12, 10,
			                  17, 15, 13, 11,
			25, 24, 23, 22, 19, 17, 15, 12, 11, 10,  8,  5,  2,
			  24, 23, 21, 20, 18, 16, 13, 12, 10,  9,  7,  4,
			    23, 21, 21, 19, 17, 14, 13, 11,  9,  8,  6,
			      22, 20, 19, 17, 14, 14, 12, 10,  8,  7,
			        19, 18, 17, 14, 14, 12, 10,  9,  7,
			      17, 17, 16, 14, 14, 12, 11,  9,  7,  6,
			    14, 15, 15, 13, 13, 12, 10,  9,  7,  6,  4,
			  10, 12, 13, 12, 12, 11, 10,  9,  7,  6,  4,  2,
			 6,  8, 10, 11, 11, 10,  9,  8,  7,  6,  4,  2,  1,
			                  10,  9,  8,  7,
			                     8,  7,  6,
			                       5,  4,
			                         2 };
	int j5[121] = {	                         2,
			                       5,  4,
			                     8,  7,  6,
			                  10,  9,  8,  7,
			 6,  8, 10, 11, 11, 10,  9,  8,  7,  6,  4,  2,  1,
			  10, 12, 13, 12, 12, 11, 10,  9,  7,  6,  4,  2,
			    14, 15, 15, 13, 13, 12, 10,  9,  7,  6,  4,
			      17, 17, 16, 14, 14, 12, 11,  9,  7,  6,
			        19, 18, 17, 14, 14, 12, 10,  9,  7,
			      22, 20, 19, 17, 14, 14, 12, 10,  8,  7,
			    23, 21, 21, 19, 17, 14, 13, 11,  9,  8,  6,
			  24, 23, 21, 20, 18, 16, 13, 12, 10,  9,  7,  4,
			25, 24, 23, 22, 19, 17, 15, 12, 11, 10,  8,  5,  2,
			                  17, 15, 13, 11,
			                    14, 12, 10,
			                      10,  8,
			                         6 };
	int j6[121] = {	                         6,
			                       8, 10,
			                    10, 12, 14,
			                  11, 13, 15, 17,
			 2,  5,  8, 10, 11, 13, 15, 17, 19, 21, 23, 24, 25,
			   4,  7,  9, 10, 12, 14, 16, 18, 20, 22, 23, 24,
			     6,  8,  9, 11, 13, 15, 17, 19, 21, 22, 23,
			       7,  8, 10, 12, 14, 16, 17, 19, 20, 21,
			         7,  9, 10, 12, 14, 16, 17, 18, 19,
			       6,  7,  9, 11, 12, 14, 15, 16, 17, 17,
			     4,  6,  7,  9, 10, 12, 13, 14, 15, 15, 14,
			   2,  4,  6,  7,  9, 10, 11, 12, 13, 13, 12, 10,
			 1,  2,  4,  6,  7,  8,  9, 10, 11, 11, 10,  8,  6,
			                   7,  8,  9, 10,
			                     6,  7,  8,
			                       4,  5,
			                         2 };
	for(j=0; j<6; j++) { // calcule pour chaque joueur
		if (Jeu->Joueurs[j] != NULL) {
			Val = 0;
			for(i=0; i<10; i++) {
				// calcul de la valeur du pion
				switch(Jeu->Joueurs[j]->numero) { 
					case 1: Val += IA_CalculValeurPoint(j1[Jeu->Joueurs[j]->Pions[i]->CaseDuPion->numero - 1]); break;
					case 2: Val += IA_CalculValeurPoint(j2[Jeu->Joueurs[j]->Pions[i]->CaseDuPion->numero - 1]); break;
					case 3: Val += IA_CalculValeurPoint(j3[Jeu->Joueurs[j]->Pions[i]->CaseDuPion->numero - 1]); break;
					case 4: Val += IA_CalculValeurPoint(j4[Jeu->Joueurs[j]->Pions[i]->CaseDuPion->numero - 1]); break;
					case 5: Val += IA_CalculValeurPoint(j5[Jeu->Joueurs[j]->Pions[i]->CaseDuPion->numero - 1]); break;
					case 6: Val += IA_CalculValeurPoint(j6[Jeu->Joueurs[j]->Pions[i]->CaseDuPion->numero - 1]); break;
				}
				// calcul du nb de déplacements possibles => favorise les situation avec un max de déplacements
				// Val += PionPeutJouer(Jeu->Joueurs[j]->Pions[i], DIRECTION_ALL);
			}
			
			// Bonus de 25 par pion arrivé dans le triangle de destination
			Val += 25 * NbPionsArrives(Jeu->Plateau, j+1);

			if (Jeu->Joueurs[j]->numero == num_joueur) {
				Somme += Val;
				// Bonus de 1000 si gagné
				if (i == 10) { Somme += 1000; }
			} else {
				Somme -= Val;
				// Malus de 250 si un adversaire gagne
				if (i == 10) { Somme -= 250; }
			}
		}
	}
	return Somme;
}

/*********************************************************************************
**  Calcule la valeur du point
**/
int IA_CalculValeurPoint(int x) {
	int mode_1[26] = {   0,  26,  51,  75,  98, 120, 141, 161, 180, 198, 215, 231, 246, 260, 273, 285, 296, 306, 315, 323, 330, 336, 341, 345, 348, 350 };
	int mode_2[26] = {   0,   1,   3,   6,  10,  15,  21,  28,  36,  45,  55,  66,  78,  91, 105, 120, 136, 153, 171, 190, 210, 231, 253, 276, 300, 325 };
	switch(IA_MODE) {
		case 0: return x; break; // linéaire
		case 1: return mode_1[x]; break;
		case 2: return mode_2[x]; break;
	}
	return 0;
}
