/*********************************************************************************
**  STRUCTURES
**/

/***** Structure case *****/
struct MaCase {
	struct MaCase * O;
	struct MaCase * NO;
	struct MaCase * NE;
	struct MaCase * E;
	struct MaCase * SE;
	struct MaCase * SO;
	struct MaCase * Next;
	struct pion * Pion;
	int numero; // de 1 à 121
	int hexagone;
	int num_joueur;
};

/***** Structure plateau *****/
struct plateau {
	struct MaCase * Cases[121];
};

/***** Structure pion *****/
struct pion {
	struct MaCase * CaseDuPion;
	struct joueur * MonJoueur;
	int numero; // de 0 à 9
};

/***** Structure joueur *****/
struct joueur {
	struct pion * Pions[10];
	char nom[256];
	int numero; // de 1 à 6
	int ordinateur;
};

/***** Structure jeu *****/
struct jeu {
	struct joueur *Joueurs[6];
	struct plateau *Plateau;
};
