
/*********************************************************************************
**  Demande le nb de joueurs et le retourne
**/
int Ask_NbJoueurs(struct jeu *Jeu, int min_nombre_joueurs) {
	int nb_joueurs = 99;
	char tmp[256];
	
	while (nb_joueurs > 6) {
		printf("\nNombre de joueurs = ");
		scanf("%s", tmp);
		if (IsInteger(tmp)) {
			nb_joueurs = GetInteger(tmp);
			if (nb_joueurs > 6) {
				AfficheChaine("/!\\ Hum ... maximum 6 cap'taine /!\\\n", ANSI_ROUGE, PAS_SOULIGNE);
			}
		} else { // autre chose qu'un entier a été saisi
			CheckExit(tmp, Jeu);
			AfficheChaine("/!\\ Hum ... savez-vous ce qu'est un entier ? ... MDR ... /!\\\n", ANSI_ROUGE, PAS_SOULIGNE);
			nb_joueurs = 99; // pour que la boucle continue
		}
	}
	if (nb_joueurs < min_nombre_joueurs) { // pas de joueurs => exit fin du pgm
		AfficheChaine("/!\\ Heu ... pas assez de joueurs => pas de jeu ... bye ... /!\\\n\n",ANSI_ROUGE, PAS_SOULIGNE);
		ExitGame(Jeu);
	}
	return nb_joueurs;
}

/*********************************************************************************
**  Demande le nom d'un joueur
**/
void Ask_NomJoueur(struct jeu *Jeu, int num_joueur) {
	char tmp[256];
	
	printf("\nNom du ");
	sprintf(tmp, "Joueur %d", num_joueur);
	AfficheChaine(tmp, num_joueur+1, SOULIGNE);
	printf(" : ");
	scanf("%s", tmp);
	CheckExit(tmp, Jeu);
	Jeu->Joueurs[num_joueur-1] = InitJoueur(num_joueur, tmp, Jeu->Plateau, JOUEUR_HUMAIN);
}

/*********************************************************************************
**  Demande le n° du pion à jouer
**/
int Ask_NumPion(struct jeu *Jeu, int num_joueur) {
	char tmp[256];
	int num_pion = -1;
	
	while (num_pion < 0) {
		printf("Quel pion voulez-vous jouer ? ( ");
		PionsQuiPeuventJouer(Jeu->Joueurs[num_joueur-1]);
		printf(") => ");
		scanf("%s", tmp);
		CheckExit(tmp, Jeu);
		if (IsInteger(tmp) == 0) { // pas entier
			num_pion = -1;
		} else {
			num_pion = GetInteger(tmp);
			if (num_pion < 10) {
				if (PionPeutJouer(GetPion(Jeu->Joueurs[num_joueur-1], num_pion), DIRECTION_ALL) == 0) {
					AfficheChaine("/!\\ Hum ... ce pion ne peut pas jouer voyons ... /!\\\n\n",ANSI_ROUGE, PAS_SOULIGNE);
					num_pion = -1;
				}
			} else {
				AfficheChaine("/!\\ Hum ... vous n'avez pas plus de 10 pions me semble-t-il ... /!\\\n\n",ANSI_ROUGE, PAS_SOULIGNE);
				num_pion = -1;
			}
		}
	}
	return num_pion;
}

/*********************************************************************************
**  Demande le n° du pion à jouer
**/
int Ask_DirectionPion(struct jeu *Jeu, int num_joueur, int num_pion, int old_direction) {
	char tmp[256];
	int num_direction = -1;

	while (num_direction < 0) {
		printf("Dans quelle direction voulez-vous jouer ? (0 pour annuler)\n");
		if (old_direction == DIRECTION_AUCUN) {
			DirectionsPossibles(Jeu->Joueurs[num_joueur-1], num_pion);
		} else {
			DirectionsEncorePossibles(Jeu->Joueurs[num_joueur-1], num_pion, old_direction);
		}
		printf("=> ");
		scanf("%s", tmp);
		CheckExit(tmp, Jeu);
		if (IsInteger(tmp) == 0) { // pas entier
			num_direction = -1;
		} else {
			num_direction = GetInteger(tmp);
			if (num_direction >= 1 && num_direction <= 6) {
				if (old_direction == DIRECTION_AUCUN) {
					if (PionPeutJouer(GetPion(Jeu->Joueurs[num_joueur-1], num_pion), num_direction) == 0 ) {
						AfficheChaine("/!\\ Hum ... direction impossible ... /!\\\n\n", ANSI_ROUGE, PAS_SOULIGNE);
						num_direction = -1;
					}
				} else {
					if (PionPeutRejouer(GetPion(Jeu->Joueurs[num_joueur-1], num_pion), num_direction, old_direction) == 0 ) {
						AfficheChaine("/!\\ Hum ... direction impossible ... /!\\\n\n", ANSI_ROUGE, PAS_SOULIGNE);
						num_direction = -1;
					}
				}
			} else if (num_direction == 0) {
				num_direction = 0;
			} else {
				AfficheChaine("/!\\ Hum ... direction inconnue ... /!\\\n\n",ANSI_ROUGE, PAS_SOULIGNE);
				num_direction = -1;
			}
		}
	}
	return num_direction;
}
