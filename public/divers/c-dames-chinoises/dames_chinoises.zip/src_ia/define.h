/*********************************************************************************
 *                             PARAMETRES MODIFIABLES                            */
/*********************************************************************************
**  Nettoyage du terminal
**     CLEAR_ACTIVE  : active ou non le fait de nettoyer le terminal
**     CLEAR_COMMAND : commande de nettoyage ("clear" sous Nux, "cls" sous Windows)
**/
#define CLEAR_ACTIVE 1
#define CLEAR_COMMAND "clear"

/*********************************************************************************
**  MODE_AFFICHAGE
**     0 => Couleur [ANSI]
**     1 => noir et blanc avec soulignage du joueur en cours [ANSI]
**     2 => noir et blanc (terminal default), à mettre pour windows...
**/
#define MODE_AFFICHAGE 0

/*********************************************************************************
**  nombre d'espaces ' ' à gauche du plateau
**/
#define DECALAGE_PLATEAU 3

/*********************************************************************************
**  MODE_DEBUG
**     0 => pas d'affichage pour débugage
**  
   1 => affichage débugage
**/
#define MODE_DEBUG 0

/*********************************************************************************
 *                                   CONSTANTES                                  */
/*********************************************************************************
**  Directions
**/
#define DIRECTION_AUCUN 0
#define DIRECTION_NO    1
#define DIRECTION_NE    2
#define DIRECTION_O     3
#define DIRECTION_E     4
#define DIRECTION_SO    5
#define DIRECTION_SE    6
#define DIRECTION_ALL   7

/*********************************************************************************
**  Style souligne
**/
#define SOULIGNE     1
#define PAS_SOULIGNE 0

/*********************************************************************************
**  saut
**/
#define A_SAUTE     1
#define A_PAS_SAUTE 0

/*********************************************************************************
**  type de joueur
**/
#define JOUEUR_HUMAIN     0
#define JOUEUR_ARTIFICIEL 1

/*********************************************************************************
**  Codes ANSI pour les couleurs
**     Chiffre x dans [x;
**        0 => couleur foncee
**        1 => couleur claire
**        4 => souligné
**        ( lancer ansi.sh pour voir toutes les possibilités )
**/
#define ANSI_NOIR    0
#define ANSI_ROUGE   1
#define ANSI_VERT    2
#define ANSI_JAUNE   3
#define ANSI_BLEU    4
#define ANSI_VIOLET  5
#define ANSI_CYAN    6
#define ANSI_BLANC   7
