
/*********************************************************************************
**  Affiche des codes Ansi afin que le texte qui suivra sera de la couleur voulue
**/
void TexteCouleur(int color, int underlined) {
	if (MODE_AFFICHAGE == 0) {
		if (underlined == 0) {
			printf("\033[1;3%dm", color);
		} else {
			printf("\033[4;3%dm", color);
		}
	}
}

/*********************************************************************************
**  Affiche des codes Ansi afin que le texte qui suivra sera 'normal'
**/
void TexteNormal(void) {
	if (MODE_AFFICHAGE == 0) {
		printf("\033[0m");
	}
}

/*********************************************************************************
**  Affiche des codes Ansi afin que le texte qui suivra sera souligné
**/
void TexteSouligne(void) {
	if (MODE_AFFICHAGE == 0) {
		printf("\033[4m");
	}
}

/*********************************************************************************
**  Affiche un texte entouré d'un cadre de '*' selon les couleurs voulues
**/
void AfficheCadre(char * chaine, int colortxt, int colorcadre) {
	int n = strlen(chaine), i;
	switch (MODE_AFFICHAGE) {
		case 0:
			printf("\033[1;3%dm", colorcadre);
			for (i=0; i<n+4; i++) { printf("*"); }
			printf("\n* \033[0m");
			AfficheChaine(chaine, colortxt, 0);
			printf("\033[1;3%dm *\n", colorcadre);
			for (i=0; i<n+4; i++) { printf("*"); }
			printf("\033[0m\n");
			break;
		case 1:
			for (i=0; i<n+4; i++) { printf("*"); }
			printf("\n* %s *\n", chaine);
			for (i=0; i<n+4; i++) { printf("*"); }
			printf("\n");
			break;
		case 2:
			for (i=0; i<n+4; i++) { printf("*"); }
			printf("\n* %s *\n", chaine);
			for (i=0; i<n+4; i++) { printf("*"); }
			printf("\n");
			break;
	}
}

/*********************************************************************************
**  Affiche un pion selon son n°
**/
void AffichePion(int npion, int color, int underlined) {
	switch (MODE_AFFICHAGE) {
		case 0:
			//printf("\033[1;4%d;3%dm%d\033[0m", bg, fg, npion); avec fond noir
			printf("\033[1;3%dm%d\033[0m", color, npion);
			break;
		case 1:
			if (underlined == 0) {
				printf("%d", npion);
			} else {
				printf("\033[4m%d\033[0m", npion);
			}
			break;
		case 2:
			printf("%d", npion);
			break;
	}
}

/*********************************************************************************
**  Affiche une chaine colorisée
**/
void AfficheChaine(char * chaine, int color, int underlined) {
	switch (MODE_AFFICHAGE) {
		case 0:
			if (underlined == 0) {
				printf("\033[1;3%dm%s\033[0m", color, chaine);
			} else {
				printf("\033[1m\033[4;3%dm%s\033[0m\033[0m", color, chaine);
			}
			break;
		case 1:
			if (underlined == 0) {
				printf("%s", chaine);
			} else {
				printf("\033[4m%s\033[0m", chaine);
			}
			break;
		case 2:
			printf("%s", chaine);
			break;
	}
}

/*********************************************************************************
**  Affiche un caractère sur le plateau (case vide)
**/
void AfficheChar(char caractere) {
	switch (MODE_AFFICHAGE) {
		case 0:
			printf("\033[0;37m%c\033[0m", caractere);
			break;
		case 1:
			printf("%c", caractere);
			break;
		case 2:
			printf("%c", caractere);
			break;
	}
}

/*********************************************************************************
**  Affiche le plateau de jeu
**/
void AffichePlateau (struct plateau *p, int joueur_num) {
	AfficheLigne(p, DECALAGE_PLATEAU + 13, 1, 1, joueur_num);
	AfficheLigne(p, DECALAGE_PLATEAU + 12, 2, 3, joueur_num);
	AfficheLigne(p, DECALAGE_PLATEAU + 11, 4, 6, joueur_num);
	AfficheLigne(p, DECALAGE_PLATEAU + 10, 7, 10, joueur_num);
	AfficheLigne(p, DECALAGE_PLATEAU + 1, 11, 23, joueur_num);
	AfficheLigne(p, DECALAGE_PLATEAU + 2, 24, 35, joueur_num);
	AfficheLigne(p, DECALAGE_PLATEAU + 3, 36, 46, joueur_num);
	AfficheLigne(p, DECALAGE_PLATEAU + 4, 47, 56, joueur_num);
	AfficheLigne(p, DECALAGE_PLATEAU + 5, 57, 65, joueur_num);
	AfficheLigne(p, DECALAGE_PLATEAU + 4, 66, 75, joueur_num);
	AfficheLigne(p, DECALAGE_PLATEAU + 3, 76, 86, joueur_num);
	AfficheLigne(p, DECALAGE_PLATEAU + 2, 87, 98, joueur_num);
	AfficheLigne(p, DECALAGE_PLATEAU + 1, 99, 111, joueur_num);
	AfficheLigne(p, DECALAGE_PLATEAU + 10, 112, 115, joueur_num);
	AfficheLigne(p, DECALAGE_PLATEAU + 11, 116, 118, joueur_num);
	AfficheLigne(p, DECALAGE_PLATEAU + 12, 119, 120, joueur_num);
	AfficheLigne(p, DECALAGE_PLATEAU + 13, 121, 121, joueur_num);
}

/*********************************************************************************
**  Affiche une ligne du plateau
**/
void AfficheLigne (struct plateau *p, int abscisse, int x1, int x2, int joueur_num) {
	int i = 0;
	struct MaCase *c;
	c = GetCase(p, x1);
	for(i=0; i<abscisse; i++) {
		printf(" ");
	}
	for(i=x1; i<=x2; i++) {
		AfficheCase(c, joueur_num);
		c = c->Next;
	}
	printf("\n");
}

/*********************************************************************************
**  Affiche une case du plateau
**/
void AfficheCase (struct MaCase *c, int joueur_num) {
	if(c->Pion == NULL) {
		if(c->hexagone < 0) {
			AfficheChar('#');
			printf(" ");
		} else {
			AfficheChar('.');
			printf(" ");
		}
	} else {
		if (joueur_num == c->Pion->MonJoueur->numero) {
			AffichePion(c->Pion->numero, c->Pion->MonJoueur->numero + 1, SOULIGNE);
		} else {
			AffichePion(c->Pion->numero, c->Pion->MonJoueur->numero + 1, PAS_SOULIGNE);
		}
		printf(" ");
	}
}
