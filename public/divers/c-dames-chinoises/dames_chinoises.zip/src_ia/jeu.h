
/*********************************************************************************
**  retourne le joueur suivant
**/
int NextJoueur(struct jeu *Jeu, int num_joueur) {
	int next_joueur = num_joueur + 1;
	if (next_joueur > 6) { // pas plus de 6 joueurs
		next_joueur = 1;
	} else {
		if (Jeu->Joueurs[next_joueur - 1] == NULL) { // pas de joueur suivant
			next_joueur = 1;
		}
	}
	return next_joueur;
}

/*********************************************************************************
**  retourne le n° du joueur gagnant ou 0 si personne n'a gagné
**/
int JeuEstFini(struct plateau *p, struct joueur *joueurs[6]) {
	// cas du joueur 1
	if (joueurs[0]!= NULL) {
		if (NbPionsArrives(p, 1) == 10) { return 1; }
	}
	// cas du joueur 2
	if (joueurs[1]!= NULL) {
		if (NbPionsArrives(p, 2) == 10) { return 2; }
	}
	// cas du joueur 3
	if (joueurs[2]!= NULL) {
		if (NbPionsArrives(p, 3) == 10) { return 3; }
	}
	// cas du joueur 4
	if (joueurs[3]!= NULL) {
		if (NbPionsArrives(p, 4) == 10) { return 4; }
	}
	// cas du joueur 5
	if (joueurs[4]!= NULL) {
		if (NbPionsArrives(p, 5) == 10) { return 5; }
	}
	// cas du joueur 6
	if (joueurs[5]!= NULL) {
		if (NbPionsArrives(p, 6) == 10) { return 6; }
	}
	return 0;
}

/*********************************************************************************
**  retourne le nb de pions arrivés
**/
int NbPionsArrives(struct plateau *p, int num_joueur) {
	struct MaCase *c;
	int j1[10] = {   1,   2,   3,   4,   5,   6,   7,   8,   9,  10 };
	int j2[10] = { 112, 113, 114, 115, 116, 117, 118, 119, 120, 121 };
	int j3[10] = {  11,  12,  13,  14,  24,  25,  26,  36,  37,  47 };
	int j4[10] = {  75,  85,  86,  96,  97,  98, 108, 109, 110, 111 };
	int j5[10] = {  20,  21,  22,  23,  33,  34,  35,  45,  46,  56 };
	int j6[10] = {  66,  76,  77,  87,  88,  89,  99, 100, 101, 102 };
	int *cases, i, n = 0;
	switch(num_joueur) {
		case 1: cases = j2; break;
		case 2: cases = j1; break;
		case 3: cases = j4; break;
		case 4: cases = j3; break;
		case 5: cases = j6; break;
		case 6: cases = j5; break;
	}
	for(i=0; i<10; i++) {
		c = GetCase(p, cases[i]);
		if (c->Pion != NULL) {
			if (c->Pion->MonJoueur->numero == num_joueur) {
				n++;
			}
		}
	}
	return n;
}

/*********************************************************************************
**  retourne si le pion peut se déplacer dans la case indiquée
**/
int ZoneAutorisee(struct pion *p, struct MaCase *c) {
	// la case doit etre dans l'etoile
	if (c == NULL) { return 0; }
	
	// la case doit etre vide
	if (c->Pion != NULL) { return 0; }
	
	// la case peut etre dans l'hexagone
	if (c->hexagone == 1) { return 1; }
	
	// la case peut etre dans le triangle de n'importe quel joueur
	if (c->num_joueur > 0) { return 1; }

	return 0; // pour la compilation ... sinon sert à rien.
}

/*********************************************************************************
**  retourne la direction opposée à celle choisie
**/
int Direction_Opposee(int direction) {
	switch(direction) {
		case DIRECTION_NO: return DIRECTION_SE; break;
		case DIRECTION_NE: return DIRECTION_SO; break;
		case DIRECTION_O:  return DIRECTION_E;  break;
		case DIRECTION_E:  return DIRECTION_O;  break;
		case DIRECTION_SO: return DIRECTION_NE; break;
		case DIRECTION_SE: return DIRECTION_NO; break;
	}
	return 0; // pour éviter erreur à la compilation
}

/*********************************************************************************
**  joue le pion et retourne 0 si un saut a été fait (1 si saut, 0 sinon)
**/
int JouePion(struct pion *p, int direction) {
	struct MaCase *c = p->CaseDuPion;
	int saut = 0;
	switch(direction) {
		case DIRECTION_NO:
			if (c->NO->Pion != NULL) {
				c->NO->NO->Pion = p;
				p->CaseDuPion = c->NO->NO;
				saut = 1;
			} else {
				c->NO->Pion = p;
				p->CaseDuPion = c->NO;
			}
			break;
		case DIRECTION_NE:
			if (c->NE->Pion != NULL) {
				c->NE->NE->Pion = p;
				p->CaseDuPion = c->NE->NE;
				saut = 1;
			} else {
				c->NE->Pion = p;
				p->CaseDuPion = c->NE;
			}
			break;
		case DIRECTION_O:
			if (c->O->Pion != NULL) {
				c->O->O->Pion = p;
				p->CaseDuPion = c->O->O;
				saut = 1;
			} else {
				c->O->Pion = p;
				p->CaseDuPion = c->O;
			}
			break;
		case DIRECTION_E:
			if (c->E->Pion != NULL) {
				c->E->E->Pion = p;
				p->CaseDuPion = c->E->E;
				saut = 1;
			} else {
				c->E->Pion = p;
				p->CaseDuPion = c->E;
			}
			break;
		case DIRECTION_SO:
			if (c->SO->Pion != NULL) {
				c->SO->SO->Pion = p;
				p->CaseDuPion = c->SO->SO;
				saut = 1;
			} else {
				c->SO->Pion = p;
				p->CaseDuPion = c->SO;
			}
			break;
		case DIRECTION_SE:
			if (c->SE->Pion != NULL) {
				c->SE->SE->Pion = p;
				p->CaseDuPion = c->SE->SE;
				saut = 1;
			} else {
				c->SE->Pion = p;
				p->CaseDuPion = c->SE;
			}
			break;
	}
	c->Pion = NULL;
	return saut;
}

/*********************************************************************************
**  affiche la liste des pions qui peuvent jouer
**/
void DirectionsPossibles(struct joueur *j, int num_pion) {
	struct pion *p = GetPion(j, num_pion);
	printf("   ");
	if (PionPeutJouer(p, DIRECTION_NO) == 1) {
		AfficheChaine("1", j->numero + 1, PAS_SOULIGNE);
		printf("\\ ");
	} else {
		printf(" \\ ");
	}
	if (PionPeutJouer(p, DIRECTION_NE) == 1) {
		printf("/");
		AfficheChaine("2", j->numero + 1, PAS_SOULIGNE);
		printf(" \n");
	} else { 
		printf("/  \n");
	}
	printf("   ");
	if (PionPeutJouer(p, DIRECTION_O) == 1) {
		printf("-");
		AfficheChaine("3", j->numero + 1, PAS_SOULIGNE);
		printf(" ");
	} else {
		printf("-  ");
	}
	if (PionPeutJouer(p, DIRECTION_E) == 1) {
		AfficheChaine("4", j->numero + 1, PAS_SOULIGNE);
		printf("-\n");
	} else {
		printf(" - \n");
	}
	printf("   ");
	if (PionPeutJouer(p, DIRECTION_SO) == 1) {
		AfficheChaine("5", j->numero + 1, PAS_SOULIGNE);
		printf("/ ");
	} else {
		printf(" / ");
	}
	if (PionPeutJouer(p, DIRECTION_SE) == 1) {
		printf("\\");
		AfficheChaine("6", j->numero + 1, PAS_SOULIGNE);
		printf(" \n");
	} else {
		printf("\\  \n");
	}
}

/*********************************************************************************
**  affiche la liste des pions qui peuvent jouer
**/
void DirectionsEncorePossibles(struct joueur *j, int num_pion, int direction_precedente) {
	struct pion *p = GetPion(j, num_pion);
	printf("   ");
	if (PionPeutRejouer(p, DIRECTION_NO, direction_precedente) == 1 ) {
		AfficheChaine("1", j->numero + 1, PAS_SOULIGNE);
		printf("\\ ");
	} else {
		printf(" \\ ");
	}
	if (PionPeutRejouer(p, DIRECTION_NE, direction_precedente) == 1 ) {
		printf("/");
		AfficheChaine("2", j->numero + 1, PAS_SOULIGNE);
		printf(" \n");
	} else { 
		printf("/  \n");
	}
	printf("   ");
	if (PionPeutRejouer(p, DIRECTION_O, direction_precedente) == 1 ) {
		printf("-");
		AfficheChaine("3", j->numero + 1, PAS_SOULIGNE);
		printf(" ");
	} else {
		printf("-  ");
	}
	if (PionPeutRejouer(p, DIRECTION_E, direction_precedente) == 1 ) {
		AfficheChaine("4", j->numero + 1, PAS_SOULIGNE);
		printf("-\n");
	} else {
		printf(" - \n");
	}
	printf("   ");
	if (PionPeutRejouer(p, DIRECTION_SO, direction_precedente) == 1 ) {
		AfficheChaine("5", j->numero + 1, PAS_SOULIGNE);
		printf("/ ");
	} else {
		printf(" / ");
	}
	if (PionPeutRejouer(p, DIRECTION_SE, direction_precedente) == 1 ) {
		printf("\\");
		AfficheChaine("6", j->numero + 1, PAS_SOULIGNE);
		printf(" \n");
	} else {
		printf("\\  \n");
	}
}

/*********************************************************************************
**  affiche la liste des pions qui peuvent jouer
**/
void PionsQuiPeuventJouer(struct joueur *j) {
	int i;
	TexteCouleur(j->numero + 1, PAS_SOULIGNE);
	// parcoure les pions
	for (i=0; i<10; i++) {
		if (PionPeutJouer(j->Pions[i], DIRECTION_ALL) > 0) {
			printf("%d ", j->Pions[i]->numero);
		}
	}
	TexteNormal();
}

/*********************************************************************************
**  indique le nb de déplacements possibles pour un pion
**/
int PionPeutJouer(struct pion *Pion, int direction) {
	struct MaCase *c = Pion->CaseDuPion;
	int n = 0;
	if(direction == DIRECTION_NO || direction == DIRECTION_ALL) {
		n += ZoneAutorisee(Pion, c->NO);
	}
	if(direction == DIRECTION_NE || direction == DIRECTION_ALL) {
		n += ZoneAutorisee(Pion, c->NE);
	} 
	if(direction == DIRECTION_O || direction == DIRECTION_ALL) {
		n += ZoneAutorisee(Pion, c->O);
	}
	if(direction == DIRECTION_E || direction == DIRECTION_ALL) {
		n += ZoneAutorisee(Pion, c->E);
	}
	if(direction == DIRECTION_SO || direction == DIRECTION_ALL) {
		n += ZoneAutorisee(Pion, c->SO);
	}
	if(direction == DIRECTION_SE || direction == DIRECTION_ALL) {
		n += ZoneAutorisee(Pion, c->SE);
	}
	n += PionPeutRejouer(Pion, direction, DIRECTION_ALL);
	return n;
}

/*********************************************************************************
**  retourne le nb de déplacements encore possibles pour un pion
**/
int PionPeutRejouer(struct pion *Pion, int direction, int direction_precedente) {
	struct MaCase *c = Pion->CaseDuPion;
	int n = 0;
	if(direction_precedente != DIRECTION_NO && (direction == DIRECTION_NO || direction == DIRECTION_ALL)) {
		if (c->NO != NULL) {
			if (c->NO->Pion != NULL) {
				n += ZoneAutorisee(Pion, c->NO->NO);
			}
		}
	}
	if(direction_precedente != DIRECTION_NE && (direction == DIRECTION_NE || direction == DIRECTION_ALL)) {
		if (c->NE != NULL) {
			if (c->NE->Pion != NULL) {
				n += ZoneAutorisee(Pion, c->NE->NE);
			}
		}
	} 
	if(direction_precedente != DIRECTION_O && (direction == DIRECTION_O || direction == DIRECTION_ALL)) {
		if (c->O != NULL) {
			if (c->O->Pion != NULL) {
				n += ZoneAutorisee(Pion, c->O->O);
			}
		}
	}
	if(direction_precedente != DIRECTION_E && (direction == DIRECTION_E || direction == DIRECTION_ALL)) {
		if (c->E != NULL) {
			if (c->E->Pion != NULL) {
				n += ZoneAutorisee(Pion, c->E->E);
			}
		}
	}
	if(direction_precedente != DIRECTION_SO && (direction == DIRECTION_SO || direction == DIRECTION_ALL)) {
		if (c->SO != NULL) {
			if (c->SO->Pion != NULL) {
				n += ZoneAutorisee(Pion, c->SO->SO);
			}
		}
	}
	if(direction_precedente != DIRECTION_SE && (direction == DIRECTION_SE || direction == DIRECTION_ALL)) {
		if (c->SE != NULL) {
			if (c->SE->Pion != NULL) {
				n += ZoneAutorisee(Pion, c->SE->SE);
			}
		}
	}
	return n;
}
