/*********************************************************************************
**  DANS CE FIHIER SE TROUVENT TOUTES LES FONCTIONS AYANT SERVI AU DEBUGAGE
**  ET AUTRES UTILITARES DE CONTROLES
**/

/*********************************************************************************
**  Affiche une chaine pour aider à débuger => cf define.h pour activer/désactiver
**/
void AfficheDebugStart(char *texte) {
	if (MODE_DEBUG == 1) {
		AfficheChaine("* DEBUG * ", ANSI_ROUGE, PAS_SOULIGNE);
		AfficheChaine(texte, ANSI_VERT, PAS_SOULIGNE);
	}
}
void AfficheDebugBody(char *texte) {
	if (MODE_DEBUG == 1) {
		AfficheChaine(texte, ANSI_VERT, PAS_SOULIGNE);
	}
}
void AfficheDebugBody1Int(char *texte, int v1) {
	if (MODE_DEBUG == 1) {
		TexteCouleur(ANSI_VERT, PAS_SOULIGNE);
		printf(texte, v1);
		TexteNormal();
	}
}
void AfficheDebugEnd(char *texte) {
	if (MODE_DEBUG == 1) {
		AfficheChaine(texte, ANSI_VERT, PAS_SOULIGNE);
		printf("\n");
	}
}
void AfficheDebug(char *texte) {
	if (MODE_DEBUG == 1) {
		AfficheChaine("* DEBUG * ", ANSI_ROUGE, PAS_SOULIGNE);
		AfficheChaine(texte, ANSI_VERT, PAS_SOULIGNE);
		printf("\n");
	}
}
void AfficheDebug1Int(char *texte, int v1) {
	if (MODE_DEBUG == 1) {
		AfficheChaine("* DEBUG * ", ANSI_ROUGE, PAS_SOULIGNE);
		TexteCouleur(ANSI_VERT, PAS_SOULIGNE);
		printf(texte, v1);
		TexteNormal();
		printf("\n");
	}
}
void AfficheDebug2Int(char *texte, int v1, int v2) {
	if (MODE_DEBUG == 1) {
		AfficheChaine("* DEBUG * ", ANSI_ROUGE, PAS_SOULIGNE);
		TexteCouleur(ANSI_VERT, PAS_SOULIGNE);
		printf(texte, v1, v2);
		TexteNormal();
		printf("\n");
	}
}

/*********************************************************************************
**  Affiche les liens (pointeurs entre cases du plateau) => CONTROLE DES LIENS
**     pos1, pos2, pos3 sont soient à 1 soit à 0 (actif / inactif)
**        pos1 : affiche les n° des cases pointées par les liens NO et NE (supérieur)
**        pos2 : affiche le n° de la case courante
**        pos3 : affiche les n° des cases pointées par les liens SO et SE (inférieur)
**     ex : avec pos1=0, pos2=0, pos3=0
**         \ /
**        -   -
**         / \
**     ex : avec pos1=1, pos2=1, pos3=0
**         28 29
**        - 38 -
**         / \
**/
void AfficheLienPlateau (struct plateau *p, int pos1, int pos2, int pos3) {
	AfficheLienLigneH(p,39,1,1, pos1);
	AfficheLienLigneM(p,39,1,1, pos2);
	AfficheLienLigneB(p,39,1,1, pos3);
	AfficheLienLigneH(p,36,2,3, pos1);
	AfficheLienLigneM(p,36,2,3, pos2);
	AfficheLienLigneB(p,36,2,3, pos3);
	AfficheLienLigneH(p,33,4,6, pos1);
	AfficheLienLigneM(p,33,4,6, pos2);
	AfficheLienLigneB(p,33,4,6, pos3);
	AfficheLienLigneH(p,30,7,10, pos1);
	AfficheLienLigneM(p,30,7,10, pos2);
	AfficheLienLigneB(p,30,7,10, pos3);
	AfficheLienLigneH(p,3,11,23, pos1);
	AfficheLienLigneM(p,3,11,23, pos2);
	AfficheLienLigneB(p,3,11,23, pos3);
	AfficheLienLigneH(p,6,24,35, pos1);
	AfficheLienLigneM(p,6,24,35, pos2);
	AfficheLienLigneB(p,6,24,35, pos3);
	AfficheLienLigneH(p,9,36,46, pos1);
	AfficheLienLigneM(p,9,36,46, pos2);
	AfficheLienLigneB(p,9,36,46, pos3);
	AfficheLienLigneH(p,12,47,56, pos1);
	AfficheLienLigneM(p,12,47,56, pos2);
	AfficheLienLigneB(p,12,47,56, pos3);
	AfficheLienLigneH(p,15,57,65, pos1);
	AfficheLienLigneM(p,15,57,65, pos2);
	AfficheLienLigneB(p,15,57,65, pos3);
	AfficheLienLigneH(p,12,66,75, pos1);
	AfficheLienLigneM(p,12,66,75, pos2);
	AfficheLienLigneB(p,12,66,75, pos3);
	AfficheLienLigneH(p,9,76,86, pos1);
	AfficheLienLigneM(p,9,76,86, pos2);
	AfficheLienLigneB(p,9,76,86, pos3);
	AfficheLienLigneH(p,6,87,98, pos1);
	AfficheLienLigneM(p,6,87,98, pos2);
	AfficheLienLigneB(p,6,87,98, pos3);
	AfficheLienLigneH(p,3,99,111, pos1);
	AfficheLienLigneM(p,3,99,111, pos2);
	AfficheLienLigneB(p,3,99,111, pos3);
	AfficheLienLigneH(p,30,112,115, pos1);
	AfficheLienLigneM(p,30,112,115, pos2);
	AfficheLienLigneB(p,30,112,115, pos3);
	AfficheLienLigneH(p,33,116,118, pos1);
	AfficheLienLigneM(p,33,116,118, pos2);
	AfficheLienLigneB(p,33,116,118, pos3);
	AfficheLienLigneH(p,36,119,120, pos1);
	AfficheLienLigneM(p,36,119,120, pos2);
	AfficheLienLigneB(p,36,119,120, pos3);
	AfficheLienLigneH(p,39,121,121, pos1);
	AfficheLienLigneM(p,39,121,121, pos2);
	AfficheLienLigneB(p,39,121,121, pos3);
}

/*********************************************************************************
**  Affiche la ligne supérieure (H comme Haut)
**/
void AfficheLienLigneH (struct plateau *p, int abscisse, int x1, int x2, int pos) {
	int i=0;
	struct MaCase *c;
	c=GetCase(p,x1);
	for(i=0;i<abscisse;i++) { printf(" "); }
	for(i=x1;i<=x2;i++) {
		AfficheLienCaseH(c,pos);
		c = c->Next;
	}
	printf("\n");
}

/*********************************************************************************
**  Affiche la ligne du milieu (M comme Milieu)
**/
void AfficheLienLigneM (struct plateau *p, int abscisse, int x1, int x2, int pos) {
	int i=0;
	struct MaCase *c;
	c=GetCase(p,x1);
	for(i=0;i<abscisse;i++) { printf(" "); }
	for(i=x1;i<=x2;i++) {
		AfficheLienCaseM(c,pos);
		c = c->Next;
	}
	printf("\n");
}

/*********************************************************************************
**  Affiche la ligne inférieure (B comme Bas)
**/
void AfficheLienLigneB (struct plateau *p, int abscisse, int x1, int x2, int pos) {
	int i=0;
	struct MaCase *c;
	c=GetCase(p,x1);
	for(i=0;i<abscisse;i++) { printf(" "); }
	for(i=x1;i<=x2;i++) {
		AfficheLienCaseB(c,pos);
		c = c->Next;
	}
	printf("\n");
}

/*********************************************************************************
**  Affiche un entier sur 3 caractères (ex : ' 56', ' 5 ', '110')
**/
void AfficheLienNum (int num) {
	if(num <10) {printf(" %d ",num);}
	else if (num <100) {printf(" %d",num);}
	else {printf("%d",num);}
}

/*********************************************************************************
**  Affiche la case d'une ligne supérieure
**/
void AfficheLienCaseH (struct MaCase *c, int pos) {
	if(pos == 1) {
		if(c->NO != NULL) { AfficheLienNum(c->NO->numero); } else { printf("   "); }
		if(c->NE != NULL) { AfficheLienNum(c->NE->numero); } else { printf("   "); }
	} else {
		if(c->NO != NULL) { printf(" \\ "); } else { printf("   "); }
		if(c->NE != NULL) { printf("/  "); } else { printf("   "); }
	}
}

/*********************************************************************************
**  Affiche la case d'une ligne du mileu
**/
void AfficheLienCaseM (struct MaCase *c, int pos) {
	if(pos == 1) {
		if(c->O != NULL) { printf(" "); } else { printf(" "); }
		AfficheLienNum(c->numero);
		if(c->E != NULL) { printf("- "); } else { printf("  "); }
	} else {
		if(c->O != NULL) { printf("-  "); } else { printf("   "); }
		if(c->E != NULL) { printf(" - "); } else { printf("   "); }
	}
}

/*********************************************************************************
**  Affiche la case d'une ligne inférieure
**/
void AfficheLienCaseB (struct MaCase *c, int pos) {
	if(pos == 1) {
		if(c->SO != NULL) { AfficheLienNum(c->SO->numero); } else { printf("   "); }
		if(c->SE != NULL) { AfficheLienNum(c->SE->numero); } else { printf("   "); }
	} else {
		if(c->SO != NULL) { printf(" / "); } else { printf("   "); }
		if(c->SE != NULL) { printf("\\  "); } else { printf("   "); }
	}
}
/*********************************************************************************/
