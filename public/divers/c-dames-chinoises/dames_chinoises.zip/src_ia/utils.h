
/*********************************************************************************
**  Vérifie si on doit quitter le jeu
**/
void CheckExit(char *chaine, struct jeu *Jeu) {
	if (strcmp(chaine, "exit") == 0 || strcmp(chaine, "quit") == 0) {
		ExitGame(Jeu);
	}
}

/*********************************************************************************
**  Quitte le jeu proprement
**/
void ExitGame(struct jeu *Jeu) {
	FreeJeu(Jeu);
	exit(0);
}

/*********************************************************************************
**  nettoie l'écran
**/
void ClearScreen(void) {
	if (CLEAR_ACTIVE == 1) {
		system(CLEAR_COMMAND);
	}
}

/*********************************************************************************
**  retourne si la chaine est un entier (0=non, 1=oui)
**/
int IsInteger(char *chaine) {
	int n = strlen(chaine);
	int i;
	int ok = 1;
	for (i=0; i<n; i++) {
		if (chaine[i] < '0' || chaine[i] >'9') {
			ok = 0;
		}
	}
	return ok;
}

/*********************************************************************************
**  retourne l'entier à partir de la chaine
**  algo simple si nb = 'abcd', alors valeur = ( (a*10 + b)*10 + c)*10 + d
**  on suppose que le nombre ne dépasse pas 6 caractères : évite l'overflow d'entier
**/
int GetInteger(char *chaine) {
	int n = strlen(chaine);
	int i;
	int valeur = 0;
	if (n > 6) { n = 6; } // limite le nb de chiffres
	for (i=0; i<n; i++) {
		// le chiffre c'est le code ascii du chiffre moins le code ascii de 0
		// heureusement que les codes ascii sont triés dans le bon ordre :D
		valeur = valeur*10 + chaine[i]-'0';
	}
	return valeur;
}

/*********************************************************************************
**  retourne le pion numéro 'num' d'un joueur
**/
struct pion * GetPion(struct joueur *j, int num) {
	return j->Pions[num];
}

/*********************************************************************************
**  retourne la case numéro 'num' du plateau
**/
struct MaCase * GetCase(struct plateau *p, int num) {
	return p->Cases[num - 1];
}
