
/*********************************************************************************
**  Initialise un objet joueur avec son nom et ses liens au plateau de jeu
**/
struct jeu * InitJeu (void) {
	struct jeu *Jeu = (struct jeu *)malloc(sizeof(struct jeu));
	int i;
	Jeu->Plateau = InitPlateau();
	for(i=0; i<6; i++) {
		Jeu->Joueurs[i] = NULL;
	}
	AfficheDebug("Initialisation du Jeu");
	return Jeu;
}

/*********************************************************************************
**  Initialise un objet joueur avec son nom et ses liens au plateau de jeu
**/
struct joueur * InitJoueur (int numero_joueur, char nom[256], struct plateau *pl, int type_joueur) {
	struct joueur *j;
	int i=0;

	AfficheDebug1Int("Initialisation du Joueur n°%d", numero_joueur);

	// création de l'objet joueur
	j = (struct joueur *)malloc(sizeof(struct joueur)); //espace à réserver est celui du struct et pas le pointeur
	j->numero = numero_joueur;
	j->ordinateur = type_joueur;
	strcpy(j->nom,nom);

	// init des pions
	for(i=0; i<=9; i++) {
		j->Pions[i] = InitPion(i, j);
	}

	// init des liens cases <=> pions
	switch(numero_joueur) {
		case 1:
			// les 10 premiers éléments sont liés tout bêtement
			for(i=0;i<=9;i++) {
				InitPionCase(GetPion(j,i),GetCase(pl,i+1));
			}
			break;
		case 2:
			InitPionCase(GetPion(j,0),GetCase(pl,121));
			InitPionCase(GetPion(j,1),GetCase(pl,119));
			InitPionCase(GetPion(j,2),GetCase(pl,120));
			InitPionCase(GetPion(j,3),GetCase(pl,116));
			InitPionCase(GetPion(j,4),GetCase(pl,117));
			InitPionCase(GetPion(j,5),GetCase(pl,118));
			InitPionCase(GetPion(j,6),GetCase(pl,112));
			InitPionCase(GetPion(j,7),GetCase(pl,113));
			InitPionCase(GetPion(j,8),GetCase(pl,114));
			InitPionCase(GetPion(j,9),GetCase(pl,115));
			break;
		case 3:
			InitPionCase(GetPion(j,0),GetCase(pl,11));
			InitPionCase(GetPion(j,1),GetCase(pl,24));
			InitPionCase(GetPion(j,2),GetCase(pl,12));
			InitPionCase(GetPion(j,3),GetCase(pl,36));
			InitPionCase(GetPion(j,4),GetCase(pl,25));
			InitPionCase(GetPion(j,5),GetCase(pl,13));
			InitPionCase(GetPion(j,6),GetCase(pl,47));
			InitPionCase(GetPion(j,7),GetCase(pl,37));
			InitPionCase(GetPion(j,8),GetCase(pl,26));
			InitPionCase(GetPion(j,9),GetCase(pl,14));
			break;
		case 4:
			InitPionCase(GetPion(j,0),GetCase(pl,111));
			InitPionCase(GetPion(j,1),GetCase(pl,110));
			InitPionCase(GetPion(j,2),GetCase(pl,98));
			InitPionCase(GetPion(j,3),GetCase(pl,109));
			InitPionCase(GetPion(j,4),GetCase(pl,97));
			InitPionCase(GetPion(j,5),GetCase(pl,86));
			InitPionCase(GetPion(j,6),GetCase(pl,108));
			InitPionCase(GetPion(j,7),GetCase(pl,96));
			InitPionCase(GetPion(j,8),GetCase(pl,85));
			InitPionCase(GetPion(j,9),GetCase(pl,75));
			break;
		case 5:
			InitPionCase(GetPion(j,0),GetCase(pl,23));
			InitPionCase(GetPion(j,1),GetCase(pl,22));
			InitPionCase(GetPion(j,2),GetCase(pl,35));
			InitPionCase(GetPion(j,3),GetCase(pl,21));
			InitPionCase(GetPion(j,4),GetCase(pl,34));
			InitPionCase(GetPion(j,5),GetCase(pl,46));
			InitPionCase(GetPion(j,6),GetCase(pl,20));
			InitPionCase(GetPion(j,7),GetCase(pl,33));
			InitPionCase(GetPion(j,8),GetCase(pl,45));
			InitPionCase(GetPion(j,9),GetCase(pl,56));
			break;
		case 6:
			InitPionCase(GetPion(j,0),GetCase(pl,99));
			InitPionCase(GetPion(j,1),GetCase(pl,87));
			InitPionCase(GetPion(j,2),GetCase(pl,100));
			InitPionCase(GetPion(j,3),GetCase(pl,76));
			InitPionCase(GetPion(j,4),GetCase(pl,88));
			InitPionCase(GetPion(j,5),GetCase(pl,101));
			InitPionCase(GetPion(j,6),GetCase(pl,66));
			InitPionCase(GetPion(j,7),GetCase(pl,77));
			InitPionCase(GetPion(j,8),GetCase(pl,89));
			InitPionCase(GetPion(j,9),GetCase(pl,102));
			break;
	}
	return j;
}

/*********************************************************************************
**  Initialise un objet joueur avec son nom et ses liens au plateau de jeu
**/
void InitPionCase (struct pion *p, struct MaCase *c) {
	p->CaseDuPion = c;
	c->Pion = p;
	c->num_joueur = p->MonJoueur->numero;
}

/*********************************************************************************
**  Instancie un objet Pion
**/
struct pion * InitPion(int num, struct joueur *j) {
	struct pion *p;
	p = (struct pion*)malloc(sizeof(struct pion));
	p->numero = num;
	p->CaseDuPion = NULL;
	p->MonJoueur = j;
	return p;
}

/*********************************************************************************
**  Init des liens SudOuest-NordEst
**/
void InitCaseSONE(struct plateau *p,int x1, int x2, int dec) {
	struct MaCase *c1, *c2;
	c1 = GetCase(p,x1+1);
	c2 = GetCase(p,x2+dec);
	int i = x1+1;
	for(i=x1+1; i<=x2; i++) {
		c1->SO = c2;
		c2->NE = c1;
		c1 = c1->Next;
		c2 = c2->Next;
	}
}

/*********************************************************************************
**  Init des proprietes de l'hexagone
**/
void InitCaseHexagone (struct plateau *p,int x1, int x2) {
	struct MaCase *c;
	c = GetCase(p,x1);
	int i=x1;
	for(i=x1;i<=x2;i++) {
		c->hexagone = 1;
		c = c->Next;
	}
} 

/*********************************************************************************
**  Init des liens SudEst-NordOuest
**/
void InitCaseSENO(struct plateau *p,int x1, int x2, int dec) {
	struct MaCase *c1, *c2;
	c1 = GetCase(p,x1);
	c2 = GetCase(p,x2+dec);
	int i=x1;
	for(i=x1; i<x2; i++) {
		c1->SE = c2;
		c2->NO = c1;
		c1 = c1->Next;
		c2 = c2->Next;
	}
}

/*********************************************************************************
**  Init des liens Est-Ouest
**/
void InitCaseEO(struct plateau *p,int x1, int x2) {
	struct MaCase *c;
	c = GetCase(p,x1);
	int i = x1;
	for(i=x1; i<x2; i++) {
		c->E = c->Next;
		c->Next->O = c;
		c = c->Next;
	}
}

/*********************************************************************************
**  Instancie un objet Case
**/
struct MaCase * InitCase(int num) {
	struct MaCase *c;
	c = (struct MaCase *)malloc(sizeof(struct MaCase));
	c->O = NULL;
	c->NO = NULL;
	c->NE = NULL;
	c->E = NULL;
	c->SE = NULL;
	c->SO = NULL;
	c->Next = NULL;
	c->Pion = NULL;
	c->num_joueur = 0;
	c->hexagone = -1; //ce n'est pas dans l'hexagone par defaut
	c->numero = num;
	return c;
}

/*********************************************************************************
**  Init du plateau
**/
struct plateau * InitPlateau(void) {
	struct plateau *p;
	int i=0;

	AfficheDebug("Initialisation du Plateau");

	// création du plateau
	p = (struct plateau *)malloc(sizeof(struct plateau));
	
	// parcoure les cases et les crée
	for(i=0;i<=120;i=i+1) {
		p->Cases[i] = InitCase(i+1);
		if (i>0) { // lien Next à initialiser
			p->Cases[i-1]->Next = p->Cases[i];
		}
	}

	// Système d'initilisation qui manque de performance (pas d'algo savant)
	// mais simple donc robuste et clair à maintenir si besoin
	
	// init des liens E-O
	InitCaseEO(p,2,3);
	InitCaseEO(p,4,6);
	InitCaseEO(p,7,10);
	InitCaseEO(p,11,23);
	InitCaseEO(p,24,35);
	InitCaseEO(p,36,46);
	InitCaseEO(p,47,56);
	InitCaseEO(p,57,65);
	InitCaseEO(p,66,75);
	InitCaseEO(p,76,86);
	InitCaseEO(p,87,98);
	InitCaseEO(p,99,111);
	InitCaseEO(p,112,115);
	InitCaseEO(p,116,118);
	InitCaseEO(p,119,120);

	// init des liens SE-NO
	InitCaseSENO(p,1,2 , 1);
	InitCaseSENO(p,2,4 , 1);
	InitCaseSENO(p,4,7 , 1);
	InitCaseSENO(p,7,11 , 5);
	InitCaseSENO(p,11,23 , 1);
	InitCaseSENO(p,24,35 , 1);
	InitCaseSENO(p,36,46 , 1);
	InitCaseSENO(p,47,56 , 1);
	InitCaseSENO(p,57,66 , 1);
	InitCaseSENO(p,66,76 , 1);
	InitCaseSENO(p,76,87 , 1);
	InitCaseSENO(p,87,99 , 1);
	InitCaseSENO(p,103,107 , 5); //pour tracer le dernier triangle
	InitCaseSENO(p,112,115 , 1);
	InitCaseSENO(p,116,118 , 1);
	InitCaseSENO(p,119,120 , 1);

	// init des liens SO-NE
	InitCaseSONE(p,0,1 , 1);
	InitCaseSONE(p,1,3 , 1);
	InitCaseSONE(p,3,6 , 1);
	InitCaseSONE(p,6,10 , 5);
	InitCaseSONE(p,11,23 , 1);
	InitCaseSONE(p,24,35 , 1);
	InitCaseSONE(p,36,46 , 1);
	InitCaseSONE(p,47,56 , 1);
	InitCaseSONE(p,56,65 , 1);
	InitCaseSONE(p,65,75 , 1);
	InitCaseSONE(p,75,86 , 1);
	InitCaseSONE(p,86,98 , 1);
	InitCaseSONE(p,103,107 , 5);
	InitCaseSONE(p,112,115 , 1);
	InitCaseSONE(p,116,118 , 1);
	InitCaseSONE(p,119,120 , 1);

	// init des parties internes de l'hexagone (sert seulement à l'affichage : plus joli)	
	InitCaseHexagone(p,15,19);
	InitCaseHexagone(p,27,32);
	InitCaseHexagone(p,38,44);
	InitCaseHexagone(p,48,55);
	InitCaseHexagone(p,57,65);
	InitCaseHexagone(p,67,74);
	InitCaseHexagone(p,78,84);
	InitCaseHexagone(p,90,95);
	InitCaseHexagone(p,103,107);

	return p;
}

/*********************************************************************************
**  Libération d'un jeu complet
**/
void FreeJeu (struct jeu *Jeu) {
	int i;
	FreePlateau(Jeu->Plateau);
	// libère les joueurs
	for(i=0; i<6; i++) {
		if (Jeu->Joueurs[i] != NULL) {
			FreeJoueur(Jeu->Joueurs[i]);
		}
	}
	AfficheDebug("Libération du Jeu");
	free(Jeu);
}

/*********************************************************************************
**  Libération d'un joueur
**/
void FreeJoueur (struct joueur *j) {
	int i;
	// libère les pions
	AfficheDebug1Int("Libération des Pions du joueur n°%d", j->numero);
	for (i=0; i<10; i++) {
		free(j->Pions[i]);
	}
	AfficheDebug1Int("Libération du Joueur n°%d", j->numero);
	free(j);
}

/*********************************************************************************
**  Libération du plateau
**/
void FreePlateau (struct plateau *p) {
	int i;
	// libère les pions
	AfficheDebug("Libération des Cases");
	for (i=0; i<121; i++) {
		free(p->Cases[i]);
	}
	AfficheDebug("Libération du Plateau");
	free(p);
}
