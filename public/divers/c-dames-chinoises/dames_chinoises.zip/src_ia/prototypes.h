
/*********************************************************************************
**  Prototypes   DAMES
**/
int Ask_NbJoueurs(struct jeu *, int);
int Ask_NumPion(struct jeu *, int);
int Ask_DirectionPion(struct jeu *, int, int, int);
void Ask_NomJoueur(struct jeu *, int);

/*********************************************************************************
**  Prototypes   AFFICHAGE
**/
void AffichePlateau (struct plateau *, int);
void AfficheLigne (struct plateau *, int , int , int , int);
void AfficheCase (struct MaCase *, int);
void AffichePion(int , int , int);
void AfficheChar(char);
void AfficheChaine(char *, int, int);
void AfficheCadre(char * , int , int );

void TexteCouleur(int, int);
void TexteNormal(void);
void TexteSouligne(void);

/*********************************************************************************
**  Prototypes   JEU
**/
int NextJoueur(struct jeu *, int);

int JeuEstFini(struct plateau *, struct joueur *[]);
int NbPionsArrives(struct plateau *, int);

void PionsQuiPeuventJouer(struct joueur *);
void DirectionsPossibles(struct joueur *, int);
int PionPeutJouer(struct pion *, int);

void DirectionsEncorePossibles(struct joueur *, int, int);
int PionPeutRejouer(struct pion *, int, int);

int JouePion(struct pion *, int);
int Direction_Opposee(int);

/*********************************************************************************
**  Prototypes   UTILS
**/
int IsInteger(char *);
int GetInteger(char *);

struct MaCase * GetCase(struct plateau *, int);
struct pion * GetPion(struct joueur *, int);

void ClearScreen(void);

void CheckExit(char *, struct jeu *);
void ExitGame(struct jeu *);

/*********************************************************************************
**  Prototypes   INIT
**/
void FreeJeu (struct jeu *);
void FreePlateau (struct plateau *);
void FreeJoueur (struct joueur *);

struct jeu * InitJeu (void);
struct plateau * InitPlateau(void);
struct MaCase * InitCase(int);
struct joueur * InitJoueur (int , char [], struct plateau *, int);
struct pion * InitPion(int , struct joueur *);
void InitCaseEO(struct plateau *, int , int );
void InitCaseSENO(struct plateau *,int , int, int );
void InitCaseSONE(struct plateau *,int , int , int );
void InitCaseHexagone (struct plateau *,int , int );
void InitPionCase (struct pion *, struct MaCase *);

/*********************************************************************************
**  Prototypes    DEBUG
**/
void AfficheDebug(char *);
void AfficheDebug1Int(char *, int);
void AfficheDebug2Int(char *, int, int);
void AfficheDebugStart(char *);
void AfficheDebugBody(char *);
void AfficheDebugBody1Int(char *, int);
void AfficheDebugEnd(char *);
void AfficheLienPlateau (struct plateau *, int, int, int);
void AfficheLienLigneH (struct plateau *, int, int, int, int);
void AfficheLienLigneM (struct plateau *, int, int, int, int);
void AfficheLienLigneB (struct plateau *, int, int, int, int);
void AfficheLienCaseH (struct MaCase *, int);
void AfficheLienCaseM (struct MaCase *, int);
void AfficheLienCaseB (struct MaCase *, int);
