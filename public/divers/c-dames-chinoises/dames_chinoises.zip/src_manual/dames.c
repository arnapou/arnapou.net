/*********************************************************************************
**  INCLUDES
**/
# include <stdio.h>
# include <string.h>
# include <stdlib.h>
# include "define.h"
# include "structure.h"
# include "prototypes.h"
# include "debug.h"
# include "utils.h"
# include "init.h"
# include "affichage.h"
# include "jeu.h"
# include "dames.h"

/*********************************************************************************
**  MAIN => programme principal
**/
int main () {
	struct joueur *joueur_en_cours;
	struct pion *pion_en_cours;
	struct jeu *Jeu;
	int nb_joueurs, i, num_joueur, num_pion;
	int num_direction, old_direction, joueur_gagnant = 0;
	char tmp[256];
	
	/***** INITIALISATION DU JEU *****/
	Jeu = InitJeu();
	
	/***** AFFICHE LE BLA BLA DU DEBUT *****/
	ClearScreen();
	AfficheCadre("    JEU DE DAMES CHINOISES    ", ANSI_BLEU, ANSI_JAUNE);
	printf("Tapez '");
	AfficheChaine("exit", ANSI_ROUGE, SOULIGNE);
	printf("' pour quitter le jeu quand vous le voulez.\n");

	/***** DEMANDE DU NB DE JOUEURS *****/
	do {
		nb_joueurs = Ask_NbJoueurs(Jeu, 2);
		if (nb_joueurs%2 != 0) {
			AfficheChaine("/!\\ Hum ... il faut un nombre pair de joueurs ... /!\\\n\n", ANSI_ROUGE, PAS_SOULIGNE);
		}
	} while(nb_joueurs%2 != 0); // si nb de joueurs impair, on redemande
	num_joueur = 1;
	
	/***** DEMANDE DES NOMS DES JOUEURS + INIT JOUEURS *****/
	for(i=0; i<nb_joueurs; i++) {
		Ask_NomJoueur(Jeu, i+1);
	}

	/***** debug d'affichage des liens du plateau *****/
	/* 
	AfficheLienPlateau(Jeu->Plateau,0,0,0);
	AfficheLienPlateau(Jeu->Plateau,1,1,0);
	AfficheLienPlateau(Jeu->Plateau,0,1,1);
	exit(0);
	*/

	/***** JEU *****/
	while(joueur_gagnant == 0) {
		// bla bla pour faire joli
		ClearScreen();
		joueur_en_cours = Jeu->Joueurs[num_joueur - 1];
		AffichePlateau(Jeu->Plateau, num_joueur);
		printf("Joueur '");
		AfficheChaine(joueur_en_cours->nom, num_joueur + 1, PAS_SOULIGNE);
		printf("'\n");

		// demande le pion et la direction
		num_pion = Ask_NumPion(Jeu, num_joueur);
		num_direction = Ask_DirectionPion(Jeu, num_joueur, num_pion, DIRECTION_AUCUN);
		// s'il n'a pas annulé le fait de jouer ce pion
		if (num_direction > 0) {
			pion_en_cours = GetPion(Jeu->Joueurs[num_joueur-1], num_pion);
			// joue le pion
			if (JouePion(pion_en_cours, num_direction) == A_SAUTE) {
				// si c'était un saut, alors il peut avoir à rejouer
				old_direction = Direction_Opposee(num_direction);
				while (PionPeutRejouer(pion_en_cours, DIRECTION_ALL, old_direction) > 0 && num_direction != 0) {
					ClearScreen();
					AffichePlateau(Jeu->Plateau, num_joueur);
					printf("Encore joueur '");
					AfficheChaine(joueur_en_cours->nom, num_joueur + 1, PAS_SOULIGNE);
					printf("'\n");
					num_direction = Ask_DirectionPion(Jeu, num_joueur, num_pion, old_direction);
					if (num_direction > 0) {
						JouePion(pion_en_cours, num_direction);
						old_direction = Direction_Opposee(num_direction);
					}
				}
			}
			// passe au joueur suivant
			num_joueur = NextJoueur(Jeu, num_joueur);
		}
		
		joueur_gagnant = JeuEstFini(Jeu->Plateau, Jeu->Joueurs);
	}

	/***** Affichage du gagnant *****/
	ClearScreen();
	AffichePlateau(Jeu->Plateau, joueur_gagnant);
	printf("\n");
	sprintf(tmp, "      Le joueur '%s' a gagné !!      ", Jeu->Joueurs[joueur_gagnant-1]->nom);
	AfficheCadre(tmp, ANSI_ROUGE, ANSI_JAUNE);
	printf("\n");

	/***** SORTIE DU JEU *****/
	ExitGame(Jeu);
	return 0;
}
