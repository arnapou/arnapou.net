/*********************************************************************************
** NE PAS OUBLIER DE METTRE CES INCLUDES DANS LE FICHIER PRINCIPAL
**

# include <sys/types.h>
# include <sys/socket.h>
# include <netinet/in.h>
# include <arpa/inet.h>
# include <netdb.h>
# include <stdio.h>
# include <string.h>
# include <stdlib.h>
# include <unistd.h>

*/

/*********************************************************************************
 *                                   DEFINE                                      */
/*********************************************************************************
**  NET_SERVER_PORT    : port ouvert
**  NET_DATA_MAXLENGTH : maximum de données envoyées our recues
**/
#define NET_SERVER_PORT    1500
#define NET_DATA_MAXLENGTH 3000

/*********************************************************************************
**  actions possibles demandées par le serveur à son client
**/
#define NET_ACTION_NONE      -1
#define NET_ACTION_EXIT       0
#define NET_ACTION_PRINT      1
#define NET_ACTION_SYSTEMCMD  2
#define NET_ACTION_PROMPT     3

/*********************************************************************************
**  réponses aux actions
**/
#define NET_ANSWER_PASOK      -1
#define NET_ANSWER_OK         0
#define NET_ANSWER_EXIT       1
#define NET_ANSWER_PRINT      2
#define NET_ANSWER_SYSTEMCMD  3
#define NET_ANSWER_PROMPT     4

/*********************************************************************************
 *                                  PROTOTYPES                                   *
 *********************************************************************************/
int NET_Send_EXIT(int);
int NET_Send_PRINT(int, char *);
int NET_Send_SYSTEMCMD(int, char *);
int NET_Send_PROMPT(int, char *, char *);

void NET_Close(int);
void NET_DefineHost(struct sockaddr_in *, char *);
void NET_BindServer(int, struct sockaddr_in *);
void NET_BindClient(int, struct sockaddr_in *);
int NET_SendDatas(int, char *);
int NET_SendActionDatas(int, int, char *);
int NET_GetDatas(int, char *);
int NET_GetActionDatas(int, int *, char *);
int NET_ConnectToServer(int, struct sockaddr_in *);
int NET_CreateSocket(void);
int NET_WaitClient(int, int *, struct sockaddr_in *);

/*********************************************************************************
 *                                  FONCTIONS                                    */
/*********************************************************************************
**  envoi une commande et retourne si ok ou pas
**/
int NET_Send_EXIT(int sd) {
	char datas[NET_DATA_MAXLENGTH];
	int action;
	NET_SendActionDatas(sd, NET_ACTION_EXIT, "exit");
	if (NET_GetActionDatas(sd, &action, datas) == 0) {
		if (action == NET_ANSWER_EXIT) {
			return NET_ANSWER_OK;
		}
	}
	return NET_ANSWER_PASOK;
}

/*********************************************************************************
**  envoi une commande et retourne si ok ou pas
**/
int NET_Send_PRINT(int sd, char *texte) {
	char datas[NET_DATA_MAXLENGTH];
	int action;
	NET_SendActionDatas(sd, NET_ACTION_PRINT, texte);
	if (NET_GetActionDatas(sd, &action, datas) == 0) {
		if (action == NET_ANSWER_PRINT) {
			return NET_ANSWER_OK;
		}
	}
	return NET_ANSWER_PASOK;
}

/*********************************************************************************
**  envoi une commande et retourne si ok ou pas
**/
int NET_Send_SYSTEMCMD(int sd, char *command) {
	char datas[NET_DATA_MAXLENGTH];
	int action;
	NET_SendActionDatas(sd, NET_ACTION_SYSTEMCMD, command);
	if (NET_GetActionDatas(sd, &action, datas) == 0) {
		if (action == NET_ANSWER_SYSTEMCMD) {
			return NET_ANSWER_OK;
		}
	}
	return NET_ANSWER_PASOK;
}

/*********************************************************************************
**  envoi une commande et retourne si ok ou pas
**/
int NET_Send_PROMPT(int sd, char *prompt, char *datas) {
	int action;
	NET_SendActionDatas(sd, NET_ACTION_PROMPT, prompt);
	if (NET_GetActionDatas(sd, &action, datas) == 0) {
		if (action == NET_ANSWER_PROMPT) {
			return NET_ANSWER_OK;
		}
	}
	return NET_ANSWER_PASOK;
}

/*********************************************************************************
**  envoie des données textes
**/
void NET_Close(int sd) {
	close(sd);
}

/*********************************************************************************
**  envoie des données textes avec une action associée
**/
int NET_SendActionDatas(int sd, int action, char *datas) {
	char tmp[NET_DATA_MAXLENGTH];
	sprintf(tmp, "%d ", action);
	strcat(tmp, datas);
	return NET_SendDatas(sd, tmp);
}

/*********************************************************************************
**  envoie des données textes
**/
int NET_SendDatas(int sd, char *datas) {
	//int rc = send(sd, datas, strlen(datas) + 1, 0);
	int rc = write(sd, datas, strlen(datas) + 1);
	if(rc < 0) {
		printf("Impossible d'envoyer les données\n");
		return 1;
	}
	return 0;
}

/*********************************************************************************
**  se connecte au serveur
**/
int NET_ConnectToServer(int sd, struct sockaddr_in *servAddr) {
	int rc = connect(sd, (struct sockaddr *) servAddr, sizeof(*servAddr));
	if(rc < 0) {
		printf("impossible de se connecter au serveur\n");
		return 1;
	}
	return 0;
}

/*********************************************************************************
**  définit les infos du serveur à joindre
**/
void NET_DefineHost(struct sockaddr_in *servAddr, char *hostname) {
	struct hostent *host;
	host = gethostbyname(hostname);
	if(host == NULL) {
		printf("hote inconnu '%s'\n", hostname);
		exit(1);
	}
	
	(*servAddr).sin_family = host->h_addrtype;
	memcpy((char *) &(*servAddr).sin_addr.s_addr, host->h_addr_list[0], host->h_length);
	(*servAddr).sin_port = htons(NET_SERVER_PORT);
}

/*********************************************************************************
**  crée un socket
**/
int NET_CreateSocket(void) {
	int sd = socket(AF_INET, SOCK_STREAM, 0);
	if(sd < 0) {
		printf("Impossible d'ouvrir le socket \n");
		exit(1);
	}
	return sd;
}

/*********************************************************************************
**  bind du serveur
**/
void NET_BindServer(int sd, struct sockaddr_in *servAddr) {
	(*servAddr).sin_family = AF_INET;
	(*servAddr).sin_addr.s_addr = htonl(INADDR_ANY);
	(*servAddr).sin_port = htons(NET_SERVER_PORT);

	if(bind(sd, (struct sockaddr *) servAddr, sizeof(*servAddr))<0) {
		printf("Impossible d'ouvrir le port %d\n", NET_SERVER_PORT);
		exit(1);
	}
	
	listen(sd,5);
}

/*********************************************************************************
**  bind du client
**/
void NET_BindClient(int sd, struct sockaddr_in *localAddr) {
	(*localAddr).sin_family = AF_INET;
	(*localAddr).sin_addr.s_addr = htonl(INADDR_ANY);
	(*localAddr).sin_port = htons(0);

	if(bind(sd, (struct sockaddr *) localAddr, sizeof(*localAddr))<0) {
		printf("Impossible d'ouvrir un port\n");
		exit(1);
	}
}

/*********************************************************************************
**  attente d'un client
**/
int NET_WaitClient(int sd, int *newSd, struct sockaddr_in *cliAddr) {
	unsigned int cliLen = sizeof(*cliAddr);
	(*newSd) = accept(sd, (struct sockaddr *) cliAddr, &cliLen);
	if((*newSd) < 0) {
		printf("Impossible d'accepter la connexion\n");
		return 1;
	}
	return 0;
}

/*********************************************************************************
**  récupère les datas d'un client
**/
int NET_GetActionDatas(int newSd, int *action ,char *net_data) {
	char tmp[NET_DATA_MAXLENGTH];
	int i = 0;
	if (NET_GetDatas(newSd, tmp) == 0) {
		while(tmp[i] != ' ') { i++; }
		tmp[i] = '\0';
		sscanf(tmp, "%d", action);
		strcpy(net_data, tmp+i+1);
		return 0;
	} else {
		*action = NET_ACTION_NONE;
		strcpy(net_data, "");
		return 1;
	}
	return 1;
}

/*********************************************************************************
**  récupère les datas d'un client
**/
int NET_GetDatas(int newSd, char *net_data) {
	char rcv_msg[NET_DATA_MAXLENGTH];
	int n;

	// init chaine retournée
	memset(net_data, 0x0, NET_DATA_MAXLENGTH);

	// init buffer
	memset(rcv_msg, 0x0, NET_DATA_MAXLENGTH);

	// attend les données
	//n = recv(newSd, rcv_msg, NET_DATA_MAXLENGTH, 0);
	n = read(newSd, rcv_msg, NET_DATA_MAXLENGTH);
	if (n < 0) {
		printf("Impossible de recevoir les données\n");
		return 1;
	} else if (n == 0) {
		printf("Connexion fermée par le client\n");
		return 1;
	}
	
	// copie les données dans la chaine destination
	strncpy(net_data, rcv_msg, n);

	return 0;
}
