/*********************************************************************************
**  INCLUDES
**/
# include <sys/types.h>
# include <sys/socket.h>
# include <netinet/in.h>
# include <arpa/inet.h>
# include <netdb.h>
# include <stdio.h>
# include <string.h>
# include <stdlib.h>
# include <unistd.h>
# include "network.h"

/*********************************************************************************
**  MAIN => programme principal
**/
int main (int argc, char *argv[]) {
	struct sockaddr_in localAddr, servAddr;
	char datas[NET_DATA_MAXLENGTH];
	int sd;
	int action = NET_ACTION_NONE;
	
	/*** teste la présence du paramètre ***/
	if(argc < 2) {
		printf("usage: %s <server>\n", argv[0]);
		exit(1);
	}
	
	/*** initialise les éléments réseau ***/
	NET_DefineHost(&servAddr, argv[1]);
	sd = NET_CreateSocket();
	NET_BindClient(sd, &localAddr);
	
	/*** se connecte au serveur ***/
	if (NET_ConnectToServer(sd, &servAddr) != 0) {
		exit(1);
	}
	
	/*** attend des données etc ... ***/
	while(action != NET_ACTION_EXIT) {
		if (NET_GetActionDatas(sd, &action, datas) == 0) {
			switch(action) {
				case NET_ACTION_EXIT:
					NET_SendActionDatas(sd, NET_ANSWER_EXIT, "exit received");
					break;
				case NET_ACTION_PRINT:
					printf(datas);
					NET_SendActionDatas(sd, NET_ANSWER_PRINT, "print received");
					break;
				case NET_ACTION_SYSTEMCMD:
					system(datas);
					NET_SendActionDatas(sd, NET_ANSWER_SYSTEMCMD, "command received");
					break;
				case NET_ACTION_PROMPT:
					printf(datas);
					scanf("%s", datas);
					NET_SendActionDatas(sd, NET_ANSWER_PROMPT, datas);
					break;
			}
		} else {
			printf("\nERREUR : pb de récupération de données, exit !\nLe serveur a peut-être été arrêté !\n\n");
			action = NET_ACTION_EXIT;
		}
	}
	NET_Close(sd);

	return 0;
}

