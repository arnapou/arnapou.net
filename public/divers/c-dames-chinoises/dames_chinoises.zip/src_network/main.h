
/*********************************************************************************
 *                                  FONCTIONS                                    */
/*********************************************************************************
** Envoie un texte à tous les clients
**/
void CLT_Send_TO_ALL(int sd[7], struct jeu *Jeu, char *texte) {
	int i;
	for(i=0; i<6; i++) {
		if (Jeu->Joueurs[i] != NULL) {
			if (sd[i] > 0) { // sécurité
				if (NET_Send_PRINT(sd[i], texte) == NET_ANSWER_PASOK) { SRV_ExitGame(Jeu); }
			}
		}
	}
}

/*********************************************************************************
** Demande un élément au client
**/
void CLT_Send_PROMPT(int sd, struct jeu *Jeu, char *prompt, char *texte) {
	if (NET_Send_PROMPT(sd, prompt, texte) == NET_ANSWER_PASOK) { SRV_ExitGame(Jeu); }
}

/*********************************************************************************
** Envoie un élément à afficher
**/
void CLT_Send_PRINT(int sd, struct jeu *Jeu, char *texte) {
	if (NET_Send_PRINT(sd, texte) == NET_ANSWER_PASOK) { SRV_ExitGame(Jeu); }
}

/*********************************************************************************
** Clear tous les écrans distants
**/
void CLT_ClearAllScreens(int sd[7], struct jeu *Jeu) {
	int i;
	for(i=0; i<6; i++) {
		if (Jeu->Joueurs[i] != NULL) {
			if (sd[i] > 0) { // sécurité
				CLT_ClearScreen(sd[i], Jeu);
			}
		}
	}
}

/*********************************************************************************
** Clear de l'écran distant
**/
void CLT_ClearScreen(int sd, struct jeu *Jeu) {
	int ret = NET_ANSWER_PASOK;
	if (CLEAR_ACTIVE == 1) {
		ret = NET_Send_SYSTEMCMD(sd, CLEAR_COMMAND);
	}
	if (ret == NET_ANSWER_PASOK) { SRV_ExitGame(Jeu); }
}

/*********************************************************************************
** Affiche les infos du debut
**/
void CLT_PrintAccueil(int sd, struct jeu *Jeu) {
	char datas[NET_DATA_MAXLENGTH];
	char texte1[NET_DATA_MAXLENGTH];
	char texte2[NET_DATA_MAXLENGTH];
	CLT_ClearScreen(sd, Jeu);
	S_AfficheCadre("    JEU DE DAMES CHINOISES    ", ANSI_BLEU, ANSI_JAUNE, texte1);
	S_AfficheChaine("exit", ANSI_ROUGE, SOULIGNE, texte2);
	sprintf(datas, "%sTapez '%s' pour quitter le jeu quand vous le voulez.\n", texte1, texte2);
	if (NET_Send_PRINT(sd, datas) == NET_ANSWER_PASOK) { SRV_ExitGame(Jeu); }
}

/*********************************************************************************
**  Quitte le jeu proprement
**/
void SRV_ExitGame(struct jeu *Jeu) {
	printf("\n\nUne Erreur de réponse a été rencontrée, exit du server !!\n\n");
	ExitGame(Jeu);
}

/*********************************************************************************
**  Vérifie si un client a quitté le jeu : retourne 1 le joueur a quitté le jeu
**/
int CLT_CheckExit(int sd[7], char *chaine, struct jeu *Jeu, int num_joueur) {
	char nom[NET_DATA_MAXLENGTH];
	char tmp1[NET_DATA_MAXLENGTH];
	char tmp2[NET_DATA_MAXLENGTH];
	int i, n = 0;
	if (strcmp(chaine, "exit") == 0 || strcmp(chaine, "quit") == 0) {
		// déconnecte le joueur
		NET_Send_EXIT(sd[num_joueur-1]);
		// pour tous les pions, les enlève du plateau
		for (i=0; i<10; i++) {
			Jeu->Joueurs[num_joueur-1]->Pions[i]->CaseDuPion->Pion = NULL;
		}
		// libère le joueur et sauve son nom avant
		S_AfficheChaine(Jeu->Joueurs[num_joueur-1]->nom, Jeu->Joueurs[num_joueur-1]->numero+1, SOULIGNE, tmp1);
		S_AfficheChaine("/!\\", ANSI_ROUGE, PAS_SOULIGNE, tmp2);
		sprintf(nom, "\n%s  Le joueur '%s' a quitté le jeu !  %s\n", tmp2, tmp1, tmp2);
		FreeJoueur(Jeu->Joueurs[num_joueur-1]);
		// décale les joueurs dans la liste des joueurs
		for (i=num_joueur-1; i<5; i++) {
			Jeu->Joueurs[i] = Jeu->Joueurs[i+1];
			sd[i] = sd[i+1];
		}
		// le dernier est mis à NULL
		Jeu->Joueurs[i] = NULL;
		sd[i] = -1;
		// compte les joueurs restants -> n
		for (i=0; i<6; i++) {
			if (Jeu->Joueurs[i] != NULL) {
				n++;
			}
		}
		// envoie aux joueurs restants l'information du départ de la personne
		CLT_Send_TO_ALL(sd, Jeu, nom);
		// pause de 1 secondes afin de laisser le temps au message d'être lu
		sleep(1);
		// quitte si pas assez de joueurs
		if (n < 2) {
			// envoie aux joueurs restants un message et les deconnecte
			for (i=0; i<6; i++) {
				if (Jeu->Joueurs[i] != NULL) {
					n++;
					NET_Send_PRINT(sd[i], "\n\nExit du jeu car il ne reste plus assez de personnes !\n\n");
					NET_Send_EXIT(sd[i]);
				}
			}
			NET_Close(sd[6]); // ferme le serveur
			ExitGame(Jeu);
		}
		return EXIT_VALUE;
	}
	return 0;
}
