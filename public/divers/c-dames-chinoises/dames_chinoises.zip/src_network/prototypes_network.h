/*********************************************************************************
 *                                  PROTOTYPES                                   *
 *********************************************************************************/

/***** Affichage *****/
void S_TexteCouleur(int, int, char *);
void S_TexteNormal(char *);
void S_TexteSouligne(char *);

void S_AfficheChaine(char *, int, int, char *);
void S_AfficheCadre(char *, int, int, char *);
void S_AffichePion(int, int, int, char *);
void S_AfficheChar(char, char *);
void S_AfficheCase (struct MaCase *, int, char *);
void S_AfficheLigne (struct plateau *, int, int, int, int, char *);
void S_AffichePlateau (struct plateau *, int, char *);

/***** Dames *****/
int S_Ask_NomJoueur(int [], struct jeu *, int);
int S_Ask_NbJoueurs(int [], struct jeu *, int, int);
int S_Ask_NumPion(int [], struct jeu *, int);

/***** Main *****/
int CLT_CheckExit(int [], char *, struct jeu *, int);
void CLT_ClearScreen(int, struct jeu *);
void CLT_ClearAllScreens(int [], struct jeu *);
void CLT_PrintAccueil(int, struct jeu *);
void CLT_Send_PRINT(int, struct jeu *, char *);
void CLT_Send_PROMPT(int, struct jeu *, char *, char *);
void CLT_Send_TO_ALL(int [], struct jeu *, char *);
void SRV_ExitGame(struct jeu *);

/***** Jeu *****/
void S_PionsQuiPeuventJouer(struct joueur *, char *);
void S_DirectionsPossibles(struct joueur *, int, char *);
void S_DirectionsEncorePossibles(struct joueur *, int, int, char *);
