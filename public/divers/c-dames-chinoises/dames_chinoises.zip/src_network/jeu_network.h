
/*********************************************************************************
 *                                  FONCTIONS                                    */
/*********************************************************************************
**  affiche la liste des pions qui peuvent jouer
**/
void S_PionsQuiPeuventJouer(struct joueur *j, char *texte) {
	char tmp[NET_DATA_MAXLENGTH];
	int i;
	S_TexteCouleur(j->numero + 1, PAS_SOULIGNE, texte);
	// parcoure les pions
	for (i=0; i<10; i++) {
		if (PionPeutJouer(j->Pions[i], DIRECTION_ALL) > 0) {
			sprintf(tmp, "%d ", j->Pions[i]->numero);
			strcat(texte, tmp);
		}
	}
	S_TexteNormal(tmp);
	strcat(texte, tmp);
}

/*********************************************************************************
**  affiche la liste des pions qui peuvent jouer
**/
void S_DirectionsPossibles(struct joueur *j, int num_pion, char *texte) {
	char tmp[NET_DATA_MAXLENGTH];
	struct pion *p = GetPion(j, num_pion);
	sprintf(texte, "   ");
	if (PionPeutJouer(p, DIRECTION_NO) == 1) {
		S_AfficheChaine("1", j->numero + 1, PAS_SOULIGNE, tmp);
		strcat(texte, tmp);
		strcat(texte, "\\ ");
	} else {
		strcat(texte, " \\ ");
	}
	if (PionPeutJouer(p, DIRECTION_NE) == 1) {
		strcat(texte, "/");
		S_AfficheChaine("2", j->numero + 1, PAS_SOULIGNE, tmp);
		strcat(texte, tmp);
		strcat(texte, " \n");
	} else { 
		strcat(texte, "/  \n");
	}
	strcat(texte, "   ");
	if (PionPeutJouer(p, DIRECTION_O) == 1) {
		strcat(texte, "-");
		S_AfficheChaine("3", j->numero + 1, PAS_SOULIGNE, tmp);
		strcat(texte, tmp);
		strcat(texte, " ");
	} else {
		strcat(texte, "-  ");
	}
	if (PionPeutJouer(p, DIRECTION_E) == 1) {
		S_AfficheChaine("4", j->numero + 1, PAS_SOULIGNE, tmp);
		strcat(texte, tmp);
		strcat(texte, "-\n");
	} else {
		strcat(texte, " - \n");
	}
	strcat(texte, "   ");
	if (PionPeutJouer(p, DIRECTION_SO) == 1) {
		S_AfficheChaine("5", j->numero + 1, PAS_SOULIGNE, tmp);
		strcat(texte, tmp);
		strcat(texte, "/ ");
	} else {
		strcat(texte, " / ");
	}
	if (PionPeutJouer(p, DIRECTION_SE) == 1) {
		strcat(texte, "\\");
		S_AfficheChaine("6", j->numero + 1, PAS_SOULIGNE, tmp);
		strcat(texte, tmp);
		strcat(texte, " \n");
	} else {
		strcat(texte, "\\  \n");
	}
}

/*********************************************************************************
**  affiche la liste des pions qui peuvent jouer
**/
void S_DirectionsEncorePossibles(struct joueur *j, int num_pion, int direction_precedente, char *texte) {
	char tmp[NET_DATA_MAXLENGTH];
	struct pion *p = GetPion(j, num_pion);
	sprintf(texte, "   ");
	if (PionPeutRejouer(p, DIRECTION_NO, direction_precedente) == 1 ) {
		S_AfficheChaine("1", j->numero + 1, PAS_SOULIGNE, tmp);
		strcat(texte, tmp);
		strcat(texte, "\\ ");
	} else {
		strcat(texte, " \\ ");
	}
	if (PionPeutRejouer(p, DIRECTION_NE, direction_precedente) == 1 ) {
		strcat(texte, "/");
		S_AfficheChaine("2", j->numero + 1, PAS_SOULIGNE, tmp);
		strcat(texte, tmp);
		strcat(texte, " \n");
	} else { 
		strcat(texte, "/  \n");
	}
	strcat(texte, "   ");
	if (PionPeutRejouer(p, DIRECTION_O, direction_precedente) == 1 ) {
		strcat(texte, "-");
		S_AfficheChaine("3", j->numero + 1, PAS_SOULIGNE, tmp);
		strcat(texte, tmp);
		strcat(texte, " ");
	} else {
		strcat(texte, "-  ");
	}
	if (PionPeutRejouer(p, DIRECTION_E, direction_precedente) == 1 ) {
		S_AfficheChaine("4", j->numero + 1, PAS_SOULIGNE, tmp);
		strcat(texte, tmp);
		strcat(texte, "-\n");
	} else {
		strcat(texte, " - \n");
	}
	strcat(texte, "   ");
	if (PionPeutRejouer(p, DIRECTION_SO, direction_precedente) == 1 ) {
		S_AfficheChaine("5", j->numero + 1, PAS_SOULIGNE, tmp);
		strcat(texte, tmp);
		strcat(texte, "/ ");
	} else {
		strcat(texte, " / ");
	}
	if (PionPeutRejouer(p, DIRECTION_SE, direction_precedente) == 1 ) {
		strcat(texte, "\\");
		S_AfficheChaine("6", j->numero + 1, PAS_SOULIGNE, tmp);
		strcat(texte, tmp);
		strcat(texte, " \n");
	} else {
		strcat(texte, "\\  \n");
	}
}
