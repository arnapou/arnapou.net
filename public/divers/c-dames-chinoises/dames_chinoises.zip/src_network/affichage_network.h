
/*********************************************************************************
 *                                  FONCTIONS                                    */
/*********************************************************************************
**  Affiche des codes Ansi afin que le texte qui suivra sera de la couleur voulue
**/
void S_TexteCouleur(int color, int underlined, char *texte) {
	if (MODE_AFFICHAGE == 0) {
		if (underlined == 0) {
			sprintf(texte, "\033[1;3%dm", color);
		} else {
			sprintf(texte, "\033[4;3%dm", color);
		}
	}
}

/*********************************************************************************
**  Affiche des codes Ansi afin que le texte qui suivra sera 'normal'
**/
void S_TexteNormal(char *texte) {
	if (MODE_AFFICHAGE == 0) {
		sprintf(texte, "\033[0m");
	}
}

/*********************************************************************************
**  Affiche des codes Ansi afin que le texte qui suivra sera souligné
**/
void S_TexteSouligne(char *texte) {
	if (MODE_AFFICHAGE == 0) {
		sprintf(texte, "\033[4m");
	}
}

/*********************************************************************************
**  Affiche un texte entouré d'un cadre de '*' selon les couleurs voulues
**/
void S_AfficheCadre(char * chaine, int colortxt, int colorcadre, char *datas) {
	char tmp[NET_DATA_MAXLENGTH];
	char texte[NET_DATA_MAXLENGTH];
	int n = strlen(chaine), i;
	// remplit tmp avec des etoiles
	for (i=0; i<n+4; i++) { tmp[i] = '*'; }
	tmp[i] = '\n';
	tmp[i+1] = '\0';
	switch (MODE_AFFICHAGE) {
		case 0:
			S_AfficheChaine(chaine, colortxt, 0, texte);
			sprintf(datas, "\033[1;3%dm%s* %s\033[1;3%dm *\n%s\033[0m\n", colorcadre, tmp, texte, colorcadre, tmp);
			break;
		case 1:
			sprintf(datas, "%s* %s *\n%s", tmp, chaine, tmp);
			break;
		case 2:
			sprintf(datas, "%s* %s *\n%s", tmp, chaine, tmp);
			break;
	}
}

/*********************************************************************************
**  Affiche un pion selon son n°
**/
void S_AffichePion(int npion, int color, int underlined, char *datas) {
	switch (MODE_AFFICHAGE) {
		case 0:
			sprintf(datas, "\033[1;3%dm%d\033[0m", color, npion);
			break;
		case 1:
			if (underlined == 0) {
				sprintf(datas, "%d", npion);
			} else {
				sprintf(datas, "\033[4m%d\033[0m", npion);
			}
			break;
		case 2:
			sprintf(datas, "%d", npion);
			break;
	}
}

/*********************************************************************************
**  Affiche une chaine colorisée
**/
void S_AfficheChaine(char *chaine, int color, int underlined, char *datas) {
	switch (MODE_AFFICHAGE) {
		case 0:
			if (underlined == 0) {
				sprintf(datas, "\033[1;3%dm%s\033[0m", color, chaine);
			} else {
				sprintf(datas, "\033[1m\033[4;3%dm%s\033[0m\033[0m", color, chaine);
			}
			break;
		case 1:
			if (underlined == 0) {
				sprintf(datas, "%s", chaine);
			} else {
				sprintf(datas, "\033[4m%s\033[0m", chaine);
			}
			break;
		case 2:
			sprintf(datas, "%s", chaine);
			break;
	}
}

/*********************************************************************************
**  Affiche un caractère sur le plateau (case vide)
**/
void S_AfficheChar(char caractere, char *datas) {
	switch (MODE_AFFICHAGE) {
		case 0:
			sprintf(datas, "\033[0;37m%c\033[0m", caractere);
			break;
		case 1:
			sprintf(datas, "%c", caractere);
			break;
		case 2:
			sprintf(datas, "%c", caractere);
			break;
	}
}
/*********************************************************************************
**  Affiche une case du plateau
**/
void S_AfficheCase (struct MaCase *c, int joueur_num, char *datas) {
	char tmp[NET_DATA_MAXLENGTH];
	if(c->Pion == NULL) {
		if(c->hexagone < 0) {
			S_AfficheChar('#', tmp);
			sprintf(datas, "%s ", tmp);
		} else {
			S_AfficheChar('.', tmp);
			sprintf(datas, "%s ", tmp);
		}
	} else {
		if (joueur_num == c->Pion->MonJoueur->numero) {
			S_AffichePion(c->Pion->numero, c->Pion->MonJoueur->numero + 1, SOULIGNE, tmp);
		} else {
			S_AffichePion(c->Pion->numero, c->Pion->MonJoueur->numero + 1, PAS_SOULIGNE, tmp);
		}
		sprintf(datas, "%s ", tmp);
	}
}

/*********************************************************************************
**  Affiche une ligne du plateau
**/
void S_AfficheLigne (struct plateau *p, int abscisse, int x1, int x2, int joueur_num, char *datas) {
	char tmp[NET_DATA_MAXLENGTH];
	int i = 0;
	struct MaCase *c;
	c = GetCase(p, x1);
	for(i=0; i<abscisse; i++) { datas[i] = ' '; }
	datas[i] = '\0';
	for(i=x1; i<=x2; i++) {
		S_AfficheCase(c, joueur_num, tmp);
		c = c->Next;
		strcat(datas, tmp);
	}
	strcat(datas, "\n");
}

/*********************************************************************************
**  Affiche le plateau de jeu
**/
void S_AffichePlateau(struct plateau *p, int joueur_num, char *datas) {
	char tmp[NET_DATA_MAXLENGTH];
	datas[0] = '\0';
	S_AfficheLigne(p, DECALAGE_PLATEAU + 13, 1, 1, joueur_num, tmp); strcat(datas, tmp);
	S_AfficheLigne(p, DECALAGE_PLATEAU + 12, 2, 3, joueur_num, tmp); strcat(datas, tmp);
	S_AfficheLigne(p, DECALAGE_PLATEAU + 11, 4, 6, joueur_num, tmp); strcat(datas, tmp);
	S_AfficheLigne(p, DECALAGE_PLATEAU + 10, 7, 10, joueur_num, tmp); strcat(datas, tmp);
	S_AfficheLigne(p, DECALAGE_PLATEAU + 1, 11, 23, joueur_num, tmp); strcat(datas, tmp);
	S_AfficheLigne(p, DECALAGE_PLATEAU + 2, 24, 35, joueur_num, tmp); strcat(datas, tmp);
	S_AfficheLigne(p, DECALAGE_PLATEAU + 3, 36, 46, joueur_num, tmp); strcat(datas, tmp);
	S_AfficheLigne(p, DECALAGE_PLATEAU + 4, 47, 56, joueur_num, tmp); strcat(datas, tmp);
	S_AfficheLigne(p, DECALAGE_PLATEAU + 5, 57, 65, joueur_num, tmp); strcat(datas, tmp);
	S_AfficheLigne(p, DECALAGE_PLATEAU + 4, 66, 75, joueur_num, tmp); strcat(datas, tmp);
	S_AfficheLigne(p, DECALAGE_PLATEAU + 3, 76, 86, joueur_num, tmp); strcat(datas, tmp);
	S_AfficheLigne(p, DECALAGE_PLATEAU + 2, 87, 98, joueur_num, tmp); strcat(datas, tmp);
	S_AfficheLigne(p, DECALAGE_PLATEAU + 1, 99, 111, joueur_num, tmp); strcat(datas, tmp);
	S_AfficheLigne(p, DECALAGE_PLATEAU + 10, 112, 115, joueur_num, tmp); strcat(datas, tmp);
	S_AfficheLigne(p, DECALAGE_PLATEAU + 11, 116, 118, joueur_num, tmp); strcat(datas, tmp);
	S_AfficheLigne(p, DECALAGE_PLATEAU + 12, 119, 120, joueur_num, tmp); strcat(datas, tmp);
	S_AfficheLigne(p, DECALAGE_PLATEAU + 13, 121, 121, joueur_num, tmp); strcat(datas, tmp);
}

