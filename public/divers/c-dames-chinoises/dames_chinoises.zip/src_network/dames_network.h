/*********************************************************************************
 *                                   DEFINE                                      */
/*********************************************************************************
**  EXIT_VALUE : valeur utilisee pour quitter savoir quand une personne 
**               a quitté la partie
**/
#define EXIT_VALUE -9

/*********************************************************************************
 *                                  FONCTIONS                                    */
/*********************************************************************************
**  Demande le nb de joueurs et le retourne
**/
int S_Ask_NbJoueurs(int sd[7], struct jeu *Jeu, int min_nombre_joueurs, int num_joueur) {
	int nb_joueurs = 99;
	char tmp[NET_DATA_MAXLENGTH];
	
	while (nb_joueurs > 6) {
		CLT_Send_PROMPT(sd[num_joueur-1], Jeu, "\nNombre de joueurs (dont vous-même) = ", tmp);
		if (IsInteger(tmp)) {
			nb_joueurs = GetInteger(tmp);
			if (nb_joueurs > 6) {
				S_AfficheChaine("/!\\ Hum ... maximum 6 cap'taine /!\\\n", ANSI_ROUGE, PAS_SOULIGNE, tmp);
				CLT_Send_PRINT(sd[num_joueur-1], Jeu, tmp);
			}
		} else { // autre chose qu'un entier a été saisi
			CLT_CheckExit(sd, tmp, Jeu, num_joueur);
			S_AfficheChaine("/!\\ Hum ... savez-vous ce qu'est un entier ? ... MDR ... /!\\\n", ANSI_ROUGE, PAS_SOULIGNE, tmp);
			CLT_Send_PRINT(sd[num_joueur-1], Jeu, tmp);
			nb_joueurs = 99; // pour que la boucle continue
		}
	}
	if (nb_joueurs < min_nombre_joueurs) { // pas de joueurs => exit fin du pgm
		S_AfficheChaine("/!\\ Heu ... pas assez de joueurs => pas de jeu ... bye ... /!\\\n\n", ANSI_ROUGE, PAS_SOULIGNE, tmp);
		CLT_Send_PRINT(sd[num_joueur-1], Jeu, tmp);
		NET_Send_EXIT(sd[num_joueur-1]);
		NET_Close(sd[6]); // ferme le serveur
		ExitGame(Jeu);
	}
	return nb_joueurs;
}

/*********************************************************************************
**  Demande le n° du pion à jouer
**/
int S_Ask_NumPion(int sd[7], struct jeu *Jeu, int num_joueur) {
	char tmp[NET_DATA_MAXLENGTH];
	char texte[NET_DATA_MAXLENGTH];
	int num_pion = -1;
	
	while (num_pion < 0) {
		S_PionsQuiPeuventJouer(Jeu->Joueurs[num_joueur-1], tmp);
		sprintf(texte, "Quel pion voulez-vous jouer ? ( %s ) => ", tmp);
		CLT_Send_PROMPT(sd[num_joueur-1], Jeu, texte, tmp);
		if (CLT_CheckExit(sd, tmp, Jeu, num_joueur) == EXIT_VALUE) { return EXIT_VALUE; }
		if (IsInteger(tmp) == 0) { // pas entier
			num_pion = -1;
		} else {
			num_pion = GetInteger(tmp);
			if (num_pion < 10) {
				if (PionPeutJouer(GetPion(Jeu->Joueurs[num_joueur-1], num_pion), DIRECTION_ALL) == 0) {
					S_AfficheChaine("/!\\ Hum ... ce pion ne peut pas jouer voyons ... /!\\\n\n",ANSI_ROUGE, PAS_SOULIGNE, tmp);
					CLT_Send_PRINT(sd[num_joueur-1], Jeu, tmp);
					num_pion = -1;
				}
			} else {
				S_AfficheChaine("/!\\ Hum ... vous n'avez pas plus de 10 pions me semble-t-il ... /!\\\n\n",ANSI_ROUGE, PAS_SOULIGNE, tmp);
				CLT_Send_PRINT(sd[num_joueur-1], Jeu, tmp);
				num_pion = -1;
			}
		}
	}
	return num_pion;
}

/*********************************************************************************
**  Demande la direction du pion à jouer
**/
int S_Ask_DirectionPion(int sd[7], struct jeu *Jeu, int num_joueur, int num_pion, int old_direction) {
	char tmp[NET_DATA_MAXLENGTH];
	char texte[NET_DATA_MAXLENGTH];
	int num_direction = -1;

	while (num_direction < 0) {
		if (old_direction == DIRECTION_AUCUN) {
			S_DirectionsPossibles(Jeu->Joueurs[num_joueur-1], num_pion, tmp);
		} else {
			S_DirectionsEncorePossibles(Jeu->Joueurs[num_joueur-1], num_pion, old_direction, tmp);
		}
		sprintf(texte, "Dans quelle direction voulez-vous jouer ? (0 pour annuler)\n%s=> ", tmp);
		CLT_Send_PROMPT(sd[num_joueur-1], Jeu, texte, tmp);
		if (CLT_CheckExit(sd, tmp, Jeu, num_joueur) == EXIT_VALUE) { return EXIT_VALUE; }
		if (IsInteger(tmp) == 0) { // pas entier
			num_direction = -1;
		} else {
			num_direction = GetInteger(tmp);
			if (num_direction >= 1 && num_direction <= 6) {
				if (old_direction == DIRECTION_AUCUN) {
					if (PionPeutJouer(GetPion(Jeu->Joueurs[num_joueur-1], num_pion), num_direction) == 0 ) {
						S_AfficheChaine("/!\\ Hum ... direction impossible ... /!\\\n\n", ANSI_ROUGE, PAS_SOULIGNE, tmp);
						CLT_Send_PRINT(sd[num_joueur-1], Jeu, tmp);
						num_direction = -1;
					}
				} else {
					if (PionPeutRejouer(GetPion(Jeu->Joueurs[num_joueur-1], num_pion), num_direction, old_direction) == 0 ) {
						S_AfficheChaine("/!\\ Hum ... direction impossible ... /!\\\n\n", ANSI_ROUGE, PAS_SOULIGNE, tmp);
						CLT_Send_PRINT(sd[num_joueur-1], Jeu, tmp);
						num_direction = -1;
					}
				}
			} else if (num_direction == 0) {
				num_direction = 0;
			} else {
				S_AfficheChaine("/!\\ Hum ... direction inconnue ... /!\\\n\n",ANSI_ROUGE, PAS_SOULIGNE, tmp);
				CLT_Send_PRINT(sd[num_joueur-1], Jeu, tmp);
				num_direction = -1;
			}
		}
	}
	return num_direction;
}

/*********************************************************************************
**  Demande le nom d'un joueur
**/
int S_Ask_NomJoueur(int sd[7], struct jeu *Jeu, int num_joueur) {
	char texte[NET_DATA_MAXLENGTH];
	char textejoueur[NET_DATA_MAXLENGTH];
	char nom[NET_DATA_MAXLENGTH];
	
	sprintf(texte, "Joueur %d", num_joueur);
	S_AfficheChaine(texte, num_joueur+1, SOULIGNE, textejoueur);
	sprintf(texte, "\nNom du %s : ", textejoueur);
	NET_Send_PROMPT(sd[num_joueur-1], texte, nom);
	if (strcmp(nom, "exit") == 0 || strcmp(nom, "quit") == 0 || strlen(nom)==0) {
		NET_Send_EXIT(sd[num_joueur-1]);
		return 0;
	} else {
		Jeu->Joueurs[num_joueur-1] = InitJoueur(num_joueur, nom, Jeu->Plateau, JOUEUR_HUMAIN);
		return 1;
	}
}
