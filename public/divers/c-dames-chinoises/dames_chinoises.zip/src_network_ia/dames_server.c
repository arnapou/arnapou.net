/*********************************************************************************
**  INCLUDES COMMUNS
**/
# include <sys/types.h>
# include <sys/socket.h>
# include <netinet/in.h>
# include <arpa/inet.h>
# include <netdb.h>
# include <stdio.h>
# include <string.h>
# include <stdlib.h>
# include <unistd.h>

# include "define.h"
# include "structure.h"
# include "prototypes.h"
# include "debug.h"
# include "utils.h"
# include "init.h"
# include "jeu.h"
# include "affichage.h"
# include "dames.h"

# include "ia.h"

/*********************************************************************************
**  INCLUDES SPECIFIQUES RESEAU
**/
# include "network.h"

# include "prototypes_network.h"
# include "dames_network.h"
# include "main.h"
# include "affichage_network.h"
# include "jeu_network.h"

/*********************************************************************************
 *                                  FONCTIONS                                    */
/*********************************************************************************
**  Demande le nb d'ordinateurs
**/
int S_Ask_NbOrdinateurs(int sd[7], struct jeu *Jeu, int nb_joueurs) {
	int nb_ordinateurs = 99;
	char tmp[NET_DATA_MAXLENGTH];
	int num_joueur = 1;
	
	while (nb_ordinateurs > 6 - nb_joueurs) {
		CLT_Send_PROMPT(sd[num_joueur-1], Jeu, "\n\nNombre d'ordinateurs = ", tmp);
		if (IsInteger(tmp)) {
			nb_ordinateurs = GetInteger(tmp);
			if (nb_ordinateurs > 6 - nb_joueurs) {
				S_AfficheChaine("/!\\ Hum ... maximum 6 joueurs au total /!\\\n", ANSI_ROUGE, PAS_SOULIGNE, tmp);
				CLT_Send_PRINT(sd[num_joueur-1], Jeu, tmp);
			}
		} else { // autre chose qu'un entier a été saisi
			CLT_CheckExit(sd, tmp, Jeu, num_joueur);
			S_AfficheChaine("/!\\ Hum ... savez-vous ce qu'est un entier ? ... MDR ... /!\\\n", ANSI_ROUGE, PAS_SOULIGNE, tmp);
			CLT_Send_PRINT(sd[num_joueur-1], Jeu, tmp);
			nb_ordinateurs = 99; // pour que la boucle continue
		}
	}
	if (nb_ordinateurs < 2 - nb_joueurs) { // pas d'ordinateur => exit fin du pgm
		S_AfficheChaine("/!\\ Heu ... pas d'ordinateur => pas de jeu ... bye ... /!\\\n\n", ANSI_ROUGE, PAS_SOULIGNE, tmp);
		CLT_Send_PRINT(sd[num_joueur-1], Jeu, tmp);
		NET_Send_EXIT(sd[num_joueur-1]);
		ExitGame(Jeu);
	}
	return nb_ordinateurs;
}

/*********************************************************************************
**  MAIN => programme principal
**/
int main (int argc, char *argv[]) {
	struct joueur *joueur_en_cours;
	struct pion *pion_en_cours;
	struct jeu *Jeu;
	int nb_joueurs, i, j, k, num_joueur, num_pion, nb_ordinateurs;
	int num_direction, old_direction, joueur_gagnant = 0;
	char tmp0[NET_DATA_MAXLENGTH];
	char tmp1[NET_DATA_MAXLENGTH];
	char tmp2[NET_DATA_MAXLENGTH];

	struct max_move *max;

	// variables reseau
	struct sockaddr_in cliAddr[6], servAddr;

	// de 0 à 5 : sockets clients
	// le dernier est le socket serveur
	int sd[7] = {-1, -1, -1, -1, -1, -1, -1};
	
	/***** crée le socket *****/
	sd[6] = NET_CreateSocket();
	NET_BindServer(sd[6], &servAddr);

	/***** INITIALISATION DU JEU *****/
	Jeu = InitJeu();
	
	/***** ATTEND LE PREMIER CLIENT : C'EST CELUI QUI REPOND AUX PREMIERES QUESTIONS *****/
	if(NET_WaitClient(sd[6], &(sd[0]), &(cliAddr[0])) == 0) {
		CLT_ClearScreen(sd[0], Jeu);
		CLT_PrintAccueil(sd[0], Jeu);
		if (S_Ask_NomJoueur(sd, Jeu, 1) == 0) { // s'il a fait exit
			NET_Close(sd[6]); // ferme le serveur
			ExitGame(Jeu);
		}

		nb_joueurs = S_Ask_NbJoueurs(sd, Jeu, 1, 1);
		
		/***** DEMANDE DU NB DE JOUEURS *****/
		do {
			if ((nb_ordinateurs+nb_joueurs)%2 != 0) {
				nb_ordinateurs = S_Ask_NbOrdinateurs(sd, Jeu, 1);
				S_AfficheChaine("/!\\ Hum ... il faut un nombre pair de joueurs ... /!\\\n\n", ANSI_ROUGE, PAS_SOULIGNE, tmp0);
				CLT_Send_PRINT(sd[0], Jeu, tmp0);
			}
		} while((nb_ordinateurs+nb_joueurs)%2 != 0); // si nb de joueurs impair, on redemande
		num_joueur = 1;
	} else {
		NET_Close(sd[6]); // ferme le serveur
		ExitGame(Jeu);
	}

	
	/***** ATTENTE DES JOUEURS + INIT JOUEURS *****/
	for(i=1; i<nb_joueurs; i++) {
		// pour chaque joueur connecté : envoie un message d'info
		for(k=0; k<i; k++) {
			CLT_ClearScreen(sd[k], Jeu);
			CLT_Send_PRINT(sd[k], Jeu, "Joueurs connectés :\n");
			// affiche la liste des joueurs connectés
			for(j=0; j<i; j++) {
				S_AfficheChaine(Jeu->Joueurs[j]->nom, Jeu->Joueurs[j]->numero+1, PAS_SOULIGNE, tmp1);
				sprintf(tmp2, "   - %s\n", tmp1);
				CLT_Send_PRINT(sd[k], Jeu, tmp2);
			}
			sprintf(tmp1, "\n(%d / %d joueurs)\n", j, nb_joueurs);
			CLT_Send_PRINT(sd[k], Jeu, tmp1);
			CLT_Send_PRINT(sd[k], Jeu, "\nen attente des autres joueurs ...\n");
		}
		if(NET_WaitClient(sd[6], &(sd[i]), &(cliAddr[i])) == 0) {
			CLT_ClearScreen(sd[i], Jeu);
			CLT_PrintAccueil(sd[i], Jeu);
			// si la personne a quitté : exit
			if (S_Ask_NomJoueur(sd, Jeu, i+1) == 0) { i--; }
		}
	}

	/***** INIT DES ORDINATEURS *****/
	InitOrdinateurs(Jeu, nb_ordinateurs);
	printf("\n");

	/***** debug d'affichage des liens du plateau *****/
	/* 
	AfficheLienPlateau(Jeu->Plateau,0,0,0);
	AfficheLienPlateau(Jeu->Plateau,1,1,0);
	AfficheLienPlateau(Jeu->Plateau,0,1,1);
	exit(0);
	*/

	/***** JEU *****/
	while(joueur_gagnant == 0) {
		joueur_en_cours = Jeu->Joueurs[num_joueur - 1];
		
		ClearScreen();
		AffichePlateau(Jeu->Plateau, num_joueur);
		
		CLT_ClearAllScreens(sd, Jeu);
		S_AffichePlateau(Jeu->Plateau, num_joueur, tmp1);
		S_AfficheChaine(joueur_en_cours->nom, joueur_en_cours->numero + 1, PAS_SOULIGNE, tmp2);
		sprintf(tmp0, "%sAu joueur '%s' de jouer.\n", tmp1, tmp2);
		CLT_Send_TO_ALL(sd, Jeu, tmp0);
		
		if (joueur_en_cours->ordinateur == JOUEUR_ARTIFICIEL) {
			// DANS LE CAS ORDINATEUR
			// cherche le meilleur coup
			max = IA_BestMove(Jeu, num_joueur);
			// joue le(s) coup(s)
			JouePionMove(GetPion(joueur_en_cours, max->num_pion), max->directions);
			// passe au joueur suivant
			num_joueur = NextJoueur(Jeu, num_joueur);
		} else {
			// demande le pion et la direction
			num_pion = S_Ask_NumPion(sd, Jeu, num_joueur);
			if (num_pion == EXIT_VALUE) { continue; }
			
			// demande la direction
			num_direction = S_Ask_DirectionPion(sd, Jeu, num_joueur, num_pion, DIRECTION_AUCUN);
			if (num_direction == EXIT_VALUE) { continue; }
			
			// s'il n'a pas annulé le fait de jouer ce pion
			if (num_direction > 0) {
				pion_en_cours = GetPion(Jeu->Joueurs[num_joueur-1], num_pion);
				// joue le pion
				if (JouePion(pion_en_cours, num_direction) == A_SAUTE) {
					// si c'était un saut, alors il peut avoir à rejouer
					old_direction = Direction_Opposee(num_direction);
					while (PionPeutRejouer(pion_en_cours, DIRECTION_ALL, old_direction) > 0 && num_direction != 0) {
						CLT_ClearAllScreens(sd, Jeu);
						S_AffichePlateau(Jeu->Plateau, num_joueur, tmp1);
						S_AfficheChaine(joueur_en_cours->nom, joueur_en_cours->numero + 1, PAS_SOULIGNE, tmp2);
						sprintf(tmp0, "%sAu joueur '%s' de rejouer.\n", tmp1, tmp2);
						CLT_Send_TO_ALL(sd, Jeu, tmp0);
						
						num_direction = S_Ask_DirectionPion(sd, Jeu, num_joueur, num_pion, old_direction);
						if (num_direction == EXIT_VALUE) { break; }
						if (num_direction > 0) {
							JouePion(pion_en_cours, num_direction);
							old_direction = Direction_Opposee(num_direction);
						}
					}
					if (num_direction == EXIT_VALUE) { continue; }
				}
				// passe au joueur suivant
				num_joueur = NextJoueur(Jeu, num_joueur);
			}
		}
		joueur_gagnant = JeuEstFini(Jeu->Plateau, Jeu->Joueurs);
	}

	/***** Affichage du gagnant *****/
	CLT_ClearAllScreens(sd, Jeu);
	S_AffichePlateau(Jeu->Plateau, joueur_gagnant, tmp1);
	sprintf(tmp0, "      Le joueur '%s' a gagné !!      ", Jeu->Joueurs[joueur_gagnant-1]->nom);
	S_AfficheCadre(tmp2, ANSI_BLEU, ANSI_JAUNE, tmp0);
	sprintf(tmp0, "%s\n%s\n", tmp1, tmp2);
	CLT_Send_TO_ALL(sd, Jeu, tmp0);

	/***** FERME LES CONNEXIONS DES CLIENTS *****/
	for(i=0; i<6; i++) {
		if (Jeu->Joueurs[i] != NULL) {
			if (sd[i] > 0) {
				NET_Send_EXIT(sd[i]);
			}
		}
	}

	/***** SORTIE DU JEU *****/
	NET_Close(sd[6]); // ferme le serveur
	ExitGame(Jeu);
	return 0;
}
