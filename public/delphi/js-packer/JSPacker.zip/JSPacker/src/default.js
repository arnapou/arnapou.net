/****************************************************
Syntax for IE script only :
	<!--[if IE]>
		<script defer type="text/javascript" src="my_script.js"></script>
	<![endif]-->
Exemples :
	<!--[if gte IE 5]> pour r�server le contenu � IE 5.0, IE5.5 et IE6.0 <![endif]-->
	<!--[if IE 5.0]> pour IE 5.0 <![endif]-->
	<!--[if IE 5.5000]> pour IE 5.5 <![endif]-->
	<!--[if IE 6]> pour IE 6.0 <![endif]-->
	<!--[if gte IE 5.5000]> pour IE5.5 et IE6.0 <![endif]-->
	<!--[if lt IE 6]> pour IE5.0 et IE5.5 <![endif]-->
	<!--[if lt IE 7]> pour IE inf�rieur � IE7 <![endif]-->
	<!--[if lte IE 6]> pour IE5.0, IE5.5 et IE6.0 mais pas IE7.0<![endif]-->
*/





/***************************************************** Cookie *****************************************************/
/**
 * Cookie plugin
 *
 * Copyright (c) 2006 Klaus Hartl (stilbuero.de)
 * Dual licensed under the MIT and GPL licenses:
 * http://www.opensource.org/licenses/mit-license.php
 * http://www.gnu.org/licenses/gpl.html
 *
 */

/**
 * Create a cookie with the given name and value and other optional parameters.
 *
 * @example $.cookie('the_cookie', 'the_value');
 * @desc Set the value of a cookie.
 * @example $.cookie('the_cookie', 'the_value', {expires: 7, path: '/', domain: 'jquery.com', secure: true});
 * @desc Create a cookie with all available options.
 * @example $.cookie('the_cookie', 'the_value');
 * @desc Create a session cookie.
 * @example $.cookie('the_cookie', '', {expires: -1});
 * @desc Delete a cookie by setting a date in the past.
 *
 * @param String name The name of the cookie.
 * @param String value The value of the cookie.
 * @param Object options An object literal containing key/value pairs to provide optional cookie attributes.
 * @option Number|Date expires Either an integer specifying the expiration date from now on in days or a Date object.
 *                             If a negative value is specified (e.g. a date in the past), the cookie will be deleted.
 *                             If set to null or omitted, the cookie will be a session cookie and will not be retained
 *                             when the the browser exits.
 * @option String path The value of the path atribute of the cookie (default: path of page that created the cookie).
 * @option String domain The value of the domain attribute of the cookie (default: domain of page that created the cookie).
 * @option Boolean secure If true, the secure attribute of the cookie will be set and the cookie transmission will
 *                        require a secure protocol (like HTTPS).
 * @type undefined
 *
 * @name $.cookie
 * @cat Plugins/Cookie
 * @author Klaus Hartl/klaus.hartl@stilbuero.de
 */

/**
 * Get the value of a cookie with the given name.
 *
 * @example $.cookie('the_cookie');
 * @desc Get the value of a cookie.
 *
 * @param String name The name of the cookie.
 * @return The value of the cookie.
 * @type String
 *
 * @name $.cookie
 * @cat Plugins/Cookie
 * @author Klaus Hartl/klaus.hartl@stilbuero.de
 */
jQuery.cookie = function(name, value, options) {
    if (typeof value != 'undefined') { // name and value given, set cookie
        options = options || {};
        var expires = '';
        if (options.expires && (typeof options.expires == 'number' || options.expires.toGMTString)) {
            var date;
            if (typeof options.expires == 'number') {
                date = new Date();
                date.setTime(date.getTime() + (options.expires * 24 * 60 * 60 * 1000));
            } else {
                date = options.expires;
            }
            expires = '; expires=' + date.toGMTString(); // use expires attribute, max-age is not supported by IE
        }
        var path = options.path ? '; path=' + options.path : '';
        var domain = options.domain ? '; domain=' + options.domain : '';
        var secure = options.secure ? '; secure' : '';
        document.cookie = [name, '=', encodeURIComponent(value), expires, path, domain, secure].join('');
    } else { // only name given, get cookie
        var cookieValue = null;
        if (document.cookie && document.cookie != '') {
            var cookies = document.cookie.split(';');
            for (var i = 0; i < cookies.length; i++) {
                var cookie = jQuery.trim(cookies[i]);
                // Does this cookie string begin with the name we want?
                if (cookie.substring(0, name.length + 1) == (name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break;
                }
            }
        }
        return cookieValue;
    }
};




















/***************************************************** jQBrowser *****************************************************/

 /**
 * jQBrowser v0.2 - Extend jQuery's browser detection capabilities
 *   * http://davecardwell.co.uk/geekery/javascript/jquery/jqbrowser/0.2/
 *
 * Dave Cardwell <http://davecardwell.co.uk/>
 *
 * Built on the shoulders of giants:
 *   * John Resig <http://jquery.com/>
 *   * Peter-Paul Koch <http://www.quirksmode.org/?/js/detect.html>
 *
 *
 * Copyright (c) 2006 Dave Cardwell, dual licensed under the MIT and GPL
 * licenses:
 *   * http://www.opensource.org/licenses/mit-license.php
 *   * http://www.gnu.org/licenses/gpl.txt
 */

/**
 * For the latest version of this plugin, and a discussion of its usage and
 * implementation, visit:
 *   * http://davecardwell.co.uk/geekery/javascript/jquery/jqbrowser/
 */

new function() {

    /**
     * The following functions and attributes form the internal methods and
     * state of the jQBrowser plugin.  See the relevant function definition
     * later in the source for further information.
     *
     * Private.browser
     * Private.version
     * Private.OS
     *
     * Private.aol
     * Private.camino
     * Private.firefox
     * Private.flock
     * Private.icab
     * Private.konqueror
     * Private.mozilla
     * Private.msie
     * Private.netscape
     * Private.opera
     * Private.safari
     *
     * Private.linux
     * Private.mac
     * Private.win
     */
    var Private = {
        // Initially set to 'Unknown', if detected each of these properties will
        // be updated.
          'browser': 'Unknown',
          'version': {
              'number': undefined,
              'string': 'Unknown'
          },
               'OS': 'Unknown',

        // Initially set to false, if detected one of the following browsers
        // will be updated.
              'aol': false,
           'camino': false,
          'firefox': false,
            'flock': false,
             'icab': false,
        'konqueror': false,
          'mozilla': false,
             'msie': false,
         'netscape': false,
            'opera': false,
           'safari': false,
           'compatible': false,

        // Initially set to false, if detected one of the following operating
        // systems will be updated.
            'linux': false,
              'mac': false,
              'win': false
    };
    

    /**
     * Loop over the items in 'data' trying to find a browser match with the
     * test in data[i].browser().  Once found, attempt to determine the
     * browser version.
     *
     *       'name': A string containing the full name of the browser.
     * 'identifier': By default this is a lowercase version of 'name', but
     *               this can be overwritten by explicitly defining an
     *               'identifier'.
     *    'browser': A function that returns a boolean value indicating
     *               whether or not the given browser is detected.
     *    'version': An optional function that overwrites the default version
     *               testing.  Must return the result of a .match().
     *
     * Please note that the order of the data array is important, as some
     * browsers contain details of others in their navigator.userAgent string.
     * For example, Flock's contains 'Firefox' so much come before Firefox's
     * test to avoid false positives.
     */
    for( var  i = 0,                    // counter
             ua = navigator.userAgent,  // the navigator's user agent string
             ve = navigator.vendor,     // the navigator's vendor string
           data = [                     // browser tests and data
                { // Safari <http://www.apple.com/safari/>
                          'name': 'Safari',
                       'browser': function() { return /Apple/.test(ve) }
                },
                { // Opera <http://www.opera.com/>
                          'name': 'Opera',
                       'browser': function() {
                                      return window.opera != undefined
                                  }
                },
                { // iCab <http://www.icab.de/>
                          'name': 'iCab',
                       'browser': function() { return /iCab/.test(ve) }
                },
                { // Konqueror <http://www.konqueror.org/>
                          'name': 'Konqueror',
                       'browser': function() { return /KDE/.test(ve) }
                },
                { // AOL Explorer <http://downloads.channel.aol.com/browser>
                    'identifier': 'aol',
                          'name': 'AOL Explorer',
                       'browser': function() {
                                      return /America Online Browser/.test(ua)
                                  },
                       'version': function() {
                                      return ua.match(/rev(\d+(?:\.\d+)+)/)
                                  }
                },
                { // Flock <http://www.flock.com/>
                          'name': 'Flock',
                       'browser': function() { return /Flock/.test(ua) }
                },
                { // Camino <http://www.caminobrowser.org/>
                          'name': 'Camino',
                       'browser': function() { return /Camino/.test(ve) }
                },
                { // Firefox <http://www.mozilla.com/firefox/>
                          'name': 'Firefox',
                       'browser': function() { return /Firefox/.test(ua) }
                },
                { // Netscape <http://browser.netscape.com/>
                          'name': 'Netscape',
                       'browser': function() { return /Netscape/.test(ua) }
                },
                { // Internet Explorer <http://www.microsoft.com/windows/ie/>
                  //                   <http://www.microsoft.com/mac/ie/>
                    'identifier': 'msie',
                          'name': 'Internet Explorer',
                       'browser': function() { return /MSIE/.test(ua) },
                       'version': function() {
                                      return ua.match(
                                          /MSIE (\d+(?:\.\d+)+(?:b\d*)?)/
                                      )
                                  }
                },
                { // Mozilla <http://www.mozilla.org/products/mozilla1.x/>
                          'name': 'Mozilla',
                       'browser': function() {
                                      return /Gecko|Mozilla/.test(ua)
                                  },
                       'version': function() {
                                      return ua.match(/rv:(\d+(?:\.\d+)+)/)
                                  }
                 }
             ];
         i < data.length;
         i++
    ) {
        if( data[i].browser() ) { // we have a match
            // If the identifier is not explicitly set, use a lowercase
            // version of the given name.
            var identifier = data[i].identifier ? data[i].identifier
                                                : data[i].name.toLowerCase();

            // Make a note that this browser was detected.
            Private[ identifier ] = true;

            // $.browser.browser() will now return the correct browser.
            Private.browser = data[i].name;

            var result;
            if( data[i].version != undefined && (result = data[i].version()) ) {
                // Use the explicitly set test for browser version.
                Private.version.string = result[1];
                Private.version.number = parseFloat( result[1] );
            } else {
                // Otherwise use the default test which searches for the
                // version number after the browser name in the user agent
                // string.
                var re = new RegExp(
                    data[i].name + '(?:\\s|\\/)(\\d+(?:\\.\\d+)+(?:(?:a|b)\\d*)?)'
                );

                result = ua.match(re);
                if( result != undefined ) {
                    Private.version.string = result[1];
                    Private.version.number = parseFloat( result[1] );
                }
            }

            // Once we've detected the browser there is no need to check the
            // others.
            break;
        }
    };



    /**
     * Loop over the items in 'data' trying to find a operating system match
     * with the test in data[i].os().
     *
     *       'name': A string containing the full name of the operating
     *               system.
     * 'identifier': By default this is a lowercase version of 'name', but
     *               this can be overwritten by explicitly defining an
     *               'identifier'.
     *         'OS': A function that returns a boolean value indicating
     *               whether or not the given operating system is detected.
     */
    for( var  i = 0,                  // counter
             pl = navigator.platform, // the navigator's platform string
           data = [                   // OS data and tests
                { // Microsoft Windows <http://www.microsoft.com/windows/>
                    'identifier': 'win',
                          'name': 'Windows',
                            'OS': function() { return /Win/.test(pl) }
                },
                { // Apple Mac OS <http://www.apple.com/macos/>
                          'name': 'Mac',
                            'OS': function() { return /Mac/.test(pl) }
                },
                { // Linux <http://www.linux.org/>
                          'name': 'Linux',
                            'OS': function() { return /Linux/.test(pl) }
                }
           ];
       i < data.length;
       i++
    ) {
        if( data[i].OS() ) { // we have a match
            // If the identifier is not explicitly set, use a lowercase
            // version of the given name.
            var identifier = data[i].identifier ? data[i].identifier
                                                : data[i].name.toLowerCase();

            // Make a note that the OS was detected.
            Private[ identifier ] = true;

            // $.browser.OS() will now return the correct OS.
            Private.OS = data[i].name;

            // Once we've detected the browser there is no need to check the
            // others.
            break;
        }
    };
    
    jQuery.browser = Private;
}();










/***************************************************** Tailles de fenetres *****************************************************/

/* 
 * Dual licensed under the MIT (http://www.opensource.org/licenses/mit-license.php) 
 * and GPL (http://www.opensource.org/licenses/gpl-license.php) licenses.
 * 
 * $LastChangedDate$
 * $Rev$
 */

jQuery.fn._height = jQuery.fn.height;
jQuery.fn._width  = jQuery.fn.width;

/**
 * If used on document, returns the document's height (innerHeight)
 * If used on window, returns the viewport's (window) height
 * See core docs on height() to see what happens when used on an element.
 *
 * @example $("#testdiv").height()
 * @result 200
 *
 * @example $(document).height()
 * @result 800
 *
 * @example $(window).height()
 * @result 400
 * 
 * @name height
 * @type Object
 * @cat Plugins/Dimensions
 */
jQuery.fn.height = function() {
	if ( this[0] == window )
		return self.innerHeight ||
			jQuery.boxModel && document.documentElement.clientHeight ||
			document.body.clientHeight;
	
	if ( this[0] == document ) 
		return Math.max( document.body.scrollHeight, document.body.offsetHeight );
	
	return this._height(arguments[0]);
};

/**
 * If used on document, returns the document's width (innerWidth)
 * If used on window, returns the viewport's (window) width
 * See core docs on height() to see what happens when used on an element.
 *
 * @example $("#testdiv").width()
 * @result 200
 *
 * @example $(document).width()
 * @result 800
 *
 * @example $(window).width()
 * @result 400
 * 
 * @name width
 * @type Object
 * @cat Plugins/Dimensions
 */
jQuery.fn.width = function() {
	if ( this[0] == window )
		return self.innerWidth ||
			jQuery.boxModel && document.documentElement.clientWidth ||
			document.body.clientWidth;
	
	if ( this[0] == document )
		return Math.max( document.body.scrollWidth, document.body.offsetWidth );
	
	if ($.browser.opera) {
		var w = this._width(arguments[0]);
		this.find('*').each(function() {
			if ($(this).width() > w) {
				w = $(this).width();
			}
		});
		return w;
	} else {
		return this._width(arguments[0]);
	}
};

/**
 * Returns the inner height value (without border) for the first matched element.
 * If used on document, returns the document's height (innerHeight)
 * If used on window, returns the viewport's (window) height
 *
 * @example $("#testdiv").innerHeight()
 * @result 800
 * 
 * @name innerHeight
 * @type Number
 * @cat Plugins/Dimensions
 */
jQuery.fn.innerHeight = function() {
	return this[0] == window || this[0] == document ?
		this.height() :
		this.css('display') != 'none' ?
		 	this[0].offsetHeight - (parseInt(this.css("borderTopWidth")) || 0) - (parseInt(this.css("borderBottomWidth")) || 0) :
			this.height() + (parseInt(this.css("paddingTop")) || 0) + (parseInt(this.css("paddingBottom")) || 0);
};

/**
 * Returns the inner width value (without border) for the first matched element.
 * If used on document, returns the document's Width (innerWidth)
 * If used on window, returns the viewport's (window) width
 *
 * @example $("#testdiv").innerWidth()
 * @result 1000
 * 
 * @name innerWidth
 * @type Number
 * @cat Plugins/Dimensions
 */
jQuery.fn.innerWidth = function() {
	return this[0] == window || this[0] == document ?
		this.width() :
		this.css('display') != 'none' ?
			this[0].offsetWidth - (parseInt(this.css("borderLeftWidth")) || 0) - (parseInt(this.css("borderRightWidth")) || 0) :
			this.height() + (parseInt(this.css("paddingLeft")) || 0) + (parseInt(this.css("paddingRight")) || 0);
};

/**
 * Returns the outer height value (including border) for the first matched element.
 * Cannot be used on document or window.
 *
 * @example $("#testdiv").outerHeight()
 * @result 1000
 * 
 * @name outerHeight
 * @type Number
 * @cat Plugins/Dimensions
 */
jQuery.fn.outerHeight = function() {
	return this[0] == window || this[0] == document ?
		this.height() :
		this.css('display') != 'none' ?
			this[0].offsetHeight :
			this.height() + (parseInt(this.css("borderTopWidth")) || 0) + (parseInt(this.css("borderBottomWidth")) || 0)
				+ (parseInt(this.css("paddingTop")) || 0) + (parseInt(this.css("paddingBottom")) || 0);
};

/**
 * Returns the outer width value (including border) for the first matched element.
 * Cannot be used on document or window.
 *
 * @example $("#testdiv").outerWidth()
 * @result 1000
 * 
 * @name outerWidth
 * @type Number
 * @cat Plugins/Dimensions
 */
jQuery.fn.outerWidth = function() {
	return this[0] == window || this[0] == document ?
		this.width() :
		this.css('display') != 'none' ?
			this[0].offsetWidth :
			this.height() + (parseInt(this.css("borderLeftWidth")) || 0) + (parseInt(this.css("borderRightWidth")) || 0)
				+ (parseInt(this.css("paddingLeft")) || 0) + (parseInt(this.css("paddingRight")) || 0);
};

/**
 * Returns how many pixels the user has scrolled to the right (scrollLeft).
 * Works on containers with overflow: auto and window/document.
 *
 * @example $("#testdiv").scrollLeft()
 * @result 100
 * 
 * @name scrollLeft
 * @type Number
 * @cat Plugins/Dimensions
 */
jQuery.fn.scrollLeft = function() {
	if ( this[0] == window || this[0] == document )
		return self.pageXOffset ||
			jQuery.boxModel && document.documentElement.scrollLeft ||
			document.body.scrollLeft;
	
	return this[0].scrollLeft;
};

/**
 * Returns how many pixels the user has scrolled to the bottom (scrollTop).
 * Works on containers with overflow: auto and window/document.
 *
 * @example $("#testdiv").scrollTop()
 * @result 100
 * 
 * @name scrollTop
 * @type Number
 * @cat Plugins/Dimensions
 */
jQuery.fn.scrollTop = function() {
	if ( this[0] == window || this[0] == document )
		return self.pageYOffset ||
			jQuery.boxModel && document.documentElement.scrollTop ||
			document.body.scrollTop;

	return this[0].scrollTop;
};

/**
 * Returns the location of the element in pixels from the top left corner of the viewport.
 * 
 * For accurate readings make sure to use pixel values for margins, borders and padding.
 * 
 * @example $("#testdiv").offset()
 * @result { top: 100, left: 100, scrollTop: 10, scrollLeft: 10 }
 * 
 * @example $("#testdiv").offset({ scroll: false })
 * @result { top: 90, left: 90 }
 *
 * @example var offset = {}
 * $("#testdiv").offset({ scroll: false }, offset)
 * @result offset = { top: 90, left: 90 }
 *
 * @name offset	
 * @param Object options A hash of options describing what should be included in the final calculations of the offset.
 *                       The options include:
 *                           margin: Should the margin of the element be included in the calculations? True by default. 
 *                                   If set to false the margin of the element is subtracted from the total offset.
 *                           border: Should the border of the element be included in the calculations? True by default.
 *                                   If set to false the border of the element is subtracted from the total offset.
 *                           padding: Should the padding of the element be included in the calculations? False by default.
 *                                    If set to true the padding of the element is added to the total offset.
 *                           scroll: Should the scroll offsets of the parent elements be included in the calculations? 
 *                                   True by default. When true, it adds the total scroll offsets of all parents to the 
 *                                   total offset and also adds two properties to the returned object, scrollTop and 
 *                                   scrollLeft. If set to false the scroll offsets of parent elements are ignored. 
 *                                   If scroll offsets are not needed, set to false to get a performance boost.
 * @param Object returnObject An object to store the return value in, so as not to break the chain. If passed in the 
 *                            chain will not be broken and the result will be assigned to this object.
 * @type Object
 * @cat Plugins/Dimensions
 * @author Brandon Aaron (brandon.aaron@gmail.com || http://brandonaaron.net)
 */
jQuery.fn.offset = function(options, returnObject) {
	var x = 0, y = 0, elem = this[0], parent = this[0], sl = 0, st = 0, options = jQuery.extend({ margin: true, border: true, padding: false, scroll: true }, options || {});
	do {
		x += parent.offsetLeft || 0;
		y += parent.offsetTop  || 0;

		// Mozilla and IE do not add the border
		if (jQuery.browser.mozilla || jQuery.browser.msie) {
			// get borders
			var bt = parseInt(jQuery.css(parent, 'borderTopWidth')) || 0;
			var bl = parseInt(jQuery.css(parent, 'borderLeftWidth')) || 0;
			
			// add borders to offset
			x += bl;
			y += bt;
			
			// Mozilla removes the border if the parent has overflow property other than visible
			if (jQuery.browser.mozilla && parent != elem && jQuery.css(parent, 'overflow') != 'visible') {
				x += bl;
				y += bt;
			}
		}
		
		var op = parent.offsetParent;
		if (op && (op.tagName == 'BODY' || op.tagName == 'HTML')) {
			// Safari and IE don't add the body margin for elments positioned with static or relative
			if ((jQuery.browser.safari || jQuery.browser.msie) && jQuery.css(parent, 'position') != 'absolute') {
				x += parseInt(jQuery.css(op, 'marginLeft')) || 0;
				y += parseInt(jQuery.css(op, 'marginTop'))  || 0;
			}
			break;
		}

		if (options.scroll) {
			// Need to get scroll offsets in-between offsetParents
			do {
				sl += parent.scrollLeft || 0;
				st += parent.scrollTop  || 0;
							
				parent = parent.parentNode;
				
				// Mozilla removes the border if the parent has overflow property other than visible
				if (jQuery.browser.mozilla && parent != elem && parent != op && jQuery.css(parent, 'overflow') != 'visible') {
					y += parseInt(jQuery.css(parent, 'borderTopWidth')) || 0;
					x += parseInt(jQuery.css(parent, 'borderLeftWidth')) || 0;
				}
			} while (parent != op);
		} else {
			parent = parent.offsetParent;
		}
	} while (parent);
	
	if ( !options.margin) {
		x -= parseInt(jQuery.css(elem, 'marginLeft')) || 0;
		y -= parseInt(jQuery.css(elem, 'marginTop'))  || 0;
	}
	
	// Safari and Opera do not add the border for the element
	if ( options.border && (jQuery.browser.safari || jQuery.browser.opera) ) {
		x += parseInt(jQuery.css(elem, 'borderLeftWidth')) || 0;
		y += parseInt(jQuery.css(elem, 'borderTopWidth'))  || 0;
	} else if ( !options.border && !(jQuery.browser.safari || jQuery.browser.opera) ) {
		x -= parseInt(jQuery.css(elem, 'borderLeftWidth')) || 0;
		y -= parseInt(jQuery.css(elem, 'borderTopWidth'))  || 0;
	}
	
	if ( options.padding ) {
		x += parseInt(jQuery.css(elem, 'paddingLeft')) || 0;
		y += parseInt(jQuery.css(elem, 'paddingTop'))  || 0;
	}
	
	// Opera thinks offset is scroll offset for display: inline elements
	if (options.scroll && jQuery.browser.opera && jQuery.css(elem, 'display') == 'inline') {
		sl -= elem.scrollLeft || 0;
		st -= elem.scrollTop  || 0;
	}
	
	var returnValue = options.scroll ? { top: y - st, left: x - sl, scrollTop:  st, scrollLeft: sl }
									: { top: y, left: x };

	if (returnObject) { jQuery.extend(returnObject, returnValue); return this; }
	else              { return returnValue; }
};

















/***************************************************** JQ MinMax *****************************************************/
/**
 * jQMinMax     http://davecardwell.co.uk/geekery/javascript/jquery/jqminmax/
 *
 * @author      Dave Cardwell <http://davecardwell.co.uk/>
 * @version     0.1
 *
 * @projectDescription  Add min-/max- height & width support.
 *
 * Built on the shoulders of giants:
 *   * John Resig      - http://jquery.com/
 *
 *
 * Copyright (c) 2006 Dave Cardwell, licensed under the MIT License:
 *   * http://www.opensource.org/licenses/mit-license.php
 */


new function() {
    $.minmax = {
        active: false,
        native: false
    };


    $(document).ready(function() {
        // Create a div to test for native minmax support.
        var test = document.createElement('div');
        $(test).css({
                'width': '1px',
            'min-width': '2px'
        });
        $('body').append(test);

        // In compliant browsers, the min-width of 2px should overwrite the
        // width of 1px.
        $.minmax.native = ( test.offsetWidth && test.offsetWidth == 2 );

        // Tidy up.
        $(test).remove();

        // Go no further if minmax is supported natively.
        if( $.minmax.native )
            return;


        // Use jQMinMax.
        $.minmax.active = true;

        // Set up the minmax jQuery expressions.
        $.minmax.expressions();


        // Use the plugin on all elements where a min/max CSS style is set.
        $(':minmax').minmax();
    });



    /**
     * Set up the minmax jQuery expressions.
     *
     * @example $.minmax.expressions();
     *
     * @name $.minmax.expressions
     * @cat  jQMinMax
     */
    $.minmax.expressions = function() {
        // p for 'properties'.
        var p = new Array( 'min-width', 'min-height',
                           'max-width', 'max-height' );

        // This will hold the components of an uber selector for grabbing
        // anything with a minmax value.
        var minmax = new Array();

        for( var i = 0; i < p.length; i++ ) {
            // Build the expression.
            var expr = "$.css(a,'" + p[i] + "')!='0px'&&"
                     + "$.css(a,'" + p[i] + "')!='auto'&&"
                     + "$.css(a,'" + p[i] + "')!=window.undefined";

            // max-width / max-height can also have the value 'none'.
            if( p[i].charAt(2) == 'x' )
                expr += "&&$.css(a,'" + p[i] + "')!='none'";

            // Add the expression to jQuery.
            $.expr[':'][ p[i] ] = expr;

            // Add the expression to the ':minmax' expression.
            minmax[i] = '(' + expr + ')';
        }

        // Build and add the ':minmax' expression.
        $.expr[':']['minmax'] = minmax.join('||');
    };



    /**
     * Check the given elements for height/width values that fall outside
     * their min/max constraints and update them appropriately.
     *
     * @example $('#foo').minmax();
     *
     * @name $.fn.minmax();
     * @cat  jQMinMax
     */
    $.fn.minmax = function() {
        return $(this).each(function() {
            // Get the min/max constraints of the current element.
            var constraint = {
                'min-width':  calculate( this, 'min-width'  ),
                'max-width':  calculate( this, 'max-width'  ),
                'min-height': calculate( this, 'min-height' ),
                'max-height': calculate( this, 'max-height' )
            };

            // Determine its current width and height.
            var width  = this.offsetWidth;
            var height = this.offsetHeight;

            var newWidth  = width;
            var newHeight = height;


            // If the element is wider than its max-width...
            if( constraint['max-width'] != window.undefined
             && newWidth > constraint['max-width'] )
                newWidth = constraint['max-width'];

            // If the element is/is now thinner than its min-width...
            if( constraint['min-width'] != window.undefined
             && newWidth < constraint['min-width'] )
                newWidth = constraint['min-width'];

            // If the element is taller than its max-height...
            if( constraint['max-height'] != window.undefined
             && newHeight > constraint['max-height'] )
                newHeight = constraint['max-height'];

            // If the element is/is now shorter than its min-height...
            if( constraint['min-height'] != window.undefined
             && newHeight < constraint['min-height'] )
                newHeight = constraint['min-height'];


            // Update the proportions of the current element as required.
            if( newWidth  != width )
                $(this).css( 'width',  newWidth  );
            if( newHeight != height )
                $(this).css( 'height', newHeight );
        });
    };



    // Calculate the computed numeric value of a CSS length value.
    function calculate( obj, p ) {
        var raw = $(obj).css( p );

        // Nothing in, nothing out.
        if( raw == window.undefined || raw == 'auto' )
            return window.undefined;

        var result;

        // Is it a percentage value?
        result = raw.match(/^\+?(\d*(?:\.\d+)?)%$/);
        if( result ) {
            return Math.round(
                Number(
                    (
                        /width$/.test(p) ? $(obj).parent().get(0).offsetWidth
                                         : $(obj).parent().get(0).offsetHeight
                    )
                    * result[1]
                    / 100
                )
            );
        }


        // Is it a straight pixel value?
        result = raw.match(/^\+?(\d*(?:\.\d+)?)(?:px)?$/);
        if( result ) {
            return Number( result[1] );
        }


        // Garbage in, nothing out.
        return window.undefined;
    }
}();
























/***************************************************** JQ plugins *****************************************************/
jQuery.fn.same_height = function() {
	var max = 0;
	this.each(function() {
		var h = $(this).height();
		if (h > max) {
			max = h;
		}
	});
	return this.css('height', max+'px');
};
jQuery.fn.same_width = function() {
	var max = 0;
	this.each(function() {
		var w = $(this).width();
		if (w > max) {
			max = w;
		}
	});
	return this.css('width', max+'px');
};
jQuery.fn.adjust_width = function(childs, padding, margin) {
	var max = this.width();
	var n   = this.find(childs).length;
	max += parseInt(this.css('padding-left').replace(/px/, ''));
	max += parseInt(this.css('padding-right').replace(/px/, ''));
	if (n > 0) {
		var w = parseInt(max/n - 2*(padding ? padding : 0) - 2*(margin ? margin : 0));
		return this.find(childs).css({
			'width'  :w+'px',
			'padding':(padding ? padding : 0)+'px',
			'margin' :(margin ? margin : 0)+'px'
		});
	} else {
		return this;
	}
};
jQuery.fn.adjust_spacing_horiz = function(childs) {
	var max = this.width();
	var n   = this.find(childs).length;
	var w   = 0;
	this.find(childs).each(function() {
		w += $(this).width();
	});
	if (w < max && n > 1) {
		var m = parseInt((max - w)/(n - 1)/2);
		this.find(childs).each(function(i) {
			//alert(max+' '+i+'/'+n+' '+w+' '+m);
			if (i > 0) {
				$(this).css('margin-left', m+'px');
			}
			if (i < n-1) {
				$(this).css('margin-right', m+'px');
			}
		});
	}
	return this;
};
jQuery.fn.center = function() {
	return this.each(function() {
		var pw = $(this).parent().width();
		var ph = $(this).parent().height();
		var w  = $(this).width();
		var h  = $(this).height();
		var mw = parseInt((pw-w)/2);
		var mh = parseInt((ph-h)/2);
		
		//alert(pw+' '+ph+"\n"+w+' '+h+"\n"+mw+' '+mh+"\n");
		if (mw > 0) {
			$(this).css({
				'margin-left'  : mw+'px',
				'margin-right' : mw+'px'
			});
		}
		if (mh > 0) {
			$(this).css({
				'margin-top'   : mh+'px',
				'margin-bottom': mh+'px'
			});
		}
	});
};





















/***************************************************** INIT *****************************************************/

// Init
var PreloadImages = new Array();
var MyRoot = './';

 $(document).ready(function() {
/****************************************************
 **  add target='_blank' to all <A> tag with rel='external'
 **/
	$("a").each(function() {
		if ($(this).attr("rel") == "external") {
			$(this).attr("target", "_blank");
		};
	});
/****************************************************
 **  PNG managment under IE
 **/
	if (($.browser.version.number >= 5.5) && ($.browser.version.number < 7.0) && (document.body.filters) && $.browser.msie) {
		// Images
		$("img").each(function() {
			if (this.src.match(/\.png$/i)) {
				var imgID = (this.id) ? "id='" + this.id + "' " : "";
				var imgClass = (this.className) ? "class='" + this.className + "' " : "";
				var imgTitle = (this.title) ? "title='" + this.title + "' " : "title='" + this.alt + "' ";
				var imgStyle = "display:inline-block;" + this.style.cssText ;
				if (this.align == "left") { imgStyle = "float:left;" + imgStyle }
				if (this.align == "right") { imgStyle = "float:right;" + imgStyle }
				if (this.parentElement.href) { imgStyle = "cursor:hand;" + imgStyle }
				this.outerHTML = "<span " + imgID + imgClass + imgTitle
				+ " style=\"" + "width:" + this.width + "px; height:" + this.height + "px;" + imgStyle + ";"
				+ "filter:progid:DXImageTransform.Microsoft.AlphaImageLoader"
				+ "(src=\'" + this.src + "\', sizingMethod='scale');\"></span>" ;
			}
		});
		/* Backgrounds-Images ***  ! ne marche pas ... pourquoi ? tant pis ... ! 31/01/2007
		$("a, td, span, div").each(function() {
			var a;
			if (a = this.style.backgroundImage.match(/url\((.+)\)/i)) {
				this.style.backgroundImage = '';
				this.style.filter = "progid:DXImageTransform.Microsoft.AlphaImageLoader(src='"+a[1].replace(/"|'/g, "")+"', sizingMethod='crop', enabled=true)";
			}
		});
		*/
	}
/****************************************************
 **  image over button
 **/
	$(".over").each(function() {
		var a, img = '';
		if ($(this).attr('src')) {
			img = $(this).attr('src').replace(/"/g, "");
		} else if ($(this).css('background-image')) {
			img = $(this).css('background-image').replace(/"/g, '').replace('url(', '').replace(/\)$/, '');
		}
		if (img.match("_over.")) {
			PreloadImages.push(img.replace("_over.", "."));
		} else if (a = img.match(/(\.[a-z]{3,4})$/i)) {
			PreloadImages.push(img.replace(a[1], '_over'+a[1]));
		}
		$(this).mouseout(ImgOver);
		$(this).mouseover(ImgOver);
	});
/****************************************************
 **  Swap image and affects value in formular
 **/
	$("img.form_boolean").each(function() {
		var m;
		if (m = this.src.match(/^(.*)([01])(\.[a-z]{3,4})$/i)) {
			var bool = (parseInt(m[2]+"")+1)%2;
			PreloadImages.push(m[1]+bool+m[3]);
			$(this).click(Form_Boolean);
		}
	});
/****************************************************
 **  force images to be load faster
 **/
	var preload_text = '';
	for(i=0; i<PreloadImages.length; i++) {
		var img;
		if (PreloadImages[i].match(/^https?:/)) {
			preload_text += '<img src="'+PreloadImages[i]+'" />';
		} else {
			preload_text += '<img src="'+MyRoot+PreloadImages[i]+'" />';
		}
	}
	if (preload_text != '') {
		$('body').append('<span style="display:none">'+preload_text+'</span>');
	}
/****************************************************
 **  Mouse management
 **/
	$('.alt_text').each(function () {
		if ($(this).attr('alt')) {
			$(this).prepend('<span style="display:none;">'+$(this).attr('alt')+'</span>');
		} else if ($(this).attr('title')) {
			$(this).prepend('<span style="display:none;">'+$(this).attr('title')+'</span>');
		} else if ($(this).attr('innerHTML')) {
			$(this).prepend('<span style="display:none;">'+$(this).attr('innerHTML').replace(/<\/?[a-z]+.*?>/, '')+'</span>');
		}
		$(this).attr('alt', '');
		$(this).attr('title', '');
		$(this).mouseover(function () {
			if ($(this).find('span:eq(0)').length == 1) {
				Alt_Show('<div class="text">'+$(this).find('span:eq(0)').attr('innerHTML')+'</div>');
			}
		});
		$(this).mouseout(Alt_Hide);
	});
	$('img.alt_img').each(function () {
		$(this).mouseover(function () {
			if ($(this).attr('longdesc')) {
				if ($(this).next().find('img').length != 1) {
					var w = 0;
					var h = 0;
					var m;
					if (m = $(this).attr('alt').match(/\(\s*([0-9]+)\s*x\s*([0-9]+)\s*\)/i)) {
						$(this).attr('alt', $(this).attr('alt').replace(/\(\s*([0-9]+)\s*x\s*([0-9]+)\s*\)/i, ''));
						w = parseInt(m[1]);
						h = parseInt(m[2]);
						$(this).attr('title', '');
					}
					if (w > 0 && h > 0) {
						$(this).after('<span style="display:none;"><img class="img" src="'+$(this).attr('longdesc')+'" alt="" width="'+w+'" height="'+h+'" /></span>');
					} else {
						$(this).after('<span style="display:none;"><img class="img" src="'+$(this).attr('longdesc')+'" alt="" /></span>');
					}
				}
				var next = $(this).next();
				if (next.find('img').length == 1) {
					var w = next.find('img').css('width').replace(/px/, '');
					var h = next.find('img').css('height').replace(/px/, '');
					Alt_Show(next.attr('innerHTML'), w, h);
				}
			}
		});
		$(this).mouseout(Alt_Hide);
	});
});





















/***************************************************** FONCTIONS *****************************************************/



/****************************************************
 **  check if param is a valid email string
 **/
function emailCheck (emailStr) {
	/* The following pattern is used to check if the entered e-mail address
	   fits the user@domain format.  It also is used to separate the username
	   from the domain. */
	var emailPat=/^(.+)@(.+)$/;
	/* The following string represents the pattern for matching all special
	   characters.  We don't want to allow special characters in the address. 
	   These characters include ( ) < > @ , ; : \ " . [ ]    */
	var specialChars="\\(\\)<>@,;:\\\\\\\"\\.\\[\\]";
	/* The following string represents the range of characters allowed in a 
	   username or domainname.  It really states which chars aren't allowed. */
	var validChars="\[^\\s" + specialChars + "\]";
	/* The following pattern applies if the "user" is a quoted string (in
	   which case, there are no rules about which characters are allowed
	   and which aren't; anything goes).  E.g. "jiminy cricket"@disney.com
	   is a legal e-mail address. */
	var quotedUser="(\"[^\"]*\")";
	/* The following pattern applies for domains that are IP addresses,
	   rather than symbolic names.  E.g. joe@[123.124.233.4] is a legal
	   e-mail address. NOTE: The square brackets are required. */
	var ipDomainPat=/^\[(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})\]$/;
	/* The following string represents an atom (basically a series of
	   non-special characters.) */
	var atom=validChars + '+';
	/* The following string represents one word in the typical username.
	   For example, in john.doe@somewhere.com, john and doe are words.
	   Basically, a word is either an atom or quoted string. */
	var word="(" + atom + "|" + quotedUser + ")";
	// The following pattern describes the structure of the user
	var userPat=new RegExp("^" + word + "(\\." + word + ")*$");
	/* The following pattern describes the structure of a normal symbolic
	   domain, as opposed to ipDomainPat, shown above. */
	var domainPat=new RegExp("^" + atom + "(\\." + atom +")*$");
	
	
	/* Finally, let's start trying to figure out if the supplied address is
	   valid. */
	
	/* Begin with the coarse pattern to simply break up user@domain into
	   different pieces that are easy to analyze. */
	var matchArray=emailStr.match(emailPat);
	if (matchArray==null) {
		/* Too many/few @'s or something; basically, this address doesn't
		even fit the general mould of a valid e-mail address. */
		alert("L'adresse email est incorrecte (v�rifiez @ and .'s)");
		return false;
	}
	var user=matchArray[1];
	var domain=matchArray[2];
	
	// See if "user" is valid 
	if (user.match(userPat)==null) {
		// user is not valid
		alert("Le nom d'utilisateur n'est pas valide.");
		return false;
	}
	
	/* if the e-mail address is at an IP address (as opposed to a symbolic
	   host name) make sure the IP address is valid. */
	var IPArray=domain.match(ipDomainPat);
	if (IPArray!=null) {
		// this is an IP address
		for (var i=1;i<=4;i++) {
			if (IPArray[i]>255) {
				alert("L'adresse IP de destination n'est pas valide !");
				return false;
			}
		}
		return true;
	}
	
	// Domain is symbolic name
	var domainArray=domain.match(domainPat);
	if (domainArray==null) {
		alert("Le nom de domaine n'est pas valide.");
		return false;
	}
	
	/* domain name seems valid, but now make sure that it ends in a
	   three-letter word (like com, edu, gov) or a two-letter word,
	   representing country (uk, nl), and that there's a hostname preceding 
	   the domain or country. */
	
	/* Now we need to break up the domain to get a count of how many atoms
	   it consists of. */
	var atomPat=new RegExp(atom,"g");
	var domArr=domain.match(atomPat);
	var len=domArr.length;
	if (domArr[domArr.length-1].length<2 || 
		domArr[domArr.length-1].length>3) {
		// the address must end in a two letter or three letter word.
		alert("L'adresse doit finir par 2 ou 3 lettres.");
		return false;
	}
	
	// Make sure there's a host name preceding the domain.
	if (len<2) {
		var errStr="Cette adresse n'a pas de nom d'h�te!";
		alert(errStr);
		return false;
	}
	
	// If we've gotten this far, everything's valid!
	return true;
}
/****************************************************
 **  Return X and Y pos relative to parent object
 **/
function findPosX(obj) {
	var curleft = 0;
	if(obj.offsetParent) {
		while(1) {
			curleft += obj.offsetLeft;
			if(!obj.offsetParent) { break; }
			obj = obj.offsetParent;
		}
	} else if(obj.x) {
		curleft += obj.x;
	}
	return curleft;
}
function findPosY(obj) {
	var curtop = 0;
	if(obj.offsetParent) {
		while(1) {
			curtop += obj.offsetTop;
			if(!obj.offsetParent) { break; }
			obj = obj.offsetParent;
		}
	} else if(obj.y) {
		curtop += obj.y;
	}
	return curtop;
}
function Point(x, y) {
	this.x = x;
	this.y = y;
}
function findPos(o) {
	var oX = 0;
	var oY = 0;
	if (o.offsetParent) {
		while (1) {
			oX+=o.offsetLeft;
			oY+=o.offsetTop;
			if (!o.offsetParent) {
				break;
			}
			o=o.offsetParent;
		}
	} else if (o.x) {
		oX+=o.x;
		oY+=o.y;
	}
	//alert(oX + �:� + oY);
	return new Point(oX, oY);
}
/****************************************************
 **  Onload function
 **/
function addLoadListener(func) {
	if (window.addEventListener) {
		window.addEventListener("load", func, false);
	} else if (document.addEventListener) {
		document.addEventListener("load", func, false);
	} else if (window.attachEvent) {
		window.attachEvent("onload", func);
	}
}

/***************************************************** MOUSE *****************************************************/

// gestion d'un objet volant
var MouseALT_Enabled = false;
var MouseALT_Div = "AltDiv";
var MouseALT_Height = 9;
var MouseALT_Width = 0;

// affiche le message volant
function Alt_Show(msg, w, h) {
	MouseALT_Width = w ? w : 0;
	MouseALT_Height = h ? h : 0;
	MouseALT_Enabled = true;
	if (document.getElementById) {
		var div = document.getElementById(MouseALT_Div);
		div.innerHTML = msg;
		Alt_Move();
		div.style.visibility = "visible";
	}
}

// move Alt window if visible
function Alt_Move() {
	var div = document.getElementById(MouseALT_Div);
	if (MouseALT_Enabled) {
		var x = $(window).width() + $(document).scrollLeft() - 20 - (MouseX + 14);
		var y = $(window).height() + $(document).scrollTop() - (MouseY + 20);
		if ($.browser.msie) { x += 12; }
		if (y > MouseALT_Height) {
			if (x > MouseALT_Width) {
				div.style.left = (MouseX+14)+"px";
				div.style.top  = (MouseY+20)+"px";
			} else {
				div.style.left = (MouseX+14 + x - MouseALT_Width)+"px";
				div.style.top  = (MouseY+20)+"px";
			}
		} else {
			if (x > MouseALT_Width) {
				div.style.left = (MouseX+14)+"px";
				div.style.top  = (MouseY+20 + y - MouseALT_Height)+"px";
			} else {
				div.style.left = (MouseX-10 - MouseALT_Width)+"px";
				div.style.top  = (MouseY-10 - MouseALT_Height)+"px";
			}
		}
	}
}

// cache le message volant
function Alt_Hide() {
	MouseALT_Enabled = false;
	if (document.getElementById) {
		document.getElementById(MouseALT_Div).innerHTML = '';
		document.getElementById(MouseALT_Div).style.visibility = "hidden";
	}
	
}

// Set Netscape up to run the "captureMousePosition" function whenever
// the mouse is moved. For Internet Explorer and Netscape 6, you can capture
// the movement a little easier.
if (document.layers) { // Netscape
	document.captureEvents(Event.MOUSEMOVE);
	document.onmousemove = getMouseXY;
} else if (document.all) { // Internet Explorer
	document.onmousemove = getMouseXY;
} else if (document.getElementById) { // Netcsape 6
	document.onmousemove = getMouseXY;
}

// Vars X and Y
var MouseX = 0; // Horizontal position of the mouse on the screen
var MouseY = 0; // Vertical position of the mouse on the screen

// Main function to retrieve mouse x-y pos.s
function getMouseXY(e) {
	var e = (e) ? e : window.event;
    if (e.pageX) {
        // When the page scrolls in Netscape, the event's mouse position
        // reflects the absolute position on the screen. innerHight/Width
        // is the position from the top/left of the screen that the user is
        // looking at. pageX/YOffset is the amount that the user has 
        // scrolled into the page. So the values will be in relation to
        // each other as the total offsets into the page, no matter if
        // the user has scrolled or not.
        MouseX = e.pageX;
        MouseY = e.pageY;
    } else if (e.x) {
        // When the page scrolls in IE, the event's mouse position 
        // reflects the position from the top/left of the screen the 
        // user is looking at. scrollLeft/Top is the amount the user
        // has scrolled into the page. clientWidth/Height is the height/
        // width of the current page the user is looking at. So, to be
        // consistent with Netscape (above), add the scroll offsets to
        // both so we end up with an absolute value on the page, no 
        // matter if the user has scrolled or not.
        MouseX = e.x + $(document).scrollLeft();
        MouseY = e.y + $(document).scrollTop();
    }
	// catch possible negative values in NS4
	if (MouseX < 0) { MouseX = 0; }
	if (MouseY < 0) { MouseY = 0; }
	// move Alt window if visible
	Alt_Move();
	return true;
}
/****************************************************
 **  Popups
 **/
function PopUp(nUrl, nNom, w, h, nScroll, nResizable){
	// Centrer le popUp
	var winl = (screen.width) ? (screen.width-w)/2 : 0;
	var wint = (screen.height) ? (screen.height-h)/2 : 0;
	var options = 'width='+w+',height='+h+','+
		'top='+wint+',left='+winl+','+
		'scrollbars='+nScroll+',resizable='+nResizable+','+
		'fullscreen=no,status=no,menubar=no,directories=no,location=no,toolbar=no';
	// Ouvrir le popUp
	var fen = window.open(nUrl,nNom,options);
	// Forcer le focus sur un PopUp d�j� ouvert
	if(fen.window.focus) { fen.window.focus(); }
}
function PopUpFullScreen(nUrl, nNom, nScroll, nResizable){
	var w = (screen.width) ? (screen.width) : 800;
	var h = (screen.height) ? (screen.height) : 600;
	var options = 'width='+w+',height='+h+','+'top=0,left=0,'+
		'scrollbars='+nScroll+',resizable='+nResizable+','+
		'fullscreen=no,status=no,menubar=no,directories=no,location=no,toolbar=no';
	// Ouvrir le popUp
	var fen = window.open(nUrl,nNom,options);
	if (screen.width) {
		fen.moveTo(0,0);
		fen.resizeTo(w, h-32);
	}
	// Forcer le focus sur un PopUp d�j� ouvert
	if(fen.window.focus) { fen.window.focus(); }
}
/****************************************************
 **  Swap the display of a block
 **/
function SwapDisplay(id) {
	if ($('#'+id).css('display') == 'block') {
		$('#'+id).css('display', 'none');
	} else {
		$('#'+id).css('display', 'block');
	}
}
/****************************************************
 **  Swap image 
 **/
function ImgOver(obj) {
	var img = typeof(obj)=="string" ? document.getElementById(obj) : (obj.src == undefined ? this : obj);
	var a, val;
	if ($(img).attr('src')) {
		val = $(img).attr('src').replace(/"/g, "");
		if (val.match("_over.")) {
			img.src = val.replace("_over.", ".");
		} else {
			if (a = val.match(/(\.[a-z]{3,4})$/i)) {
				img.src = val.replace(a[1], '_over'+a[1]);
			}
		}
	} else if ($(img).css('background-image')) {
		val = $(img).css('background-image').replace(/"/g, "");
		if (val.match("_over.")) {
			img.style.backgroundImage = val.replace("_over.", ".");
		} else {
			if (a = val.match(/(\.[a-z]{3,4}\s*\))$/i)) {
				img.style.backgroundImage = val.replace(a[1], '_over'+a[1]);
			}
		}
	}
}
/****************************************************
 **  Swap image and affects value in formular
 **/
function Form_Boolean(obj) {
	var img = typeof(obj)=="string" ? document.getElementById(obj) : (obj.src == undefined ? this : obj);
	var a, m, id;
	if (a = img.id.match(/^img_(.*)$/i)) {
		id = a[1];
	} else if (document.getElementById('img_'+img.id)) {
		id = img.id;
		img = document.getElementById('img_'+img.id);
	}
	if (m = img.src.match(/^(.*)([01])(\.[a-z]{3,4})$/i)) {
		var bool = (parseInt(m[2]+"")+1)%2;
		if (document.getElementById(id)) {
			document.getElementById(id).value = bool;
		}
		img.src = m[1]+bool+m[3];
	}
}
