<?php
/****************************************************************************
* Copyright (c) 1998, Arnaud BUATHIER - Arnapou
* http://www.arnapou.net
* Version : 4.5 (2007/01/05)
* All rights reserved.
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
*
*     * Redistributions of source code must retain the above copyright
*       notice, this list of conditions and the following disclaimer.
*     * Redistributions in binary form must reproduce the above copyright
*       notice, this list of conditions and the following disclaimer in the
*       documentation and/or other materials provided with the distribution.
*     * Neither the name of the Arnaud BUATHIER, Arnapou nor the
*       names of its contributors may be used to endorse or promote products
*       derived from this software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL THE REGENTS AND CONTRIBUTORS BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

define('ARNAPOU_OPTIMIZE_HTML'   , true);  // si le contenu HTML est optimis� (sans Cr ni Lf etc ...)
define('ARNAPOU_SHOW_ERRORS'     , false); // affiche certains messages d'erreur ou pas
define('ARNAPOU_OBFUSCATE_EMAIL' , true);  // rend les emails moins lisibles par les robots
define('ARNAPOU_REMOVE_BODY'     , true);  // ne garde que ce qu'il y a entre <body> et </body> pour les sous-templates

/****************************************************************************
 **  function to obfuscate emails
 **/
function arnapou_obfuscate_emails($matches) {
	$email      = $matches[2];
	$obfuscated = '';
	if ($matches[1] != '') {
		$obfuscated = '';
		$text       = 'mailto';
		for($i = 0; $i < strlen($text); $i++) {
			$r = rand(0, 4);
			if ($r < 3)      { $obfuscated .= '&#'.ord($text[$i]).';'; }
			else             { $obfuscated .= $text[$i]; }
		}
		$obfuscated .= ':';
		for($i = 0; $i < strlen($email); $i++) {
			$r = rand(0, 7);
			if ($r < 3)      { $obfuscated .= '%'.dechex(ord($email[$i])); }
			else if ($r < 6) { $obfuscated .= '&#'.ord($email[$i]).';'; }
			else             { $obfuscated .= $email[$i]; }
		}
	} else {
		for($i = 0; $i < strlen($email); $i++) {
			$r = rand(0, 4);
			if ($r < 3)      { $obfuscated .= '&#'.ord($email[$i]).';'; }
			else             { $obfuscated .= $email[$i]; }
		}
	}
	return $obfuscated;
}
/****************************************************************************
 **  OItem
 **/
class OItem {
	var $Replace;                 // Stocke les remplacements � effectuer
	var $Replace_Peres;           // Stocke les remplacements � effectuer (fusion des peres)
	
	var $Content     = '';        // contenu brut du fichier HTML
	var $Analyzed    = False;     // si le contenu HTML a �t� analys�
	var $ClassType   = '';        // type de l'objet

	var $Parameters  = array();   // param�tres �ventuels de l'objet
	var $Items       = array();   // contenu structur� de la page    
	
	var $Root        = NULL;      // Pointeur vers la racine des objets
	
	var $Remove_Body = False;     // Si le body doit �tre enlev� du template

	var $isAJAX      = False;
	
	var $DisplayFunctions        = array();
	var $DisplayFunctionsEnabled  = true;
	
	/**
	 ** Constructeur
	 **/
	function __construct(& $Root = NULL) {
		$this->Replace       = new OReplace();
		$this->Replace_Peres = new OReplace();
		$this->ClassType     = get_class($this);
		$this->Root          = & $Root;
	}
	/**
	 ** push display function
	 **/
	function PushDisplay($funcname) {
		array_push($this->Root->DisplayFunctions, $funcname);
	}
	/**
	 ** pop display function
	 **/
	function PopDisplay() {
		return array_pop($this->Root->DisplayFunctions);
	}
	/**
	 ** get
	 **/
	function __get($nom_champ) {
		switch($nom_champ) {
			case 'NbItems':
				return count($this->Items);
				break;
			case 'DisplayEnabled':
				return $this->Root->DisplayFunctionsEnabled;
				break;
		}
	}
	/**
	 ** set
	 **/
	function __set($nom_champ, $val_champ) {
		switch($nom_champ) {
			case 'DisplayEnabled':
				$this->Root->DisplayFunctionsEnabled = $val_champ === false ? false : true;
				break;
		}
	}
	/**
	 ** manage html code before sending it to browser
	 **/
	function Display($html) {
		$output = $html;
		if (ARNAPOU_OBFUSCATE_EMAIL) {
			$output = preg_replace_callback(
				'/(mailto:)?([a-z0-9._-]+@[a-z0-9.-]{2,}[.][a-z]{2,3})/si', 
				'arnapou_obfuscate_emails', 
				$output
			);
		}
		if ($this->Root->DisplayFunctionsEnabled) {
			foreach($this->Root->DisplayFunctions as $funcname) {
				if (function_exists($funcname)) {
					$output = call_user_func($funcname, $output);
				}
			}
		}
		// change <br> and <hr> to <br /> and <hr />
		$output = preg_replace('/<(br|hr)\s*>/si', '<$1 />', $output);
		echo $output;
	}
	/**
	 ** optimize javascript code and return it
	 **/
	static function Optimize_JS($content) {
		$js = $content;
		if (ARNAPOU_OPTIMIZE_HTML) {
			//showpre($js);
			$js = preg_replace('/^\/\/[^\n]*/is', '', $js);            //  remove // comments
			$js = preg_replace('/\n\/\/[^\n]*/is', "\n", $js);         //  remove // comments
			$js = preg_replace('/[\t\r ]+\/\/[^\n]*/is', '', $js);     //  remove // comments
			$js = preg_replace('/(\{|,|;)\/\/[^\n]*/is', '$1', $js);   //  remove // comments
			$js = preg_replace('/\/\*(.|\n|\t|\r)*?\*\//is', '', $js); //  remove /* comments /*
			$js = preg_replace('/\r+/is', '', $js);                    //  remove \r
			$js = preg_replace('/\n\s+/is', "\n", $js);                //  remove spaces at line start
			$js = preg_replace('/\s+\n/is', "\n", $js);                //  remove spaces at line end
			$js = preg_replace('/\n\n+/is', "\n", $js);                //  remove additionnal \n
			$js = preg_replace('/\{\n/is', '{', $js);
			$js = preg_replace('/;\n\}/is', ';}', $js);
			$js = preg_replace('/;\n\}/is', ';}', $js);
			$js = preg_replace('/\}\n\}/is', '}}', $js);
			$js = preg_replace('/\}\n\}/is', '}}', $js);
			$js = preg_replace('/\}\n\}/is', '}}', $js);
			$js = preg_replace('/\}\n\}/is', '}}', $js);
			$js = preg_replace('/,\n/is', ',', $js);
			$js = preg_replace('/\[\n/is', '[', $js);
			$js = preg_replace('/\n\]/is', ']', $js);
			$js = preg_replace('/\}\n(else[^\{]*)\n\{/is', '}$1{', $js);
			$js = preg_replace('/\s*;\n/is', ';', $js);
			$js = preg_replace('/:\n/is', ':', $js);
			$js = preg_replace('/\(\n/is', '(', $js);
			$js = preg_replace('/\n\)/is', ')', $js);
			$js = preg_replace('/\n\+/is', '+', $js);
			$js = preg_replace('/\+\n/is', '+', $js);
			$js = preg_replace('/\n\?/is', '?', $js);
			$js = preg_replace('/\?\n/is', '?', $js);
			$js = preg_replace('/\n\./is', '.', $js);
			$js = preg_replace('/\.\n/is', '.', $js);
			$js = preg_replace('/\n\&\&/is', ' &&', $js);
			$js = preg_replace('/\&\&\n/is', '&& ', $js);
			$js = preg_replace('/\n\|\|/is', ' ||', $js);
			$js = preg_replace('/\|\|\n/is', '|| ', $js);
			$js = preg_replace('/\nelse/is', ' else', $js);
			$js = preg_replace('/else\n/is', 'else ', $js);
			$js = preg_replace('/ +\}/is', '}', $js);
			$js = preg_replace('/\} +/is', '}', $js);
			$js = preg_replace('/ +\{/is', '{', $js);
			$js = preg_replace('/\{ +/is', '{', $js);
			$js = preg_replace('/\)\n\{/is', '){', $js);
			$js = preg_replace('/^\n+/is', '', $js);
			$js = preg_replace('/\n+$/is', '', $js);
			$js = preg_replace('/if +\(/is', 'if(', $js);
			$js = preg_replace('/for +\(/is', 'for(', $js);
			$js = preg_replace('/while +\(/is', 'while(', $js);
			$js = preg_replace('/([a-z0-9._]+) *= */is', '$1=', $js);
			$js = preg_replace('/ *== */is', '==', $js);
			$js = preg_replace('/ *!= */is', '!=', $js);
			$js = preg_replace('/ *> */is', '>', $js);
			$js = preg_replace('/ *< */is', '<', $js);
			$js = preg_replace('/ *>= */is', '>=', $js);
			$js = preg_replace('/ *<= */is', '<=', $js);
		}
		return $js;
	}
	/**
	 ** optimize html and return code
	 **/
	static function Optimize_HTML($content, $all = true) {
		$txt = $content;
		if (ARNAPOU_OPTIMIZE_HTML) {
			if ($all) {
				// optimise le JS + HTML
				$Pattern= '|(.*<script.*?javascript.*?>)(.*?)(</script>.*)|is';
				$txtfin = '';
				while (preg_match($Pattern, $txt, $m)) {
					$txtfin = OItem::Optimize_JS($m[2]).OItem::Optimize_HTML($m[3], false).$txtfin;
					$txt	= $m[1];
				}
				$txt	= OItem::Optimize_HTML($txt, false).$txtfin;
				$txtfin = '';
			} else {
				// optimise l'HTML
				$Pattern= '|(.*)<pre>(.*?)</pre>(.*)|is';
				$txtfin = '';
				$a1 = array( '/\t+/si' , '/\n+/si' , '/\r+/si' );
				$a2 = array( ''        , ''        , ''         );
				while (preg_match($Pattern, $txt, $m)) {
					$txtfin = '<pre>'.$m[2].'</pre>'.preg_replace($a1, $a2, $m[3]).$txtfin;
					$txt	= $m[1];
				}
				$txt	= preg_replace($a1, $a2, $txt).$txtfin;
				$txtfin = '';
				$a1 = array( '/ +>/si' , '/< +/si' , '/<!--.*?-->/si' , '/  +/si' );
				$a2 = array( '>'       , '<'       , ''               , ' '       );
				while (preg_match($Pattern, $txt, $m)) {
					$txtfin = '<pre>'.$m[2].'</pre>'.preg_replace($a1, $a2, $m[3]).$txtfin;
					$txt	= $m[1];
				}
				$txt = preg_replace($a1, $a2, $txt).$txtfin;
			}
		}
		return $txt;
	}

}
/****************************************************************************
 **  OHtml
 **/
class OHtml extends OItem {
	/**
	 ** Constructeur
	 **/
	function __construct($Content, & $Root = NULL) {
		parent::__construct($Root);
		$this->Content = $Content;
	}
	/** 
	 ** retourne le code HTML
	 **/
	function Out() {
		$tmp = $this->Content;
		$tmp = $this->Replace_Peres->Replace($tmp);
		$tmp = $this->Replace->Replace($tmp);
		$this->Display($tmp);
	}
}
/****************************************************************************
 **  OExec
 **/
class OExec extends OItem {
	/**
	 ** Constructeur
	 **/
	function __construct($Content, & $Root = NULL) {
		parent::__construct($Root);
		$this->Content = $Content;
	}
	/** 
	 ** Execute le code Php
	 **/
	function Out() {
		$tmp = $this->Content;
		$tmp = $this->Replace_Peres->Replace($tmp);
		$tmp = $this->Replace->Replace($tmp);
		eval($tmp.';');
	}
}
/****************************************************************************
 **  OPage
 **/
class OPage extends OTemplate {
	var $HTM_filename = '';    // nom du fichier HTML
	var $Objects      = NULL;  // contient les objets HTML utilis�s pour le rendu

	/**
	 ** Constructeur
	 **/
	function __construct($filename = '', & $Root = NULL, $Remove_Body = false) {
		if ($Root === NULL) {
			parent::__construct('', $this);
		} else {
			parent::__construct('', $Root);
		}
		$this->HTM_filename  = $filename;
		$this->Remove_Body   = $Remove_Body;
		$this->Objects       = new OObjects($this->Root);
	}
	/**
	 ** Analyse du fichier
	 **/
	function Analyze() {
		if (!$this->Analyzed || preg_match('/__[a-z0-9_-]+__/si', $this->HTM_filename)) {
			$ficname = $this->Replace_Peres->Replace($this->HTM_filename);
			$ficname = $this->Replace->Replace($ficname);
			if (file_exists($ficname)) {
				$this->Content = file_get_contents($ficname);
			} else if (file_exists($ficname.'.tpl')) {
				$this->Content = file_get_contents($ficname.'.tpl');
			} else {
				if (ARNAPOU_SHOW_ERRORS) {
					die("le fichier source '".$ficname."' n'existe pas"); 
				}
			}
			$this->Items = array();
			$this->Optimize();
			$this->Detect_Blocks($this->Content);
			$this->Analyzed = true;
		}
		$this->Detect_Random();
	}
	
	/**
	 ** Get the HTML Content
	 **/
	function GetHTML() {
		ob_start();
		$this->Out();
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
	}
	
	/**
	 ** Compatibility function with AJAX system
	 **/
	function Export($funcList = "") {
		die('<span style="color:red;font-size:14px;font-weight:bold;">AJAX is not enabled. Use OPageX class instead of OPage !</span>');
	}
	
	/**
	 ** Compatibility function with AJAX system
	 **/
	function ExportClass($instanceList) {
		die('<span style="color:red;font-size:14px;font-weight:bold;">AJAX is not enabled. Use OPageX class instead of OPage !</span>');
	}
	
	/**
	 ** Compatibility function with AJAX system
	 **/
	function ExportClassFunctions($funcList = "") {
		die('<span style="color:red;font-size:14px;font-weight:bold;">AJAX is not enabled. Use OPageX class instead of OPage !</span>');
	}
}

/****************************************************************************
 **  OBlock
 **/
class OBlock extends OTemplate {
	var $Pack       = '';
	var $Function   = '';
	var $Params     = '';
	var $isRecursif = false;

	/**
	 ** Constructeur
	 **/
	function __construct($BlockParams, $Parts, & $Root = NULL) {
		parent::__construct('', $Root);
		//  syntax: Pack.Function(Params)
		//           1(           ) 2(          )3(         )
		$Pattern1 = "|^([a-z0-9_-]*)\.([a-z0-9_-]+)((\(.*\))?)|is";
		//           1(          )2(         )
		$Pattern2 = "|^([a-z0-9_-]+)((\(.*\))?)|is";
		if(preg_match($Pattern1, $BlockParams, $m)) {
			$this->Pack     = $m[1]=='' ? 'default' : $m[1];
			$this->Function = $m[2];
			$this->Params   = $m[3]=='' ? '' : substr($m[3], 1, strlen($m[3])-2);
		} else if(preg_match($Pattern2, $BlockParams, $m)) {
			$this->Pack     = '';
			$this->Function = $m[1];
			$this->Params   = $m[2]=='' ? '' : substr($m[2], 1, strlen($m[2])-2);
		} else {
			die("les param�tres ne sont pas valides (".$this->ClassType.") : '".$BlockParams."' !");
		}
		foreach($Parts as $part) {
			$tmp = new OTemplate($part, $this->Root);
			$tmp->Analyze();
			$this->Items[] = $tmp;
		}
	}
		
	/** 
	 ** Execute la fonction
	 **/
	function Exec() {
		$rep = clone($this->Replace_Peres);
		if ($this->isRecursif) {
			$rep->Merge($this->Replace);
		}
		$Params = $rep->Replace($this->Params);
		if ($Params != '') { $Params = ','.$Params; }
		eval('$Params = array($this'.$Params.');');
		if ($this->Pack !== '') {
			require_once('pack.'.$this->Pack.'.php');
			call_user_func_array($this->Pack.'_'.$this->Function, $Params);
			//eval($this->Pack.'_'.$this->Function."(\$this".$Params.");");
		} else {
			call_user_func_array($this->Function, $Params);
			//eval($this->Function."(\$this".$Params.");");
		}
		$this->isRecursif = false;
	}
	
	/** 
	 ** retourne la page web
	 **/
	function Out($index = 0) {
		if (isset($this->Items[$index])) {
			$this->Items[$index]->Analyze();
			$this->Items[$index]->Replace_Peres->Merge($this->Replace_Peres);
			$this->Items[$index]->Replace_Peres->Merge($this->Replace);
			$this->Items[$index]->Out();
		} else {
			die("la partie $index n'existe pas !");
		}
	}
	
	/** 
	 ** retourne la page web recursif
	 **/
	function OutRecursif($index = 0) {
		if (count($this->Items)>=3 && $index == 0) {
			$this->Out(0);
			$bkup['Params']        = $this->Params;
			$bkup['Replace']       = clone($this->Replace);
			$bkup['Replace_Peres'] = clone($this->Replace_Peres);
			$this->isRecursif      = true;
			$this->Params          = $this->Items[1]->Content;
			$this->Exec();
			$this->Params          = $bkup['Params'];
			$this->Replace         = clone($bkup['Replace']);
			$this->Replace_Peres   = clone($bkup['Replace_Peres']);
			$this->Out(2);
		} else {
			$this->Out($index);
		}
	}
}
/****************************************************************************
 **  OTemplate
 **/
class OTemplate extends OItem {
	/**
	 ** Constructeur
	 **/
	function __construct($Content = '', & $Root = NULL) {
		parent::__construct($Root);
		$this->Content = $Content;
	}
	
	/** 
	 ** retourne la page web
	 **/
	function Out() {
		$this->Analyze();
		$this->OutItems();
	}
	
	/** 
	 ** affiche les items
	 **/
	function OutItems() {
		foreach ($this->Items as $Item) {
			$Item->Replace_Peres->Merge($this->Replace_Peres);
			$Item->Replace_Peres->Merge($this->Replace);
			if ($Item->ClassType == 'OBlock') {
				$Item->Exec();
			} else {
				$Item->Out();
			}
		}
	}
	
	/**
	 ** Analyse du fichier
	 **/
	function Analyze() {
		if (!$this->Analyzed) { // ne refait pas l'analyse si d�j� faite
			$this->Detect_Blocks($this->Content);
			$this->Analyzed = true;
		}
	}
	
	/**
	 ** optimise le resultat en enlevant les tabulations etc ... sauf entre les balises <PRE>
	 **/
	function Optimize() {
		$this->Content = OItem::Optimize_HTML($this->Content);
		if ($this->Remove_Body && ARNAPOU_REMOVE_BODY) {
			// keep only body part
			$Pattern= "|.*<body[^>]*>(.*?)</body>|is";
			if (preg_match($Pattern, $this->Content, $m)) {
				$this->Content = $m[1];
			}
		}
	}
	
	/**
	 ** Remplace {RANDOMxxx} par une suite de 8 caract�res + chiffres al�atoires
	 **/
	function Detect_Random() {
		$r = new OReplace();
		//  syntax: {RANDOMxxxx}
		$Pattern = "|(.*)\{RANDOM([^}]*)\}(.*)|is";
		$Content = $this->Content;
		while(preg_match($Pattern, $Content, $m)) {
			$this->Replace->Add('{RANDOM'.$m[2].'}', substr(md5(rand()), rand(1, 24), 8), true);
			$Content = $m[1]; // pr�pare l'it�ration suivante
		}
		$this->Detect_PHPLiveX();
	}
	
	/**
	 ** Remplace {AJAX_JS} par le code PHPLiveX qu'il faut
	 **/
	function Detect_PHPLiveX() {
		//  syntax: {AJAX_JS}
		$Pattern = "|(.*)\{AJAX_JS\}(.*)|is";
		$Content = $this->Content;
		$r = new OReplace();
		if ($this->Root->isAJAX) {
			if (preg_match($Pattern, $Content)) {
				$this->Replace->AddHTML(
					'{AJAX_JS}', 
					'<script language="javascript" type="text/javascript">'.
					$this->Root->GetJavascript().
					'</script>', 
					true
				);
			}
		} else {
			if (preg_match($Pattern, $Content)) {
				$this->Replace->Add('{AJAX_JS}', '', true);
			}
		}
	}
	
	/**
	 ** Include des fichiers HTM qui sont dans le code html
	 **/
	function Detect_Include($Content) {
		//  syntax: <TINCLUDE filename />
		//          1(  )            2(   )     3(  )
		$Pattern = "|(.*?)<TINCLUDE[ ]*(.*?)[ ]*/>(.*)|is";
		$tmp = $Content;
		while(preg_match($Pattern, $tmp, $m)) {
			$this->Detect_ExecPhp($m[1]);
			$this->Items[] = new OPage($m[2], $this->Root, true);
			$tmp = $m[3]; // pr�pare l'it�ration suivante
		}
		$this->Detect_ExecPhp($tmp);
	}
	
	/**
	 ** Detecte la balise TOBJECT
	 **/
	function Detect_Object($Content) {
		//  syntax: <TOBJECT object />
		//          1(  )         2(   )      3(  )
		$Pattern = "|(.*?)<TOBJECT[ ]*(.*?)[ ]*/>(.*)|is";
		$tmp = $Content;
		while(preg_match($Pattern, $tmp, $m)) {
			$this->Detect_Function($m[1]);
			$this->Items[] = new OObject($m[2], $this->Root);
			$tmp = $m[3]; // pr�pare l'it�ration suivante
		}
		$this->Detect_Function($tmp);
	}
	
	/**
	 ** Detecte la balise TFunction
	 **/
	function Detect_Function($Content) {
		//  syntax: <TFUNCTION code />
		//          1(  )              2(   )     3(  )
		$Pattern = "|(.*?)<TFUNCTION[ ]*(.*?)[ ]*/>(.*)|is";
		$tmp = $Content;
		while(preg_match($Pattern, $tmp, $m)) {
			$this->Items[] = new OHtml($m[1], $this->Root);
			$this->Items[] = new OFunction($m[2], $this->Root);
			$tmp = $m[3]; // pr�pare l'it�ration suivante
		}
		$this->Items[] = new OHtml($tmp, $this->Root);
	}
	
	/**
	 ** Detecte la balise TEXEC
	 **/
	function Detect_ExecPhp($Content) {
		//  syntax: <TEXEC code php />
		//          1(  )         2(   )      3(  )
		$Pattern = "|(.*?)<TEXEC[ ]*(.*?)[ ]*/>(.*)|is";
		$tmp = $Content;
		while(preg_match($Pattern, $tmp, $m)) {
			$this->Detect_Object($m[1]);
			$this->Items[] = new OExec($m[2], $this->Root);
			$tmp = $m[3]; // pr�pare l'it�ration suivante
		}
		$this->Detect_Object($tmp);
	}
	
	/**
	 ** Detecte les blocks
	 **/
	function Detect_Blocks($Content) {
		//  syntax: <TBLOCK Pack.Function(Params) />  <TELSE />  </TBLOCK>
		$Pattern = "%<TBLOCK[ ](.*?)[ ]*>|</TBLOCK>|<TELSE[^\/]+/>%is";
		preg_match_all($Pattern, $Content, $matches, PREG_SET_ORDER|PREG_OFFSET_CAPTURE);
		if (count($matches) > 0) {
			if (strpos(strtoupper($matches[0][0][0]), '<TBLOCK')!==0) {
				die("le premier �l�ment d�tect� n'est pas un BLOCK : '".$matches[0][0][0]."' !");
			}
			$lastindex = 0;
			$i      = 1;
			$tag    = strtoupper($matches[0][0][0]);
			$params = $matches[0][1][0];
			$parts  = array();
			$nivo   = 1;
			$this->Detect_Include(substr($Content, $lastindex, $matches[0][0][1] - $lastindex));
			$lastindex = $matches[0][0][1] + strlen($matches[0][0][0]);
			while ($i < count($matches) && $nivo > 0) {
				$tag    = strtoupper($matches[$i][0][0]);
				$offset = $matches[$i][0][1];
				if (strpos($tag, '<TBLOCK')===0) {
					$nivo++;
				} else if (strpos($tag, '</TBLOCK')===0) {
					$nivo--;
					if ($nivo === 0) {
						$parts[] = substr($Content, $lastindex, $matches[$i][0][1] - $lastindex);
						$this->Items[] = new OBlock($params, $parts, $this->Root);
						$parts = array();
						$lastindex = $matches[$i][0][1] + strlen($matches[$i][0][0]);
						if ($i < count($matches) - 1) {
							// si ce n'est pas le dernier de la liste
							$i++;
							if (strpos(strtoupper($matches[$i][0][0]), '<TBLOCK')!==0) {
								die("l'�l�ment d�tect� n'est pas un BLOCK : '".$matches[$i][0][0]."' !");
							}
							$params = $matches[$i][1][0];
							$this->Detect_Include(substr($Content, $lastindex, $matches[$i][0][1] - $lastindex));
							$lastindex = $matches[$i][0][1] + strlen($matches[$i][0][0]);
						}
						$nivo = 1;
					}
				} else if (strpos($tag, '<TELSE')===0) {
					if ($nivo === 1) {
						$parts[] = substr($Content, $lastindex, $matches[$i][0][1] - $lastindex);
						$lastindex = $matches[$i][0][1] + strlen($matches[$i][0][0]);
					}
				}
				$i++;
			}
			if ($nivo !== 1) {
				die("probl�me durant la d�tection d'un block");
			} else {
				$this->Detect_Include(substr($Content, $lastindex));
			}
		} else {
			$this->Detect_Include($Content);
		}
	}
}

/****************************************************************************
 **  OObject
 **/
class OObject extends OTemplate {
	
	var $entete  = '';
	var $objname = '';
	var $params  = array();
	
	/**
	 ** Constructeur
	 **/
	function __construct($entete, & $Root = NULL) {
		parent::__construct('', $Root);
		$this->entete = $entete;
		$this->Remove_Body = true;
	}
	
	/**
	 ** Analyse du fichier
	 **/
	function Analyze() {
		$this->Optimize();
		$this->Detect_Blocks($this->Content);
	}
	
	/** 
	 ** retourne la page web
	 **/
	function Out() {
		$previous_obj = $this->objname;
		
		$entete = $this->entete;
		$entete = $this->Replace_Peres->Replace($entete);
		$entete = $this->Replace->Replace($entete);
		
		//  syntax: ObjectName(Params)
		//          1(          )2(         )
		$Pattern = "|([\.a-z0-9_-]+)((\(.*\))?)|is";
		if(preg_match($Pattern, $entete, $m)) {
			$this->objname = $m[1];
			$this->Content = $this->Root->Objects->GetObject($this->objname);
			$params        = $m[2]=='' ? '' : substr($m[2], 1, strlen($m[2])-2);
			eval('$this->params = array('.$params.');');
		} else {
			die("les param�tres ne sont pas valides : '".$this->entete."' !");
		}
		
		if ($previous_obj != $this->objname) {
			$this->Items = array();
			$this->Analyze();
		}
		$a = array();
		foreach($this->params as $key => $val) {
			$a[$key] = $this->Replace_Peres->Replace($this->params[$key]);
			$a[$key] = $this->Replace->Replace($a[$key]);
		}
		$this->Detect_Random();
		$this->Replace->AddArrayHTML($a);
		$this->OutItems();
	}
}
/****************************************************************************
 **  OFunction
 **/
class OFunction extends OBlock {
	/**
	 ** Constructeur
	 **/
	function __construct($Params, & $Root = NULL) {
		parent::__construct($Params, array(), $Root);
	}
	/** 
	 ** Execute la fonction
	 **/
	function Exec() {
		$rep = clone($this->Replace_Peres);
		$Params = $rep->Replace($this->Params);
		eval('$Params = array('.$Params.');');
		if ($this->Pack !== '') {
			require_once('pack.'.$this->Pack.'.php');
			call_user_func_array($this->Pack.'_'.$this->Function, $Params);
			//eval($this->Pack.'_'.$this->Function.'('.$Params.');');
		} else {
			call_user_func_array($this->Function, $Params);
			//eval($this->Function.'('.$Params.');');
		}
	}
	/** 
	 ** Alias de Exec
	 **/
	function Out() {
		$this->Exec();
	}
}
/****************************************************************************
 **  OObjects
 **  Liste des objets charg�s
 **/
class OObjects extends OItem {
	
	/**
	 ** Constructeur
	 **/
	function __construct(& $Root = NULL) {
		parent::__construct($Root);
	}
	/** 
	 ** Ajoute un �l�ment
	 **/
	function Add($objname, $content) {
		$this->Items[$objname] = $content;
	}
	/** 
	 ** Ajoute le contenu d'un fichier en tant qu'objet
	 **/
	function AddFile($filename, $objname) {
		if (file_exists($filename)) {
			$content = file_get_contents($filename);
		} else {
			$content = '';
		}
		$this->Items[$objname] = $content;
	}
	/** 
	 ** Ajoute le contenu de chaque fichier d'un r�pertoire en tant qu'objets
	 **/
	function AddFolder($foldername) {
		$files = array();
		if (is_dir($foldername)) {
			$files = glob($foldername.'/object.*.tpl');
			if ($files === false) {
				$files = array();
			}
		}
		foreach ($files as $file) {
			$this->AddFile($file, preg_replace('/^object\./', '', basename($file, '.tpl')));
		}
	}
	/** 
	 ** R�cup�re l'HTML d'un objet
	 **/
	function GetObject($name) {
		if (isset($this->Items[$name])) {
			return $this->Items[$name];
		}
		return '';
	}
}
/****************************************************************************
 **  OReplace
 **/
class OReplace {
	var $Tab = array();
	
	/** 
	 ** Ajoute un �l�ment
	 **/
	function _add($pattern, $replace, $html = false, $exact = false) {
		if ($pattern != '' && is_scalar($replace)) {
			if ($html) {
				if ($exact || preg_match('/^__[0-9A-Z_-]+__$/', $pattern)) {
					$this->Tab['/'.preg_quote($pattern, '/').'/'] = $replace;
				} else {
					$this->Tab['/__'.preg_quote(strtoupper($pattern), '/').'__/'] = $replace;
				}
			} else {
				if ($exact || preg_match('/^__[0-9A-Z_-]+__$/', $pattern)) {
					$this->Tab['/'.preg_quote($pattern, '/').'/'] = htmlspecialchars($replace);
				} else {
					$this->Tab['/__'.preg_quote(strtoupper($pattern), '/').'__/'] = htmlspecialchars($replace);
				}
			}
		}
	}
	/** 
	 ** Ajoute un �l�ment
	 **/
	function Add() {
		$num_args = func_num_args();
		$exact    = false;
		if ($num_args%2 == 1) { $exact = func_get_arg($num_args - 1); $num_args--; }
		if ($num_args > 0) { 
			for ($i = 0 ; $i < $num_args ; $i = $i + 2) {
				$pattern = func_get_arg($i);
				$replace = func_get_arg($i + 1);
				$this->_add($pattern, $replace, false, $exact);
			}
		}
	}
	/** 
	 ** Ajoute un �l�ment des cl�s sans htmlspecialchars
	 **/
	function AddHTML() {
		$num_args = func_num_args();
		$exact    = false;
		if ($num_args%2 == 1) { $exact = func_get_arg($num_args - 1); $num_args--; }
		if ($num_args > 0) { 
			for ($i = 0 ; $i < $num_args ; $i = $i + 2) {
				$pattern = func_get_arg($i);
				$replace = func_get_arg($i + 1);
				$this->_add($pattern, $replace, true, $exact);
			}
		}
	}
	/** 
	 ** Ajoute un tableau avec des cl�s
	 **/
	function AddArray($tab, $exact = false) {
		foreach ($tab as $key => $val) {
			$this->_add($key, $val, false, $exact);
		}
	}
	/** 
	 ** Ajoute un tableau avec des cl�s sans htmlspecialchars
	 **/
	function AddArrayHTML($tab, $exact = false) {
		foreach ($tab as $key => $val) {
			$this->_add($key, $val, true, $exact);
		}
	}
	/** 
	 ** Ajoute un tableau avec des cl�s pr�fix�es
	 **/
	function AddArrayPrefix($tab, $prefix, $exact = false) {
		foreach ($tab as $key => $val) {
			$this->_add($prefix.$key, $val, false, $exact);
		}
	}
	/** 
	 ** Ajoute un tableau avec des cl�s pr�fix�es
	 **/
	function AddArrayPrefixHTML($tab, $prefix, $exact = false) {
		foreach ($tab as $key => $val) {
			$this->_add($prefix.$key, $val, true, $exact);
		}
	}
	/** 
	 ** Fusionne un autre 'OReplace' dans celui en cours
	 **/
	function Merge($replacetab) {
		$this->Tab = array_merge($this->Tab, $replacetab->Tab);
	}
	/** 
	 ** Retourne si la cl� existe ou pas
	 **/
	function ExistKey($key) {
		$keys = array_keys($this->Tab);
		$tmp_key_1 = '/'.preg_quote(strtoupper($key), '/').'/';
		$tmp_key_2 = '/__'.preg_quote(strtoupper($key), '/').'__/';
		return in_array($key, $keys) || in_array($tmp_key_1, $keys) || in_array($tmp_key_2, $keys);
	}
	/** 
	 ** Supprime un �l�ment du tableau de remplacement
	 **/
	function Remove($key) {
		$tmp_key_1 = '/'.preg_quote(strtoupper($key), '/').'/';
		$tmp_key_2 = '/__'.preg_quote(strtoupper($key), '/').'__/';
		if (isset($this->Tab[$tmp_key_1])) { unset($this->Tab[$tmp_key_1]); }
		if (isset($this->Tab[$tmp_key_2])) { unset($this->Tab[$tmp_key_2]); }
		if (isset($this->Tab[$key])) { unset($this->Tab[$key]); }
	}
	/** 
	 ** Supprime plusieurs �l�ments du tableau de remplacement (par les cl�s)
	 **/
	function RemoveArray($tab) {
		foreach($tab as $key => $val) {
			$this->Remove($key);
		}
	}
	/** 
	 ** Remplace la chaine pass�e en param�tre
	 **/
	function Replace($chaine) {
		if (count($this->Tab) > 0) {
			$patterns = array_keys($this->Tab);
			$replaces = preg_replace('/\\\/s', "\\\\\\\\", array_values($this->Tab));
			return preg_replace($patterns, $replaces, $chaine);
		} else {
			return $chaine;	
		}
	}
	/** 
	 ** RAZ du tableau
	 **/
	function RAZ() {
		$this->Tab = array();
	}
}

/****************************************************************************
 **  OPageX
 **/
class OPageX extends OPage {

	var $isAJAX = true;
	var $PHPLiveX = null;

	/**
	 ** constructor
	 **/
	function __construct($filename, $funcList = '') {
		parent::__construct($filename);
		$this->PHPLiveX = new PHPLiveX($funcList);
	}

	/**
	 ** return javascript code optimized
	 **/
	function GetJavascript() {
		$html  = $this->PHPLiveX->CreateJS();
		$html .= $this->PHPLiveX->GetFunctions();
		return OItem::Optimize_JS($html);
	}
	
	/**
	 ** Export PHPLiveX function
	 **/
	function Export($funcList = "") {
		$this->PHPLiveX->Export($funcList);
	}
	
	/**
	 ** ExportClass PHPLiveX function
	 **/
	function ExportClass($instanceList) {
		$this->PHPLiveX->ExportClass($instanceList);
	}
	
	/**
	 ** ExportClassFunctions PHPLiveX function
	 **/
	function ExportClassFunctions($funcList = "") {
		$this->PHPLiveX->ExportClassFunctions($funcList);
	}
}

/****************************************************************************
 **  PHPLiveX
 **/

 
#########################################
# PHPLiveX Library						#
# (C) Copyright 2006 Arda Beyazo�lu		#
# Version: 2.2							#
# Home Page: phplivex.sourceforge.net	#
# Contact: ardabeyazoglu@gmail.com      #
#########################################

class PHPLiveX {

	var $FileUrl;
	var $Url;
	var $Error = "";

	var $FList = array();

	function PHPLiveX($funcList = "", $url = ""){
		$this->Export($funcList);
		
		if(!empty($_SERVER['QUERY_STRING'])) $query = "?" . $_SERVER['QUERY_STRING'];
		else $query = "";
		
		if($url == ""){
			$this->Url = $_SERVER['PHP_SELF'].$query;
		}else{
			 $this->FileUrl = $url;
			 $this->Url = $url . $query;
		}
		
	}

	function Export($funcList = ""){
		if($funcList == "") return;
		$funcArray = explode(",", $funcList);
		for($i=0;$i<count($funcArray);$i++){
			$funcArray[$i] = stripslashes(trim($funcArray[$i]));
			if(function_exists($funcArray[$i])){
				if(!in_array($funcArray[$i], $this->FList)){
					$this->FList[] = $funcArray[$i];
				}
			}else{
				$this->Error .= "'".$funcArray[$i]."' function doesn't exist!";
				?>
				<script language="javascript">
				alert("<? echo $this->Error ?>");
				</script>
				<?
			}
		}
		$this->Execute();
		reset($this->FList);
	}

	function ExportClassFunctions($funcList = ""){
		if($funcList == "") return;
		$funcArray = explode(",", $funcList);
		for($i=0;$i<count($funcArray);$i++){
			$funcArray[$i] = stripslashes(trim($funcArray[$i]));
			if(strpos($funcArray[$i], "->") === false) continue;
			
			$parts = explode("->", $funcArray[$i]);
			$instanceName = $parts[0];
			$funcName = $parts[1];
			$newName = $instanceName . "__" . $funcName;
			global $$instanceName;
			 
			if(!in_array($newName, $this->FList)){
				$_SESSION["plx_" . $instanceName] = $$instanceName;
		 		$this->FList[] = $newName;
			}
		}
		reset($this->FList);
		$this->Execute();
	}

	function ExportClass($instanceList){
		if($instanceList == "") return;
		$instanceArray = explode(",", $instanceList);
		for($i=0;$i<count($instanceArray);$i++){
			$instanceArray[$i] = stripslashes(trim($instanceArray[$i]));
			
			$instanceName = $instanceArray[$i];
			global $$instanceName;
			$methods = get_class_methods($$instanceName);
		
			for($k=1;$k<count($methods);$k++){
				$newName = $instanceName . "__" . $methods[$k];
				if(!in_array($newName, $this->FList)){
					$_SESSION["plx_" . $instanceName] = $$instanceName;
					$this->FList[] = $newName;
				}
			}
		}
		reset($this->FList);
		$this->Execute();
	}

	function Execute(){
		$funcName = ""; $funcArgs = array();
		if(isset($_REQUEST['funcName'])){
			$funcName = $_REQUEST['funcName'];
			if(isset($_REQUEST['funcArgs'])) $funcArgs = $_REQUEST['funcArgs'];
			
			if(strpos($funcName, "__") === false){
				if(in_array($funcName, $this->FList)){
					$runFunc = call_user_func_array($funcName, $funcArgs);
					echo "<phplivex>"  .$runFunc . "</phplivex>";
					exit();
				}
			}else{
				if(in_array($funcName, $this->FList)){
					$parts = explode("__", $funcName);
					$object = $_SESSION["plx_" . $parts[0]];
					echo "<phplivex>" . $object->$parts[1]($funcArgs) . "</phplivex>";
					exit();
				}
			}
		}
	}

	function CreateJS(){
		ob_start();
		
		?>
		/////////////////////////////////////////
		// PHPLiveX Library                    //	
		// (C) Copyright 2006 Arda Beyazo�lu   //
		// Version: 2.2                        //
		// Home Page: phplivex.sourceforge.net //
		/////////////////////////////////////////
		
		function PHPLiveX(type, target, mode, preload, method){
			this.TYPE = type;
			this.MODE = mode;
			this.TARGET = target;
			this.PRELOAD = preload;
			this.METHOD = method;
		};
		
		PHPLiveX.prototype.GetSpecialChars = function(str){
			str = str.replace(/%E7/g,"�");
			str = str.replace(/%C7/g,"�");
			str = str.replace(/%F0/g,"�");
			str = str.replace(/%D0/g,"�");
			str = str.replace(/%FD/g,"�");
			str = str.replace(/%DD/g,"�");
			str = str.replace(/%F6/g,"�");
			str = str.replace(/%D6/g,"�");
			str = str.replace(/%FE/g,"�");
			str = str.replace(/%DE/g,"�");
			str = str.replace(/%FC/g,"�");
			str = str.replace(/%DC/g,"�");
			return unescape(str);
		};

		PHPLiveX.prototype.EscapeSpecialChars = function(str){
			str = str.replace(/�/g,escape("�"));
			str = str.replace(/�/g,escape("�"));
			str = str.replace(/�/g,escape("�"));
			str = str.replace(/�/g,escape("�"));
			str = str.replace(/�/g,escape("�"));
			str = str.replace(/�/g,escape("�"));
			str = str.replace(/�/g,escape("�"));
			str = str.replace(/�/g,escape("�"));
			str = str.replace(/�/g,escape("�"));
			str = str.replace(/�/g,escape("�"));
			str = str.replace(/�/g,escape("�"));
			str = str.replace(/�/g,escape("�"));
			return str;
		};
		
		PHPLiveX.prototype.ShowError = function(errorMsg){
			if(errorMsg != ""){
				alert(errorMsg);
				return false;
			}else{
				return true;
			}
		};
		
		PHPLiveX.prototype.GetXmlHttp = function(){
			objXmlHttp = false;
	        if (window.XMLHttpRequest) {
	            objXmlHttp = new XMLHttpRequest();
	            if (objXmlHttp.overrideMimeType) {
	                objXmlHttp.overrideMimeType('text/xml');
	            }
	        } else if (window.ActiveXObject) {
	            try {
	                objXmlHttp = new ActiveXObject("Msxml2.XMLHTTP");
	            } catch (e) {
	                try {
	                    objXmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
	                } catch (e) {}
	            }
	        }

	        if (!objXmlHttp) {
	            alert('Giving up :( Cannot create an XMLHTTP instance');
	            return false;
	        }

			return objXmlHttp;
		};
		
		PHPLiveX.prototype.CreatePreloading = function(preloadId){
			document.getElementById(preloadId).style.visibility = "visible";
		};
		
		PHPLiveX.prototype.CreateOutput = function(funcName, funcArgs, funcUrl){
			var data = "funcName=" + escape(funcName);
			var args = new Array();
			if(funcUrl == null){ funcUrl = "<? echo $this->Url ?>"; }
			if(funcArgs != ""){
				if(funcArgs.indexOf(",") != -1){
					args = funcArgs.split(",");
					for (i=0;i<args.length;i++) { data += "&funcArgs[]=" + escape(args[i]); }
				}else{
					data += "&funcArgs[]=" + escape(funcArgs);
				}
			}
			var parentObject = this;
			
			var XmlHttp = this.GetXmlHttp();
			var ajaxType = false;
			if(this.TYPE != "r") ajaxType = true;
			
			if(this.METHOD == "get"){
				if(funcUrl.indexOf("?") != -1){
					XmlHttp.open("GET", funcUrl + "&" + this.EscapeSpecialChars(data), ajaxType);
				}else{
					XmlHttp.open("GET", funcUrl + "?" + this.EscapeSpecialChars(data), ajaxType);
				}
			}else{ XmlHttp.open("post", funcUrl, ajaxType); }
			
			XmlHttp.setRequestHeader("Method", this.METHOD + " " + funcUrl + " HTTP/1.1");
			XmlHttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=iso-8859-9");
			XmlHttp.setRequestHeader("Pragma", "no-cache");
			XmlHttp.setRequestHeader("Cache-Control", "must-revalidate");
			XmlHttp.setRequestHeader("Cache-Control", "no-cache");
			XmlHttp.setRequestHeader("Cache-Control", "no-store");
			
			if(this.TYPE != "r"){
				if(this.PRELOAD != null){ this.CreatePreloading(this.PRELOAD); }
				
				XmlHttp.onreadystatechange = function(){
					if(XmlHttp.readyState == 0){
						XmlHttp.abort();
						if(parentObject.PRELOAD != null){
							document.getElementById(parentObejct.PRELOAD).style.visibility = "hidden";
						}
					}else if(XmlHttp.readyState == 4){
						var output = parentObject.GetSpecialChars(XmlHttp.responseText);
						var outparts = output.split("<phplivex>");
						output = outparts[outparts.length-1].split("</phplivex>")[0];
						
						//If JS Code Exists
						var jscode = "";
						var parts = output.match(/<script[^>]*>(.|\n|\t|\r)*?<\/script>/gi);
						if(parts){
							for(i=0;i<parts.length;i++){
								jscode += parts[i].replace(/<script[^>]*>|<\/script>/gi, "");
								output = output.replace(parts[i], "");
							}
						}
						if(jscode != ""){
							var script = document.createElement("script");
							script.type = 'text/javascript'; 
							script.lang = 'javascript';
							script.text = jscode;
							document.getElementsByTagName('head')[0].appendChild(script);
						}
						//
						
						if(parentObject.PRELOAD != null){ document.getElementById(parentObject.PRELOAD).style.visibility = "hidden"; }
						
						if(parentObject.TYPE == "e"){ return; }
						else if(parentObject.TARGET == "alert"){ alert(output); }
						else if(parentObject.MODE == "aw"){ document.getElementById(parentObject.TARGET).innerHTML += output; }
						else if(parentObject.MODE == "rw"){ document.getElementById(parentObject.TARGET).innerHTML = output; }
					}
				};
				
				if(this.METHOD == "get"){ XmlHttp.send(null); }
				else{ XmlHttp.send(this.EscapeSpecialChars(data)); }
			}else{
				if(this.METHOD == "get"){ XmlHttp.send(null); }
				else{ XmlHttp.send(this.EscapeSpecialChars(data)); }
				var output = this.GetSpecialChars(XmlHttp.responseText);
				var outparts = output.split("<phplivex>");
				output = outparts[outparts.length-1].split("</phplivex>")[0];
				
				//If JS Code Exists
				var jscode = "";
				var parts = output.match(/<script[^>]*>(.|\n|\t|\r)*?<\/script>/gi);
				if(parts){
					for(i=0;i<parts.length;i++){
						jscode += parts[i].replace(/<script[^>]*>|<\/script>/gi, "");
						output = output.replace(parts[i], "");
					}
				}
				if(jscode != ""){
					var script = document.createElement("script");
					script.type = 'text/javascript'; 
					script.lang = 'javascript';
					script.text = jscode;
					document.getElementsByTagName('head')[0].appendChild(script);
				}
				//
				
				return output;
			}
		};
		
		<?
		$html = ob_get_contents();
		ob_end_clean();
		return $html;
		
	}

	function CreateFunction($funcName){
		ob_start();
		?>
		
		function <? echo $funcName ?>() {
			var args = new Array(); var plx_args = new Array();
			var plxType = "e"; var plxTarget = null;
			var plxMode = "rw"; var plxPreload = null;
			var plxMethod = "get";
			
			for(i=0;i<<? echo $funcName ?>.arguments.length;i++){ args[i] = <? echo $funcName ?>.arguments[i]; }
			if(args[args.length-1].indexOf(",") != -1){ plx_args = args[args.length-1].split(","); }
			else{ plx_args[0] = args[args.length-1]; }
			
			for(i=0;i<plx_args.length;i++){
				if(plx_args[i].indexOf("type=") != -1){
					plxType = plx_args[i].substr(5);
				}else if(plx_args[i].indexOf("target=") != -1){
					plxTarget = plx_args[i].substr(7);
					plxType = "print";
				}else if(plx_args[i].indexOf("mode=") != -1){
					plxMode = plx_args[i].substr(5);
				}else if(plx_args[i].indexOf("preload=") != -1){
					plxPreload = plx_args[i].substr(8);
				}else if(plx_args[i].indexOf("method=") != -1){
					plxMethod = plx_args[i].substr(7);
				}
			}

			args.splice(args.length-1, 1);
			var FuncArgs = args.join();
			
			var PLX_<? echo $funcName ?> = new PHPLiveX(plxType, plxTarget, plxMode, plxPreload, plxMethod);
					
			try{
				if(plxType == "r"){ 
					return PLX_<? echo $funcName ?>.CreateOutput("<? echo $funcName ?>", FuncArgs<?=!empty($this->FileUrl) ? ",\"".$this->Url."\"" : "" ; ?>);
				}else{
					PLX_<? echo $funcName ?>.CreateOutput("<? echo $funcName ?>", FuncArgs<?=!empty($this->FileUrl) ? ",\"".$this->Url."\"" : "" ;?>);
				}
			}catch(ex){
				PLX_<? echo $funcName ?>.ShowError(ex);
			}
			
				
		}
		<?
		$html = ob_get_contents();
		ob_end_clean();
		return $html;

	}

	function Run(){
		$html = $this->CreateJS();
		for($i=0;$i<count($this->FList);$i++){
			$html .= $this->CreateFunction($this->FList[$i]);
		}
		echo $html;
	}

	function GetFunctions(){
		$html = "";
		for($i=0;$i<count($this->FList);$i++){
			$html .= $this->CreateFunction($this->FList[$i]);
		}
		return $html;
	}


}

?>
