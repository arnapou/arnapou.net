<?php
require dirname(__FILE__).'/class.JavaScriptPacker.php';

if (count($_SERVER['argv']) != 3) {
	die("usage: packer.php <input_file> <output_file>\n");
}

$input  = $_SERVER['argv'][1];
$output = $_SERVER['argv'][2];
$script = file_get_contents($input);

$encoding     = 62;
$fast_decode  = true;
$special_char = false;
  
$t1 = microtime(true);
$packer = new JavaScriptPacker($script, $encoding, $fast_decode, $special_char);
$packed = $packer->pack();
$t2 = microtime(true);

file_put_contents($output, $packed);

$size_in  = str_pad(strlen($script), 6, " ", STR_PAD_LEFT);
$size_out = str_pad(strlen($packed), 6, " ", STR_PAD_LEFT);
$ratio    = str_pad(number_format(100 * $size_out / $size_in, 1).' %', 6);
$time     = str_pad(sprintf('%d', 1000*($t2 - $t1)).' ms', 7);

echo "$time  Size: $size_out / $size_in  -> $ratio  [ ".basename($input)." ]\n";

?>
